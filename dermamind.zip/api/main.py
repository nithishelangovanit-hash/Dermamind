import os
from contextlib import asynccontextmanager
from pathlib import Path
import joblib
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, StrictBool, StrictInt, field_validator

from api import pipeline

MODEL_VERSION = "synthetic-rf-0.1"
MODEL_DIR = Path(__file__).resolve().parent.parent / "ml" / "models"


class Consent(BaseModel):
    model_config = ConfigDict(extra="forbid")
    collect_details: StrictBool
    analyse_photo: StrictBool
    use_location: StrictBool
    share_with_doctor: StrictBool


class AnalyseRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    symptoms: dict[str, StrictInt]
    consent: Consent

    @field_validator("symptoms")
    @classmethod
    def validate_binary_features(cls, value: dict[str, int]) -> dict[str, int]:
        if any(v not in (0, 1) for v in value.values()):
            raise ValueError("Symptom values must be 0 or 1")
        return value


@asynccontextmanager
async def lifespan(app: FastAPI):
    model_path = MODEL_DIR / "dermamind_rf.joblib"
    order_path = MODEL_DIR / "feature_order.joblib"
    if not model_path.is_file() or not order_path.is_file():
        raise RuntimeError("Model artifacts are missing from ml/models")
    loaded_model = joblib.load(model_path)
    feature_order = joblib.load(order_path)
    if not isinstance(feature_order, (list, tuple)) or not feature_order:
        raise RuntimeError("feature_order.joblib must contain a non-empty feature list")
    pipeline.configure_model(loaded_model, feature_order)
    yield


app = FastAPI(title="DermaMind synthetic model API", version=MODEL_VERSION, lifespan=lifespan)

allowed_origins = [origin.strip() for origin in os.getenv("ALLOWED_ORIGINS", "").split(",") if origin.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_origin_regex=r"^http://localhost(?::\d+)?$",
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)


@app.get("/health")
def health():
    return {"status": "ok", "model": MODEL_VERSION}


@app.post("/analyse")
def analyse(request: AnalyseRequest):
    if pipeline.model is None:
        raise HTTPException(status_code=503, detail="Model is unavailable")
    result = pipeline.analyse(request.symptoms, request.consent.model_dump())
    return {**result, "model_version": MODEL_VERSION}
