"""Three-step inference pipeline copied from the DermaMind comparison notebook."""

import numpy as np
import pandas as pd

RED_FLAGS = ["Bleeding_Without_Injury", "Sore_Not_Healing_4wk", "Dark_Streak_Under_Nail"]
model = None
cols = []


def configure_model(loaded_model, feature_order):
    global model, cols
    model = loaded_model
    cols = list(feature_order)


# ---------- STEP 1: INPUT CHECK ----------
def input_check(symptoms: dict, consent: dict):
    issues = []

    # consent (each process is separate)
    for c in ["collect_details", "analyse_photo", "use_location", "share_with_doctor"]:
        if c not in consent:
            issues.append(f"consent missing: {c}")
    if not consent.get("collect_details", False):
        issues.append("no consent to collect details - cannot continue")

    # completeness and valid values
    unknown = [k for k in symptoms if k not in cols]
    missing = [c for c in cols if c not in symptoms]
    bad = [k for k, v in symptoms.items() if k in cols and v not in (0, 1)]
    if unknown: issues.append(f"unknown symptoms ignored: {unknown}")
    if bad:     issues.append(f"values must be 0 or 1: {bad}")
    if len(missing) > 0.4 * len(cols):
        issues.append("too many unanswered questions - please complete the form")

    blocking = [i for i in issues if "cannot continue" in i or "values must" in i or "too many" in i]
    return {"passed": not blocking, "issues": issues}


# ---------- STEP 2: MODEL CHECK ----------
def model_check(symptoms: dict):
    row = pd.DataFrame([{c: symptoms.get(c, 0) for c in cols}])
    risk = float(model.predict_proba(row)[0][1])

    # confidence = how much the individual trees agree
    tree_probs = np.array([t.predict_proba(row.values)[0][1] for t in model.estimators_])
    agreement = float(np.mean((tree_probs >= 0.5) == (risk >= 0.5)))
    confidence = "High" if agreement >= 0.85 else "Medium" if agreement >= 0.70 else "Low"

    zone = "Red" if risk >= 0.60 else "Yellow" if risk >= 0.25 else "Green"

    # safety rule: red-flag symptoms never score below Yellow
    safety_applied = False
    if zone == "Green" and any(symptoms.get(f, 0) == 1 for f in RED_FLAGS):
        zone, safety_applied = "Yellow", True

    # low confidence in a Green result is not left as Green
    if zone == "Green" and confidence == "Low":
        zone = "Yellow"

    imp = pd.Series(model.feature_importances_, index=cols)
    reasons = [c for c in imp.sort_values(ascending=False).index
               if symptoms.get(c, 0) == 1][:3]

    return {"risk_score": round(risk, 2), "zone": zone, "confidence": confidence,
            "tree_agreement": round(agreement, 2), "safety_rule_applied": safety_applied,
            "top_reasons": reasons}


# ---------- STEP 3: DOCTOR REVIEW ----------
def doctor_review(model_result: dict, consent: dict):
    needs_review = model_result["zone"] in ("Yellow", "Red")
    can_share = consent.get("share_with_doctor", False)
    if needs_review and can_share:
        status = "Queued for dermatologist review (can confirm or override)"
    elif needs_review:
        status = "Review recommended - user has not consented to share with a doctor"
    else:
        status = "No review needed - continue self-monitoring"
    return {"needs_review": needs_review, "status": status}


# ---------- FULL PIPELINE ----------
NEXT_STEP = {
    "Green": "Low concern now. Keep monitoring and re-check if anything changes.",
    "Yellow": "Book a dermatologist visit soon.",
    "Red": "See a dermatologist as soon as possible.",
}


def analyse(symptoms: dict, consent: dict):
    s1 = input_check(symptoms, consent)
    if not s1["passed"]:
        return {"step1_input_check": s1, "result": "Stopped: fix the input issues first"}

    s2 = model_check(symptoms)
    s3 = doctor_review(s2, consent)

    return {
        "step1_input_check": s1,
        "step2_model_check": s2,
        "step3_doctor_review": s3,
        "FINAL_OUTPUT": {
            "zone": s2["zone"],
            "next_step": NEXT_STEP[s2["zone"]],
            "reasons": s2["top_reasons"],
            "note": "Screening only, not a diagnosis.",
        },
    }
