# DermaMind screening API

The API uses only the twelve allowlisted Yes/No values and the four consent booleans. It never receives a patient's name, age, phone, place, images, or identifiers. It does not log request bodies or persist requests.

## Run locally

1. Place the matching `dermamind_rf.joblib` and `feature_order.joblib` files in `ml/models/`.
2. Install the packages in `api/requirements.txt` using the same scikit-learn version that created the model files.
3. Set `ALLOWED_ORIGINS` to a comma-separated list of exact site origins (for example, the deployed Netlify origin and `http://localhost:5173`). The API also permits `http://localhost:*` during local development.
4. From the project root, run `uvicorn api.main:app --reload`.

Check `GET /health` before setting `VITE_API_BASE_URL` for the frontend. Leave `VITE_API_BASE_URL` empty to disable ML. Netlify serves the frontend but cannot host this Python API; deploy the API separately on Render or Hugging Face Spaces and set its URL as `VITE_API_BASE_URL` at frontend build time.

## Inputs and scoring engines

The frontend always computes the rule-based score locally. When `VITE_API_BASE_URL` is set, it sends only the twelve binary symptom features plus `collect_details`, `analyse_photo`, `use_location`, and `share_with_doctor`. The API has an eight-second timeout. If the request fails or times out, the frontend keeps the rule-based result and records `rule-based fallback` as the engine.

The remaining thirteen symptoms (7, 9, 10, 11, 14, 15, 16, 18, 19, 21, 22, 24, 25) and all behaviour answers (duration, trend, frequency, intensity, and follow-ups) are excluded from the ML request. They remain inputs to the browser rule-based score, explanation panel, and doctor report.

The requested feature names match the corresponding names in the supplied CSV header: `Asymmetric_Spot`, `Irregular_Border`, `Multiple_Colours`, `Diameter_Over_6mm`, `Change_in_Size`, `Change_in_Shape_or_Colour`, `Bleeding_Without_Injury`, `Firm_or_Hard`, `Growing_Fast`, `Sore_Not_Healing_4wk`, `Looks_Different_From_Other_Moles`, and `Dark_Streak_Under_Nail`.

## Artifact and training note

The supplied notebook and 10k synthetic CSV are copied into `ml/notebooks/` and `ml/data/`. The notebook's training cell currently selects every non-diagnosis column from the CSV (25 symptom columns), while the integration request specifies a 12-feature model. The expected model and feature-order joblib files were not included, so the model's actual feature order and the training scikit-learn version cannot be verified. The API intentionally fails startup when either model artifact is absent; the frontend continues with the local rule-based fallback. Before deployment, supply the matching artifacts, confirm the model was trained on the twelve documented features, and pin the exact training scikit-learn version in `api/requirements.txt`.

All ML outputs are from a synthetic dataset. This is a prototype and is not clinically validated. The rule weights and thresholds are placeholders pending dermatologist review.
