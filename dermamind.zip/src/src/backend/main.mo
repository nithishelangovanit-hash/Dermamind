import Runtime "mo:core/Runtime";
import Time "mo:core/Time";
import Map "mo:core/Map";
import Array "mo:core/Array";
import Iter "mo:core/Iter";
import Order "mo:core/Order";
import List "mo:core/List";
import Principal "mo:core/Principal";
import MixinStorage "blob-storage/Mixin";
import Storage "blob-storage/Storage";
import MixinAuthorization "authorization/MixinAuthorization";
import AccessControl "authorization/access-control";

actor {
  type Gender = {
    #male;
    #female;
    #other;
  };

  module Gender {
    public func compare(gender1 : Gender, gender2 : Gender) : Order.Order {
      switch (gender1, gender2) {
        case (#male, #male) { #equal };
        case (#male, _) { #less };
        case (#female, #male) { #greater };
        case (#female, #female) { #equal };
        case (#female, #other) { #less };
        case (#other, #other) { #equal };
        case (#other, _) { #greater };
      };
    };
  };

  type UserRole = {
    #admin;
    #doctor;
    #patient;
  };

  module UserRole {
    public func compare(role1 : UserRole, role2 : UserRole) : Order.Order {
      switch (role1, role2) {
        case (#admin, #admin) { #equal };
        case (#admin, _) { #less };
        case (#doctor, #admin) { #greater };
        case (#doctor, #doctor) { #equal };
        case (#doctor, #patient) { #less };
        case (#patient, #patient) { #equal };
        case (#patient, _) { #greater };
      };
    };
  };

  type Symptom = {
    name : Text;
    severity : ?Nat8;
    durationDays : ?Nat16;
    trend : ?Text;
  };

  module Symptom {
    public func compare(symptom1 : Symptom, symptom2 : Symptom) : Order.Order {
      symptom1.name.compare(symptom2.name);
    };
  };

  type RiskFactor = {
    name : Text;
    description : Text;
  };

  module RiskFactor {
    public func compareByName(riskFactor1 : RiskFactor, riskFactor2 : RiskFactor) : Order.Order {
      riskFactor1.name.compare(riskFactor2.name);
    };
  };

  type PersonalInfo = {
    firstName : Text;
    lastName : Text;
    age : Nat8;
    gender : Gender;
    contact : Text;
  };

  module PersonalInfo {
    public func compareByFirstName(info1 : PersonalInfo, info2 : PersonalInfo) : Order.Order {
      switch (Text.compare(info1.firstName, info2.firstName)) {
        case (#equal) {
          switch (Text.compare(info1.lastName, info2.lastName)) {
            case (#equal) { info1.contact.compare(info2.contact) };
            case (order) { order };
          };
        };
        case (order) { order };
      };
    };
  };

  type UserProfile = {
    principal : Principal;
    role : UserRole;
    personalInfo : PersonalInfo;
  };

  module UserProfile {
    public func compareByFirstName(profile1 : UserProfile, profile2 : UserProfile) : Order.Order {
      PersonalInfo.compareByFirstName(profile1.personalInfo, profile2.personalInfo);
    };
  };

  type RiskZone = {
    #green;
    #yellow;
    #red;
  };

  module RiskZone {
    public func compare(zone1 : RiskZone, zone2 : RiskZone) : Order.Order {
      switch (zone1, zone2) {
        case (#green, #green) { #equal };
        case (#green, _) { #less };
        case (#yellow, #green) { #greater };
        case (#yellow, #yellow) { #equal };
        case (#yellow, #red) { #less };
        case (#red, #red) { #equal };
        case (#red, _) { #greater };
      };
    };
  };

  type ScreeningStatus = {
    #pending;
    #reviewed;
    #approved;
    #rejected;
  };

  module ScreeningStatus {
    public func compare(status1 : ScreeningStatus, status2 : ScreeningStatus) : Order.Order {
      switch (status1, status2) {
        case (#pending, #pending) { #equal };
        case (#pending, _) { #less };
        case (#reviewed, #pending) { #greater };
        case (#reviewed, #reviewed) { #equal };
        case (#reviewed, #approved) { #less };
        case (#reviewed, #rejected) { #less };
        case (#approved, #approved) { #equal };
        case (#approved, #rejected) { #less };
        case (#rejected, #rejected) { #equal };
        case (#rejected, _) { #greater };
        case (_) { #less };
      };
    };
  };

  type AnalyticsStats = {
    totalUsers : Nat;
    totalSubmissions : Nat;
    greenCount : Nat;
    yellowCount : Nat;
    redCount : Nat;
    pendingCount : Nat;
  };

  type DoctorReview = {
    doctorId : Principal;
    notes : Text;
    testRecommendations : [Text];
  };

  module DoctorReview {
    public func compareByDoctorId(review1 : DoctorReview, review2 : DoctorReview) : Order.Order {
      review1.doctorId.compare(review2.doctorId);
    };
  };

  type ScreeningSubmission = {
    id : Nat;
    userId : Principal;
    symptoms : [Symptom];
    riskFactors : [RiskFactor];
    aiRiskScore : Nat8;
    riskZone : RiskZone;
    image : ?Storage.ExternalBlob;
    report : ?Storage.ExternalBlob;
    status : ScreeningStatus;
    doctorReview : ?DoctorReview;
    submittedAt : Time.Time;
  };

  type Lab = {
    name : Text;
    contact : Text;
    address : Text;
    services : [Text];
  };

  module Lab {
    public func compareByName(lab1 : Lab, lab2 : Lab) : Order.Order {
      switch (Text.compare(lab1.name, lab2.name)) {
        case (#equal) { lab1.contact.compare(lab2.contact) };
        case (order) { order };
      };
    };
  };

  public type HealthReminder = {
    patientId : Text;
    message : Text;
    dueDate : Time.Time;
  };

  module HealthReminder {
    public func compareByDueDate(reminder1 : HealthReminder, reminder2 : HealthReminder) : Order.Order {
      if (reminder1.dueDate < reminder2.dueDate) {
        #less;
      } else if (reminder1.dueDate > reminder2.dueDate) {
        #greater;
      } else {
        compareByMessage(reminder1, reminder2);
      };
    };

    func compareByMessage(reminder1 : HealthReminder, reminder2 : HealthReminder) : Order.Order {
      reminder1.message.compare(reminder2.message);
    };
  };

  let users = Map.empty<Principal, UserProfile>();
  let submissions = Map.empty<Nat, ScreeningSubmission>();
  let patientReminders = Map.empty<Principal, [HealthReminder]>();
  let labs = Map.empty<Text, Lab>();

  var nextSubmissionId = 0;

  include MixinStorage();
  let accessControlState = AccessControl.initState();
  include MixinAuthorization(accessControlState);

  // Required by frontend: Get caller's own profile
  public query ({ caller }) func getCallerUserProfile() : async ?UserProfile {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view profiles");
    };
    users.get(caller);
  };

  // Required by frontend: Save caller's own profile
  public shared ({ caller }) func saveCallerUserProfile(profile : UserProfile) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can save profiles");
    };

    // Ensure caller cannot change their own principal
    if (profile.principal != caller) {
      Runtime.trap("Cannot change profile principal");
    };

    // Prevent privilege escalation - only admins can assign admin role
    if (profile.role == #admin) {
      let userProfile = users.get(caller);
      switch (userProfile) {
        case (?profile) {
          if (profile.role != #admin) {
            Runtime.trap("Unauthorized: Only admins can assign admin role");
          };
        };
        case (null) { Runtime.trap("User not found") };
      };
    };

    // Prevent users from changing to doctor role without admin approval
    switch (users.get(caller)) {
      case (?existingProfile) {
        if (existingProfile.role != #doctor and profile.role == #doctor) {
          Runtime.trap("Unauthorized: Only admins can assign doctor role");
        };
      };
      case (null) {
        // New profile - only allow patient role unless admin
        if (profile.role != #patient) {
          Runtime.trap("Unauthorized: New users can only register as patients");
        };
      };
    };
    users.add(caller, profile);
  };

  // Required by frontend: Get another user's profile (query-only)
  public query ({ caller }) func getUserProfile(user : Principal) : async ?UserProfile {
    // Allow user to view their own profile
    if (caller == user) {
      return users.get(user);
    };

    // Check if caller has admin role
    switch (users.get(caller)) {
      case (?profile) {
        if (profile.role != #admin) {
          Runtime.trap("Unauthorized: Can only view your own profile");
        };
        users.get(user);
      };
      case (null) { Runtime.trap("Unauthorized: Can only view your own profile") };
    };
  };

  // Admin-only: Create user profile with specific role
  public shared ({ caller }) func createUserProfile(personalInfo : PersonalInfo, role : UserRole) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can create user profiles");
    };
    let userProfile : UserProfile = {
      principal = caller;
      role;
      personalInfo;
    };
    users.add(caller, userProfile);
  };

  // Patient only: Submit screening
  public shared ({ caller }) func submitScreening(symptoms : [Symptom], riskFactors : [RiskFactor], aiRiskScore : Nat8, riskZone : RiskZone, image : ?Storage.ExternalBlob) : async Nat {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can submit screenings");
    };

    // Check if user has patient role
    switch (users.get(caller)) {
      case (?profile) {
        if (profile.role != #patient) {
          Runtime.trap("Unauthorized: Only patients can submit screenings");
        };
      };
      case (null) { Runtime.trap("Unauthorized: Only patients can submit screenings") };
    };

    let submissionId = nextSubmissionId;
    let submission : ScreeningSubmission = {
      id = submissionId;
      userId = caller;
      symptoms;
      riskFactors;
      aiRiskScore;
      riskZone;
      image;
      report = null;
      status = #pending;
      doctorReview = null;
      submittedAt = Time.now();
    };
    submissions.add(submissionId, submission);
    nextSubmissionId += 1;
    submissionId;
  };

  // Doctor only: Add doctor review
  public shared ({ caller }) func addDoctorReview(submissionId : Nat, review : DoctorReview, status : ScreeningStatus) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can add reviews");
    };

    // Check if user has doctor role
    switch (users.get(caller)) {
      case (?profile) {
        if (profile.role != #doctor) {
          Runtime.trap("Unauthorized: Only doctors can add reviews");
        };
      };
      case (null) { Runtime.trap("Unauthorized: Only doctors can add reviews") };
    };

    // Verify the review is from the caller
    if (review.doctorId != caller) {
      Runtime.trap("Unauthorized: Cannot submit review on behalf of another doctor");
    };

    switch (submissions.get(submissionId)) {
      case (null) { Runtime.trap("Submission not found") };
      case (?existingSubmission) {
        let updatedSubmission = {
          existingSubmission with
          doctorReview = ?review;
          status;
        };
        submissions.add(submissionId, updatedSubmission);
      };
    };
  };

  // Doctor or admin only: Add health reminders
  public shared ({ caller }) func addHealthReminders(personalId : Principal, reminders : HealthReminder) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can add reminders");
    };

    // Check if user has doctor or admin roles
    switch (users.get(caller)) {
      case (?profile) {
        if (profile.role != #doctor and profile.role != #admin) {
          Runtime.trap("Unauthorized: Only doctors and admins can add health reminders");
        };
      };
      case (null) { Runtime.trap("Unauthorized: Only doctors and admins can add health reminders") };
    };

    let currentReminders = switch (patientReminders.get(personalId)) {
      case (null) { [] };
      case (?existing) { existing };
    };
    let newReminders = currentReminders.concat([reminders]);
    patientReminders.add(personalId, newReminders);
  };

  // Patient can view own reminders
  public query ({ caller }) func getRemindersByDueDate(personalId : Principal) : async [HealthReminder] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view reminders");
    };

    // Check if user has access to view the reminders
    if (caller != personalId) {
      // If not the owner, must have doctor or admin role
      switch (users.get(caller)) {
        case (?profile) {
          if (profile.role != #doctor and profile.role != #admin) {
            Runtime.trap("Unauthorized: Can only view your own reminders");
          };
        };
        case (null) { Runtime.trap("Unauthorized: Can only view your own reminders") };
      };
    };

    switch (patientReminders.get(personalId)) {
      case (null) { [] };
      case (?reminders) {
        reminders.sort(
          HealthReminder.compareByDueDate
        );
      };
    };
  };

  // Admin only: Add lab
  public shared ({ caller }) func addLab(name : Text, contact : Text, address : Text, services : [Text]) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can add labs");
    };
    let lab : Lab = {
      name;
      contact;
      address;
      services;
    };
    labs.add(name, lab);
  };

  // Any authenticated user can view labs
  public query ({ caller }) func getLabsByName() : async [Lab] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view labs");
    };
    labs.values().toArray().sort(
      Lab.compareByName
    );
  };

  // Patient can view own submissions
  public query ({ caller }) func getPersonalScreeningSubmissions(personalId : Principal) : async [ScreeningSubmission] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view submissions");
    };

    // Check if user has access to view the submissions
    if (caller != personalId) {
      // If not the owner, must have doctor or admin role
      switch (users.get(caller)) {
        case (?profile) {
          if (profile.role != #doctor and profile.role != #admin) {
            Runtime.trap("Unauthorized: Can only view your own submissions");
          };
        };
        case (null) { Runtime.trap("Unauthorized: Can only view your own submissions") };
      };
    };

    let submissionsIter = submissions.values();
    submissionsIter.filter(
      func(s) {
        s.userId == personalId;
      }
    ).toArray();
  };

  // Doctor or admin only: Update screening status
  public shared ({ caller }) func updateScreeningStatus(submissionId : Nat, status : ScreeningStatus) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can update status");
    };

    // Check if user has doctor or admin roles
    switch (users.get(caller)) {
      case (?profile) {
        if (profile.role != #doctor and profile.role != #admin) {
          Runtime.trap("Unauthorized: Only doctors and admins can update screening status");
        };
      };
      case (null) { Runtime.trap("Unauthorized: Only doctors and admins can update screening status") };
    };

    switch (submissions.get(submissionId)) {
      case (null) { Runtime.trap("Submission not found") };
      case (?existingSubmission) {
        let updatedSubmission = { existingSubmission with status };
        submissions.add(submissionId, updatedSubmission);
      };
    };
  };

  // Doctor or admin only: Update screening report
  public shared ({ caller }) func updateScreeningReport(submissionId : Nat, report : Storage.ExternalBlob) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can update reports");
    };

    // Check if user has doctor or admin roles
    switch (users.get(caller)) {
      case (?profile) {
        if (profile.role != #doctor and profile.role != #admin) {
          Runtime.trap("Unauthorized: Only doctors and admins can update screening reports");
        };
      };
      case (null) { Runtime.trap("Unauthorized: Only doctors and admins can update screening reports") };
    };

    switch (submissions.get(submissionId)) {
      case (null) { Runtime.trap("Submission not found") };
      case (?existingSubmission) {
        let updatedSubmission = {
          existingSubmission with
          report = ?report;
        };
        submissions.add(submissionId, updatedSubmission);
      };
    };
  };

  // Doctor or admin only: Get submissions by risk zone
  public query ({ caller }) func getScreeningSubmissionsByRiskZone(riskZone : RiskZone) : async [ScreeningSubmission] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view submissions");
    };

    // Check if user has doctor or admin roles
    switch (users.get(caller)) {
      case (?profile) {
        if (profile.role != #doctor and profile.role != #admin) {
          Runtime.trap("Unauthorized: Only doctors and admins can view submissions by risk zone");
        };
      };
      case (null) { Runtime.trap("Unauthorized: Only doctors and admins can view submissions by risk zone") };
    };

    let submissionsIter = submissions.values();
    submissionsIter.filter(
      func(s) {
        s.riskZone == riskZone;
      }
    ).toArray();
  };

  // Admin only: Get analytics stats
  public query ({ caller }) func getAnalyticsStats() : async AnalyticsStats {
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can view analytics");
    };

    var greenCount = 0;
    var yellowCount = 0;
    var redCount = 0;
    var pendingCount = 0;

    for (submission in submissions.values()) {
      switch (submission.riskZone) {
        case (#green) { greenCount += 1 };
        case (#yellow) { yellowCount += 1 };
        case (#red) { redCount += 1 };
      };
      if (submission.status == #pending) {
        pendingCount += 1;
      };
    };

    {
      totalUsers = users.size();
      totalSubmissions = submissions.size();
      greenCount;
      yellowCount;
      redCount;
      pendingCount;
    };
  };
};
