import { Toaster } from "@/components/ui/sonner";
import { useState } from "react";
import Layout from "./components/Layout";
import AboutScreen from "./pages/AboutScreen";
import AdminDashboard from "./pages/AdminDashboard";
import AssessmentFlow from "./pages/AssessmentFlow";
import AuthScreen from "./pages/AuthScreen";
import DoctorDashboard from "./pages/DoctorDashboard";
import IntroScreen from "./pages/IntroScreen";
import LabRecommendations from "./pages/LabRecommendations";
import PatientDashboard from "./pages/PatientDashboard";
import PatientReportView from "./pages/PatientReportView";
import type { Patient, Screen, User } from "./types";

const PUBLIC_SCREENS: Screen[] = ["intro", "about", "auth"];

export default function App() {
  const [screen, setScreen] = useState<Screen>("intro");
  const [user, setUser] = useState<User | null>(null);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);

  function handleLogin(u: User) {
    setUser(u);
  }

  function handleLogout() {
    setUser(null);
    setScreen("intro");
  }

  function navigate(s: Screen) {
    setScreen(s);
  }

  const isPublic = PUBLIC_SCREENS.includes(screen);

  if (isPublic) {
    return (
      <>
        <Toaster />
        {screen === "intro" && <IntroScreen onNavigate={navigate} />}
        {screen === "about" && <AboutScreen onNavigate={navigate} />}
        {screen === "auth" && (
          <AuthScreen onNavigate={navigate} onLogin={handleLogin} />
        )}
      </>
    );
  }

  if (!user) {
    return <AuthScreen onNavigate={navigate} onLogin={handleLogin} />;
  }

  return (
    <>
      <Toaster />
      <Layout
        currentScreen={screen}
        user={user}
        onNavigate={navigate}
        onLogout={handleLogout}
      >
        {screen === "patient-dashboard" && (
          <PatientDashboard onNavigate={navigate} user={user} />
        )}
        {screen === "assessment" && (
          <AssessmentFlow onNavigate={navigate} user={user} />
        )}
        {screen === "doctor-dashboard" && (
          <DoctorDashboard
            onNavigate={navigate}
            onSelectPatient={setSelectedPatient}
          />
        )}
        {screen === "patient-report" && (
          <PatientReportView onNavigate={navigate} patient={selectedPatient} />
        )}
        {screen === "lab-recommendations" && <LabRecommendations />}
        {screen === "admin-dashboard" && <AdminDashboard />}
      </Layout>
    </>
  );
}
