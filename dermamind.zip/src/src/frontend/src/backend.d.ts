import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export class ExternalBlob {
    getBytes(): Promise<Uint8Array<ArrayBuffer>>;
    getDirectURL(): string;
    static fromURL(url: string): ExternalBlob;
    static fromBytes(blob: Uint8Array<ArrayBuffer>): ExternalBlob;
    withUploadProgress(onProgress: (percentage: number) => void): ExternalBlob;
}
export interface UserProfile {
    principal: Principal;
    role: UserRole;
    personalInfo: PersonalInfo;
}
export interface AnalyticsStats {
    pendingCount: bigint;
    greenCount: bigint;
    yellowCount: bigint;
    totalSubmissions: bigint;
    totalUsers: bigint;
    redCount: bigint;
}
export type Time = bigint;
export interface HealthReminder {
    patientId: string;
    dueDate: Time;
    message: string;
}
export interface PersonalInfo {
    age: number;
    contact: string;
    gender: Gender;
    lastName: string;
    firstName: string;
}
export interface DoctorReview {
    doctorId: Principal;
    testRecommendations: Array<string>;
    notes: string;
}
export interface RiskFactor {
    name: string;
    description: string;
}
export interface Lab {
    contact: string;
    name: string;
    address: string;
    services: Array<string>;
}
export interface Symptom {
    durationDays?: number;
    trend?: string;
    name: string;
    severity?: number;
}
export interface ScreeningSubmission {
    id: bigint;
    status: ScreeningStatus;
    report?: ExternalBlob;
    doctorReview?: DoctorReview;
    aiRiskScore: number;
    userId: Principal;
    riskZone: RiskZone;
    submittedAt: Time;
    riskFactors: Array<RiskFactor>;
    symptoms: Array<Symptom>;
    image?: ExternalBlob;
}
export enum Gender {
    other = "other",
    female = "female",
    male = "male"
}
export enum RiskZone {
    red = "red",
    green = "green",
    yellow = "yellow"
}
export enum ScreeningStatus {
    pending = "pending",
    approved = "approved",
    rejected = "rejected",
    reviewed = "reviewed"
}
export enum UserRole {
    patient = "patient",
    admin = "admin",
    doctor = "doctor"
}
export enum UserRole__1 {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    addDoctorReview(submissionId: bigint, review: DoctorReview, status: ScreeningStatus): Promise<void>;
    addHealthReminders(personalId: Principal, reminders: HealthReminder): Promise<void>;
    addLab(name: string, contact: string, address: string, services: Array<string>): Promise<void>;
    assignCallerUserRole(user: Principal, role: UserRole__1): Promise<void>;
    createUserProfile(personalInfo: PersonalInfo, role: UserRole): Promise<void>;
    getAnalyticsStats(): Promise<AnalyticsStats>;
    getCallerUserProfile(): Promise<UserProfile | null>;
    getCallerUserRole(): Promise<UserRole__1>;
    getLabsByName(): Promise<Array<Lab>>;
    getPersonalScreeningSubmissions(personalId: Principal): Promise<Array<ScreeningSubmission>>;
    getRemindersByDueDate(personalId: Principal): Promise<Array<HealthReminder>>;
    getScreeningSubmissionsByRiskZone(riskZone: RiskZone): Promise<Array<ScreeningSubmission>>;
    getUserProfile(user: Principal): Promise<UserProfile | null>;
    isCallerAdmin(): Promise<boolean>;
    saveCallerUserProfile(profile: UserProfile): Promise<void>;
    submitScreening(symptoms: Array<Symptom>, riskFactors: Array<RiskFactor>, aiRiskScore: number, riskZone: RiskZone, image: ExternalBlob | null): Promise<bigint>;
    updateScreeningReport(submissionId: bigint, report: ExternalBlob): Promise<void>;
    updateScreeningStatus(submissionId: bigint, status: ScreeningStatus): Promise<void>;
}
