import { Brain, Cross } from "lucide-react";

interface LogoProps {
  variant?: "light" | "dark";
  size?: "sm" | "md" | "lg";
}

export default function Logo({ variant = "dark", size = "md" }: LogoProps) {
  const textClass = variant === "dark" ? "text-foreground" : "text-white";
  const iconSize = size === "sm" ? 18 : size === "lg" ? 28 : 22;
  const textSize =
    size === "sm" ? "text-base" : size === "lg" ? "text-2xl" : "text-lg";

  return (
    <div className="flex items-center gap-2">
      <div className="relative flex items-center justify-center">
        <div className="bg-primary rounded-lg p-1.5">
          <Brain size={iconSize} className="text-white" />
        </div>
        <Cross
          size={10}
          className="absolute -top-1 -right-1 text-white fill-primary bg-primary rounded-full p-0.5"
        />
      </div>
      <span className={`font-bold tracking-tight ${textSize} ${textClass}`}>
        Onco<span className="text-primary">Mind</span>
      </span>
    </div>
  );
}
