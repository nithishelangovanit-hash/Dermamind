import type { Patient } from "../types";

function riskLevelLabel(zone: string): string {
  if (zone === "red") return "RED — HIGH RISK";
  if (zone === "yellow") return "YELLOW — MODERATE RISK";
  return "GREEN — LOW RISK";
}

function riskLevelColor(zone: string): string {
  if (zone === "red") return "#c62828";
  if (zone === "yellow") return "#f57f17";
  return "#2e7d32";
}

function statusColor(status: string): string {
  if (status === "approved") return "#2e7d32";
  if (status === "rejected") return "#c62828";
  return "#e65100";
}

function escapeHtml(str: string): string {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function sectionHeader(title: string): string {
  return `
    <div class="section-header">
      <span>${escapeHtml(title)}</span>
    </div>
  `;
}

function infoRow(label: string, value: string): string {
  return `
    <div class="info-cell">
      <span class="info-label">${escapeHtml(label)}</span>
      <span class="info-value">${escapeHtml(value)}</span>
    </div>
  `;
}

function buildHTML(
  patient: Patient,
  doctorNotes?: string,
  recommendedTests?: string[],
): string {
  const p = patient;
  const now = new Date().toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  // --- Symptom rows
  const positiveSymptoms = (p.symptomData ?? []).filter((s) => s.present);
  let symptomRows = "";
  if (positiveSymptoms.length === 0) {
    symptomRows = `<tr><td colspan="4" class="empty-cell">No symptoms reported</td></tr>`;
  } else {
    for (const s of positiveSymptoms) {
      const intensityColor =
        s.intensity === "High"
          ? "#c62828"
          : s.intensity === "Medium"
            ? "#e65100"
            : "#2e7d32";
      symptomRows += `
        <tr>
          <td>${escapeHtml(s.name)}</td>
          <td>${escapeHtml(s.duration)}</td>
          <td style="color: ${intensityColor}; font-weight: 600;">${escapeHtml(s.intensity)}</td>
          <td>${escapeHtml(s.trend)}</td>
        </tr>
      `;
    }
  }

  // --- Exposure
  const exposureText =
    p.exposure && p.exposure.length > 0 ? p.exposure.join(", ") : "None";

  const exposureTextForSkin = p.exposure?.length
    ? `Reported skin-related exposure: ${p.exposure.join(", ")}. Discuss this history with a dermatologist.`
    : "No skin-related exposures reported.";

  // --- Image findings
  const imageFindings = p.structuredReport?.imageFindings
    ? p.structuredReport.imageFindings
    : p.imageBase64
      ? "Skin image uploaded — ABCDE rule assessment pending specialist review."
      : "No image uploaded by patient.";

  // --- Final reasoning
  const finalReasoning = p.structuredReport?.recommendation
    ? p.structuredReport.recommendation
    : `Based on the symptom profile, lifestyle data, and risk factors, the AI system has assigned a risk score of ${p.riskScore}/100 (${riskLevelLabel(p.riskZone)}). Clinical correlation and specialist review are advised.`;

  // --- Risk factors
  const riskFactorsText =
    p.riskFactors && p.riskFactors.length > 0
      ? p.riskFactors.join("\n• ")
      : "No specific risk factors identified.";

  // --- Contributing symptoms
  const contributingText =
    p.symptoms && p.symptoms.length > 0
      ? p.symptoms.join("\n• ")
      : "No contributing symptoms identified.";

  // --- Image section
  const imageSection = p.imageBase64
    ? `<div class="image-container">
        <img src="${p.imageBase64}" alt="Patient Skin Image" class="patient-image" />
        <p class="image-caption">Uploaded skin/medical image — Patient ID: ${escapeHtml(p.id)}</p>
       </div>`
    : `<p class="na-text">No skin/medical image uploaded by patient.</p>`;

  // --- Uploaded reports
  const reportsSection =
    p.testReports && p.testReports.length > 0
      ? `<ul class="list-items">${p.testReports.map((r) => `<li>${escapeHtml(r.name)} <span class="badge">${escapeHtml(r.type.toUpperCase())}</span></li>`).join("")}</ul>`
      : `<p class="na-text">No medical reports uploaded.</p>`;

  // --- Doctor section
  const notesText =
    doctorNotes?.trim() ||
    p.doctorNotes?.trim() ||
    "No notes added by reviewing doctor.";
  const testsArr =
    recommendedTests && recommendedTests.length > 0
      ? recommendedTests
      : p.recommendedTests && p.recommendedTests.length > 0
        ? p.recommendedTests
        : [];
  const testsText = testsArr.length > 0 ? testsArr.join(", ") : "None selected";
  const currentStatus = p.status || "pending";

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>DermaMind Skin Screening Report — ${escapeHtml(p.id)}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Segoe UI', Arial, sans-serif;
      background: #ffffff;
      color: #1a1a1a;
      font-size: 13px;
      line-height: 1.5;
      padding: 0;
    }
    .page {
      max-width: 900px;
      margin: 0 auto;
      padding: 32px 40px;
    }
    /* Header */
    .report-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      padding-bottom: 18px;
      border-bottom: 3px solid #E53935;
      margin-bottom: 24px;
    }
    .brand-block .brand-name {
      font-size: 28px;
      font-weight: 800;
      color: #E53935;
      letter-spacing: -0.5px;
    }
    .brand-block .brand-tagline {
      font-size: 13px;
      color: #666;
      margin-top: 2px;
    }
    .brand-block .report-title {
      font-size: 16px;
      font-weight: 700;
      color: #1a1a1a;
      margin-top: 6px;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .meta-block {
      text-align: right;
      font-size: 12px;
      color: #555;
      line-height: 1.8;
    }
    .meta-block .patient-id {
      font-weight: 700;
      color: #E53935;
      font-size: 14px;
    }
    /* Section headers */
    .section-header {
      background: #E53935;
      color: #ffffff;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      padding: 7px 14px;
      border-radius: 4px;
      margin-bottom: 14px;
      margin-top: 22px;
    }
    /* Info grid */
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px 24px;
      margin-bottom: 6px;
    }
    .info-grid-3 {
      grid-template-columns: 1fr 1fr 1fr;
    }
    .info-cell {
      display: flex;
      flex-direction: column;
      padding: 6px 0;
      border-bottom: 1px solid #f0f0f0;
    }
    .info-label {
      font-size: 10px;
      color: #888;
      text-transform: uppercase;
      letter-spacing: 0.4px;
      font-weight: 600;
      margin-bottom: 2px;
    }
    .info-value {
      font-size: 13px;
      font-weight: 600;
      color: #1a1a1a;
    }
    /* Tables */
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
      margin-bottom: 6px;
    }
    th {
      background: #fafafa;
      border: 1px solid #e0e0e0;
      padding: 8px 10px;
      text-align: left;
      font-weight: 700;
      color: #555;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    td {
      border: 1px solid #e0e0e0;
      padding: 8px 10px;
      color: #1a1a1a;
      vertical-align: top;
    }
    tr:nth-child(even) td { background: #fafafa; }
    .empty-cell {
      text-align: center;
      color: #888;
      font-style: italic;
    }
    /* Risk badge */
    .risk-badge {
      display: inline-block;
      padding: 5px 16px;
      border-radius: 20px;
      font-weight: 800;
      font-size: 14px;
      color: #fff;
      margin-top: 4px;
    }
    /* Text sections */
    .finding-block {
      margin-bottom: 14px;
    }
    .finding-block h4 {
      font-size: 12px;
      font-weight: 700;
      color: #E53935;
      margin-bottom: 5px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    .finding-block p, .finding-block ul {
      font-size: 13px;
      color: #333;
      line-height: 1.6;
    }
    .finding-block ul {
      padding-left: 18px;
    }
    .finding-block li {
      margin-bottom: 3px;
    }
    /* Image */
    .image-container {
      margin: 8px 0 12px;
    }
    .patient-image {
      max-width: 200px;
      max-height: 200px;
      object-fit: cover;
      border: 2px solid #e0e0e0;
      border-radius: 6px;
      display: block;
    }
    .image-caption {
      font-size: 11px;
      color: #888;
      margin-top: 4px;
      font-style: italic;
    }
    /* Score row */
    .score-row {
      display: flex;
      align-items: center;
      gap: 24px;
      flex-wrap: wrap;
      padding: 12px;
      background: #fafafa;
      border: 1px solid #e0e0e0;
      border-radius: 6px;
    }
    .score-item {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .score-label {
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.4px;
      color: #888;
    }
    .score-value {
      font-size: 26px;
      font-weight: 900;
      color: #E53935;
      line-height: 1;
    }
    .score-unit {
      font-size: 12px;
      color: #888;
    }
    /* Doctor notes */
    .notes-box {
      background: #fffde7;
      border: 1px solid #f9a825;
      border-left: 4px solid #f9a825;
      border-radius: 4px;
      padding: 12px 14px;
      font-size: 13px;
      color: #3e2723;
      white-space: pre-wrap;
      margin-bottom: 12px;
    }
    /* List items */
    .list-items {
      padding-left: 18px;
      margin: 0;
    }
    .list-items li {
      margin-bottom: 4px;
      font-size: 13px;
    }
    .badge {
      display: inline-block;
      background: #e8eaf6;
      color: #3949ab;
      font-size: 10px;
      font-weight: 700;
      padding: 1px 7px;
      border-radius: 10px;
      margin-left: 6px;
    }
    .na-text {
      color: #888;
      font-style: italic;
      font-size: 13px;
    }
    /* Reasoning block */
    .reasoning-block {
      background: #fff8f8;
      border-left: 4px solid #E53935;
      padding: 12px 14px;
      border-radius: 4px;
      font-size: 13px;
      color: #1a1a1a;
      line-height: 1.7;
    }
    /* Footer */
    .report-footer {
      margin-top: 36px;
      padding-top: 14px;
      border-top: 2px solid #E53935;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
    }
    .footer-confidential {
      font-size: 10px;
      font-weight: 700;
      color: #E53935;
      text-transform: uppercase;
      letter-spacing: 0.8px;
    }
    .footer-generated {
      font-size: 10px;
      color: #999;
      text-align: right;
    }
    @media print {
      body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
      .page { padding: 20px 24px; }
      .section-header { background: #E53935 !important; color: #fff !important; }
      .risk-badge { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    }
  </style>
</head>
<body>
<div class="page">

  <!-- ===== REPORT HEADER ===== -->
  <div class="report-header">
    <div class="brand-block">
      <div class="brand-name">DermaMind</div>
      <div class="brand-tagline">AI-Powered Early Cancer Detection Platform</div>
      <div class="report-title">Structured Clinical Report</div>
    </div>
    <div class="meta-block">
      <div class="patient-id">Patient ID: ${escapeHtml(p.id)}</div>
      <div>Generated: ${escapeHtml(now)}</div>
      <div>Submission: ${escapeHtml(p.submittedAt)}</div>
      <div>Status: <strong style="color: ${statusColor(currentStatus)}">${escapeHtml(currentStatus.toUpperCase())}</strong></div>
    </div>
  </div>

  <!-- ===== SECTION 1: PATIENT INFORMATION ===== -->
  ${sectionHeader("1. Patient Information")}
  <div class="info-grid">
    ${infoRow("Full Name", p.name)}
    ${infoRow("Age", `${p.age} years`)}
    ${infoRow("Phone Number", p.phone || "—")}
    ${infoRow("Place / Location", p.place || "—")}
    ${infoRow("Gender", p.gender || "—")}
    ${infoRow("Submitted On", p.submittedAt)}
  </div>

  <!-- ===== SECTION 2: LIFESTYLE DETAILS ===== -->
  ${sectionHeader("2. Lifestyle Details")}
  <div class="info-grid">
    ${infoRow("Smoking Status", p.smoking)}
    ${infoRow("Alcohol Consumption", p.alcohol)}
    ${infoRow("Environmental Exposure", exposureText)}
    ${infoRow("Existing Diseases", p.existingDiseases || "None reported")}
  </div>

  <!-- ===== SECTION 3: SYMPTOM SUMMARY ===== -->
  ${sectionHeader("3. Symptom Summary (YES Symptoms Only)")}
  <p style="font-size: 11px; color: #888; margin-bottom: 10px; font-style: italic;">Only symptoms marked YES are listed below.</p>
  <table>
    <thead>
      <tr>
        <th>Symptom</th>
        <th>Duration (Weeks)</th>
        <th>Trend</th>
        <th>Intensity</th>
      </tr>
    </thead>
    <tbody>
      ${symptomRows}
    </tbody>
  </table>

  <!-- ===== SECTION 4: AI FINDINGS ===== -->
  ${sectionHeader("4. AI Findings")}
  <div class="finding-block">
    <h4>Key Contributing Symptoms</h4>
    <ul>${contributingText
      .split("\n")
      .map((s) => `<li>${escapeHtml(s.replace(/^•\s*/, ""))}</li>`)
      .join("")}</ul>
  </div>
  <div class="finding-block">
    <h4>Risk Factors</h4>
    <ul>${riskFactorsText
      .split("\n")
      .map((s) => `<li>${escapeHtml(s.replace(/^•\s*/, ""))}</li>`)
      .join("")}</ul>
  </div>
  <div class="finding-block">
    <h4>Reported exposure history</h4>
    <p>${escapeHtml(exposureTextForSkin)}</p>
  </div>
  <div class="finding-block">
    <h4>Image-Based Observations (ABCDE Rule)</h4>
    <p>${escapeHtml(imageFindings)}</p>
  </div>
  <div class="finding-block">
    <h4>Final Reasoning</h4>
    <div class="reasoning-block">${escapeHtml(finalReasoning)}</div>
  </div>

  <!-- ===== SECTION 5: RISK ASSESSMENT ===== -->
  ${sectionHeader("5. Risk Assessment")}
  <div class="score-row">
    <div class="score-item">
      <span class="score-label">Risk Score</span>
      <span class="score-value">${p.riskScore}<span class="score-unit">/100</span></span>
    </div>
    <div class="score-item">
      <span class="score-label">Risk Level</span>
      <span class="risk-badge" style="background: ${riskLevelColor(p.riskZone)};">${escapeHtml(riskLevelLabel(p.riskZone))}</span>
    </div>
    ${
      p.confidenceScore !== undefined
        ? `
    <div class="score-item">
      <span class="score-label">AI Confidence</span>
      <span class="score-value" style="color: #1565c0">${p.confidenceScore}<span class="score-unit">%</span></span>
    </div>
    `
        : ""
    }
  </div>

  <!-- ===== SECTION 6: UPLOADED DATA ===== -->
  ${sectionHeader("6. Uploaded Data")}
  <div class="finding-block">
    <h4>Skin / Medical Image</h4>
    ${imageSection}
  </div>
  <div class="finding-block">
    <h4>Uploaded Medical Reports</h4>
    ${reportsSection}
  </div>

  <!-- ===== SECTION 7: DOCTOR SECTION ===== -->
  ${sectionHeader("7. Doctor Section")}
  <div class="finding-block">
    <h4>Doctor Notes</h4>
    <div class="notes-box">${escapeHtml(notesText)}</div>
  </div>
  <div class="info-grid">
    ${infoRow("Approval Status", currentStatus.toUpperCase())}
    ${infoRow("Recommended Tests", testsText)}
  </div>

  <!-- ===== FOOTER ===== -->
  <div class="report-footer">
    <div>
      <div class="footer-confidential">⚠ CONFIDENTIAL — For Authorized Medical Personnel Only</div>
      <div style="font-size: 11px; color: #888; margin-top: 3px;">Prototype rule-based skin screening summary. Not a diagnosis.</div>
    </div>
    <div class="footer-generated">
      <div>DermaMind · Screening aid only</div>
      <div>Report ID: OM-${escapeHtml(p.id)}-${Date.now()}</div>
    </div>
  </div>

</div>
</body>
</html>`;
}

export function generateClinicalReportPDF(
  patient: Patient,
  doctorNotes?: string,
  recommendedTests?: string[],
): void {
  const html = buildHTML(patient, doctorNotes, recommendedTests);
  const printWindow = window.open("", "_blank");
  if (!printWindow) {
    alert(
      "Popup blocked. Please allow popups to download the clinical report.",
    );
    return;
  }
  printWindow.document.write(html);
  printWindow.document.close();
  // Wait for images to load before printing
  printWindow.onload = () => {
    setTimeout(() => {
      printWindow.focus();
      printWindow.print();
    }, 400);
  };
  // Fallback if onload already fired
  setTimeout(() => {
    try {
      printWindow.focus();
      printWindow.print();
    } catch {
      // already closed or printed
    }
  }, 1200);
}
