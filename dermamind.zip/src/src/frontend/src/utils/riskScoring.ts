import type { RiskZone, SymptomData } from "../types";

function getDurationWeeks(duration: string): number {
  const match = duration.match(/^(\d+)/);
  return match ? Number.parseInt(match[1]) : 1;
}

export function calculateRiskWithConfidence(
  symptoms: SymptomData[],
  riskFactors: string[],
): { score: number; confidence: number } {
  let score = 0;
  const presentSymptoms = symptoms.filter((s) => s.present);

  for (const s of presentSymptoms) {
    const weeks = getDurationWeeks(s.duration);
    const intensityBase =
      s.intensity === "High" ? 15 : s.intensity === "Medium" ? 10 : 5;
    let symptomScore = 0;

    if (weeks <= 2) {
      // Week 1-2: Low weight, IGNORE trend, DO NOT escalate
      symptomScore = intensityBase * 0.3;
    } else if (weeks <= 4) {
      // Week 3-4: Normal evaluation, moderate trend
      const trendFactor =
        s.trend === "Worse" ? 1.2 : s.trend === "Same" ? 1.0 : 0.8;
      symptomScore = intensityBase * 1.0 * trendFactor;
    } else {
      // Week 5+: High importance, strong trend + intensity
      const trendFactor =
        s.trend === "Worse" ? 2.0 : s.trend === "Same" ? 1.3 : 0.7;
      const intensityMultiplier =
        s.intensity === "High" ? 1.5 : s.intensity === "Medium" ? 1.2 : 1.0;
      symptomScore = intensityBase * intensityMultiplier * trendFactor;
    }

    score += symptomScore;
  }

  score += riskFactors.length * 8;

  // Multi-symptom confidence
  const count = presentSymptoms.length;
  let confidence = 0;
  if (count === 0) confidence = 0;
  else if (count === 1) confidence = 30;
  else if (count === 2) confidence = 50;
  else if (count === 3) confidence = 65;
  else if (count === 4) confidence = 78;
  else confidence = Math.min(85 + (count - 5) * 3, 97);

  if (riskFactors.length > 0)
    confidence = Math.min(confidence + riskFactors.length * 3, 98);

  return { score: Math.min(Math.round(score), 100), confidence };
}

export function calculateRiskScore(
  symptoms: SymptomData[],
  riskFactors: string[],
): number {
  return calculateRiskWithConfidence(symptoms, riskFactors).score;
}

export function getRiskZone(score: number): RiskZone {
  if (score >= 80) return "red";
  if (score >= 41) return "yellow";
  return "green";
}

export function getRiskLabel(zone: RiskZone): string {
  return zone === "red"
    ? "High Risk"
    : zone === "yellow"
      ? "Medium Risk"
      : "Low Risk";
}

export function getRiskColors(zone: RiskZone): {
  bg: string;
  text: string;
  border: string;
} {
  if (zone === "red")
    return { bg: "bg-red-100", text: "text-red-700", border: "border-red-200" };
  if (zone === "yellow")
    return {
      bg: "bg-yellow-100",
      text: "text-yellow-700",
      border: "border-yellow-200",
    };
  return {
    bg: "bg-green-100",
    text: "text-green-700",
    border: "border-green-200",
  };
}
