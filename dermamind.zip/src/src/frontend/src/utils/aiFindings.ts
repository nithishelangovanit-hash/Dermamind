import type { ClinicalReport, Patient } from "../types";

/** Explainable screening summary. No medical image or diagnosis is produced. */
export function generateAIFindings(patient: Patient): string[] {
  const findings: string[] = [];
  if (patient.symptoms.length) {
    findings.push(`Reported skin changes: ${patient.symptoms.join(", ")}`);
  }
  if (patient.exposure.length) {
    findings.push(`Reported exposures: ${patient.exposure.join(", ")}`);
  }
  if (patient.riskFactors.length) {
    findings.push(`Reported history factors: ${patient.riskFactors.join(", ")}`);
  }
  findings.push(`Rule-based screening zone: ${patient.riskZone} (score ${patient.riskScore}). This is not a diagnosis or probability.`);
  findings.push(patient.imageBase64
    ? "An image was attached; this version does not analyze images. Ask a dermatologist to review it."
    : "No image was attached for clinician review.");
  if (patient.existingDiseases?.trim()) findings.push("Other medical history was provided for clinician context.");
  return findings;
}

export function generateStructuredClinicalReport(patient: Patient, confidenceScore: number): ClinicalReport {
  const positiveSymptoms = (patient.symptomData || []).filter((s) => s.present);
  return {
    generatedAt: new Date().toISOString(),
    symptoms: positiveSymptoms.map((s) => ({ name: s.name, duration: s.duration, intensity: s.intensity, trend: s.trend })),
    riskFactors: patient.riskFactors,
    imageFindings: patient.imageBase64
      ? "Image attached but not analyzed by this screening tool. Dermatologist review is recommended."
      : "No image provided. This tool does not perform image analysis.",
    recommendation: patient.riskZone === "red"
      ? "Arrange prompt dermatologist assessment, particularly for a changing, bleeding, or non-healing spot."
      : patient.riskZone === "yellow"
        ? "Consider a dermatologist appointment to review the reported skin changes."
        : "Continue checking for changes and seek professional assessment if a spot becomes concerning.",
    confidenceScore,
    riskScore: patient.riskScore,
    riskZone: patient.riskZone,
  };
}
