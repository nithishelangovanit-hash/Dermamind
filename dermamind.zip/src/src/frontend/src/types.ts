export type Screen =
  | "intro"
  | "about"
  | "auth"
  | "patient-dashboard"
  | "assessment"
  | "doctor-dashboard"
  | "patient-report"
  | "lab-recommendations"
  | "admin-dashboard";

export type Role = "patient" | "doctor" | "admin";
export type RiskZone = "red" | "yellow" | "green";
export type SubmissionStatus =
  | "pending"
  | "in-progress"
  | "approved"
  | "rejected";

export interface SymptomData {
  name: string;
  present: boolean;
  duration: string;
  trend: "Improving" | "Same" | "Worse";
  intensity: "Low" | "Medium" | "High";
}

export interface TestFinding {
  parameter: string;
  value: string;
  referenceRange: string;
  isAbnormal: boolean;
}

export interface TestReport {
  id: string;
  name: string;
  type: "blood" | "ct" | "xray" | "other";
  uploadedAt: string;
  findings: TestFinding[];
  summary: string;
}

export interface ClinicalReport {
  generatedAt: string;
  symptoms: {
    name: string;
    duration: string;
    intensity: string;
    trend: string;
  }[];
  riskFactors: string[];
  imageFindings: string;
  recommendation: string;
  confidenceScore: number;
  riskScore: number;
  riskZone: string;
}

export interface Patient {
  id: string;
  userId: string;
  name: string;
  age: number;
  gender: string;
  phone: string;
  place: string;
  smoking: "non-smoker" | "occasional" | "regular";
  alcohol: "no" | "occasional" | "regular";
  exposure: string[];
  existingDiseases: string;
  riskScore: number;
  riskZone: RiskZone;
  status: SubmissionStatus;
  symptoms: string[];
  symptomData?: SymptomData[];
  riskFactors: string[];
  submittedAt: string;
  imageBase64?: string;
  aiFindings: string[];
  confidenceScore?: number;
  consultationActive?: boolean;
  doctorReviewed?: boolean;
  testReports?: TestReport[];
  structuredReport?: ClinicalReport;
  doctorNotes?: string;
  recommendedTests?: string[];
}

export interface Lab {
  id: number;
  name: string;
  city: string;
  distance: number;
  rating: number;
  tests: string[];
  costRange: string;
  category: "low" | "mid" | "high";
}

export interface User {
  name: string;
  email: string;
  role: Role;
}
