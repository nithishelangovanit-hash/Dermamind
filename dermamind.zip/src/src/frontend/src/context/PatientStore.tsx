import type React from "react";
import { createContext, useContext, useEffect, useState } from "react";
import type { Patient } from "../types";

interface PatientStoreCtx {
  patients: Patient[];
  addPatient: (p: Patient) => void;
  updatePatient: (id: string, updates: Partial<Patient>) => void;
}

const PatientStoreContext = createContext<PatientStoreCtx>({
  patients: [],
  addPatient: () => {},
  updatePatient: () => {},
});

export function PatientStoreProvider({
  children,
}: { children: React.ReactNode }) {
  const [patients, setPatients] = useState<Patient[]>(() => {
    try {
      const stored = localStorage.getItem("oncomind_patients");
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("oncomind_patients", JSON.stringify(patients));
  }, [patients]);

  function addPatient(p: Patient) {
    setPatients((prev) => [p, ...prev]);
  }

  function updatePatient(id: string, updates: Partial<Patient>) {
    setPatients((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p)),
    );
  }

  return (
    <PatientStoreContext.Provider
      value={{ patients, addPatient, updatePatient }}
    >
      {children}
    </PatientStoreContext.Provider>
  );
}

export function usePatientStore() {
  return useContext(PatientStoreContext);
}
