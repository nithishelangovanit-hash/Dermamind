import { Button } from "@/components/ui/button";
import { MapPin, Phone, Star } from "lucide-react";
import { mockLabs } from "../data/mockData";

const STAR_KEYS = ["s1", "s2", "s3", "s4", "s5"];

export default function LabRecommendations() {
  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Nearby Labs</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Recommended diagnostic centres for your tests
        </p>
      </div>

      <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
        <p className="text-sm font-medium text-primary">
          Skin screening options: Dermatologist consultation · Dermoscopy · Skin biopsy (if advised by a clinician)
        </p>
      </div>

      <div
        className="grid grid-cols-1 md:grid-cols-2 gap-4"
        data-ocid="labs.list"
      >
        {mockLabs.map((lab, i) => (
          <div
            key={lab.id}
            className="bg-card rounded-xl p-5 shadow-card border border-border"
            data-ocid={`labs.item.${i + 1}`}
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="font-semibold text-base">{lab.name}</h3>
                <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                  <MapPin size={12} /> {lab.city} · {lab.distance} km away
                </div>
              </div>
              <span
                className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                  lab.category === "high"
                    ? "bg-red-100 text-red-700"
                    : lab.category === "mid"
                      ? "bg-yellow-100 text-yellow-700"
                      : "bg-green-100 text-green-700"
                }`}
              >
                {lab.category === "high"
                  ? "Premium"
                  : lab.category === "mid"
                    ? "Standard"
                    : "Budget"}
              </span>
            </div>

            <div className="flex items-center gap-1 mb-3">
              {STAR_KEYS.map((sk, j) => (
                <Star
                  key={sk}
                  size={14}
                  className={
                    j < Math.floor(lab.rating)
                      ? "text-yellow-400 fill-yellow-400"
                      : "text-gray-200 fill-gray-200"
                  }
                />
              ))}
              <span className="text-xs text-muted-foreground ml-1">
                {lab.rating}
              </span>
            </div>

            <div className="flex flex-wrap gap-1 mb-3">
              {lab.tests.map((t) => (
                <span
                  key={t}
                  className="bg-muted text-xs px-2 py-0.5 rounded-full"
                >
                  {t}
                </span>
              ))}
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">
                  Estimated Cost (INR)
                </p>
                <p className="text-sm font-bold text-primary">
                  {lab.costRange}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs"
                  data-ocid={`labs.directions.button.${i + 1}`}
                >
                  <MapPin size={12} className="mr-1" /> Directions
                </Button>
                <Button
                  size="sm"
                  className="text-xs bg-primary hover:bg-primary/90 text-white"
                  data-ocid={`labs.book.button.${i + 1}`}
                >
                  <Phone size={12} className="mr-1" /> Book
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <footer className="border-t border-border pt-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()}. Built with ❤️ using{" "}
        <a
          href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
          className="underline"
          target="_blank"
          rel="noreferrer"
        >
          caffeine.ai
        </a>
      </footer>
    </div>
  );
}
