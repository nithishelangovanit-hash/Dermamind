import { Button } from "@/components/ui/button";
import {
  AlertCircle,
  ArrowLeft,
  Brain,
  ChevronRight,
  ClipboardList,
  Heart,
  Shield,
  Stethoscope,
  Sun,
  User,
  Wind,
} from "lucide-react";
import Logo from "../components/Logo";
import type { Screen } from "../types";

interface Props {
  onNavigate: (screen: Screen) => void;
}

const stats = [
  {
    value: "ABCDE",
    label: "spot warning sign checklist",
    source: "Screening guide",
  },
  {
    value: "EFG",
    label: "Elevated, Firm, Growing",
    source: "Screening guide",
  },
  {
    value: "1 spot",
    label: "Notice the Ugly Duckling sign",
    source: "Screening guide",
  },
];

const howItWorks = [
  {
    step: "1",
    title: "Submit Information",
    desc: "Answer the skin warning-sign questions and the visible follow-up prompts.",
    icon: <User size={24} />,
  },
  {
    step: "2",
    title: "AI Analysis",
    desc: "A browser-based rule score summarizes your answers. A separate synthetic-data model may be used when configured.",
    icon: <Brain size={24} />,
  },
  {
    step: "3",
    title: "Doctor Review",
    desc: "A dermatologist can review the report and recommend next steps.",
    icon: <Stethoscope size={24} />,
  },
  {
    step: "4",
    title: "Get Your Report",
    desc: "Review your screening summary, skin-specific recommendations, and follow-up guidance.",
    icon: <ClipboardList size={24} />,
  },
];

const cancerTypes = [
  { icon: <Sun size={20} className="text-orange-500" />, name: 'Skin Cancer', desc: 'Watch for spots that change, look different from other moles, or do not heal.' },
];

const warningSigns = [
  { sign: 'Asymmetry', detail: 'One half does not match the other.' },
  { sign: 'Irregular border or uneven colour', detail: 'Edges may be ragged or blurred; colour may include several shades.' },
  { sign: 'Diameter or evolving', detail: 'Larger than 6 mm or changing in size, shape, colour, or elevation.' },
  { sign: 'Elevated, firm, growing', detail: 'A raised, hard spot increasing in size over time.' },
  { sign: 'Ugly Duckling sign', detail: 'One spot looks noticeably different from your other moles.' },
  { sign: 'New or changing spot', detail: 'A sore that does not heal, or a spot that itches, crusts, or bleeds.' },
];
export default function AboutScreen({ onNavigate }: Props) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-border shadow-xs px-4 md:px-8 h-14 flex items-center justify-between">
        <Logo />
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate("intro")}
            data-ocid="about.back.button"
          >
            <ArrowLeft size={16} className="mr-1" /> Back
          </Button>
          <Button
            size="sm"
            onClick={() => onNavigate("auth")}
            className="bg-primary text-white hover:bg-primary/90"
            data-ocid="about.signin.button"
          >
            Sign In
          </Button>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/5 to-red-50 px-4 md:px-8 py-14 md:py-20 text-center">
        <div className="max-w-3xl mx-auto">
          <span className="inline-block bg-primary/10 text-primary text-xs font-semibold px-3 py-1 rounded-full mb-4">
            About DermaMind
          </span>
          <h1 className="text-3xl md:text-5xl font-bold leading-tight mb-4">
            Skin Warning Signs
            <br />
            <span className="text-primary">Screening Guide</span>
          </h1>
          <p className="text-muted-foreground text-lg mb-6 max-w-2xl mx-auto">
            DermaMind helps you review changing spots and moles with a transparent, rule-based screening summary. It is not a diagnosis or a substitute for a dermatologist.
          </p>
          <p className="text-xl font-bold text-primary">
            Screening aid only. See a dermatologist about changing or concerning spots.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="px-4 md:px-8 py-10 max-w-5xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {stats.map((s) => (
            <div
              key={s.value}
              className="bg-primary text-white rounded-2xl p-6 text-center"
            >
              <p className="text-3xl font-black mb-1">{s.value}</p>
              <p className="text-sm opacity-90 mb-1">{s.label}</p>
              <p className="text-xs opacity-70">Source: {s.source}</p>
            </div>
          ))}
        </div>
      </section>

      {/* What is cancer */}
      <section className="px-4 md:px-8 py-10 max-w-5xl mx-auto">
        <div className="bg-card rounded-2xl p-6 md:p-8 border border-border shadow-card">
          <h2 className="text-2xl font-bold mb-4">What is skin cancer?</h2>
          <p className="text-muted-foreground leading-relaxed mb-4">
            Skin cancer develops when abnormal cells grow in the skin. A new, changing, bleeding, or non-healing spot should be assessed by a qualified clinician.
          </p>
          <p className="text-muted-foreground leading-relaxed mb-4">
            The ABCDE and EFG warning signs and the Ugly Duckling sign can help people notice changes. They cannot confirm whether a spot is cancerous.
          </p>
          <p className="font-semibold text-foreground">
            If you notice a concerning change, arrange a professional skin examination.
          </p>
        </div>
      </section>

      {/* How it works */}
      <section className="px-4 md:px-8 py-10 max-w-5xl mx-auto">
        <h2 className="text-2xl font-bold mb-6 text-center">
          How DermaMind Works
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {howItWorks.map((h) => (
            <div
              key={h.step}
              className="bg-card rounded-xl p-5 shadow-card border border-border relative"
            >
              <div className="w-10 h-10 bg-primary/10 text-primary rounded-xl flex items-center justify-center mb-3">
                {h.icon}
              </div>
              <div className="absolute top-4 right-4 w-7 h-7 bg-primary text-white rounded-full text-xs font-bold flex items-center justify-center">
                {h.step}
              </div>
              <h3 className="font-semibold mb-2">{h.title}</h3>
              <p className="text-sm text-muted-foreground">{h.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Common cancer types */}
      <section className="px-4 md:px-8 py-10 bg-muted/30">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold mb-6 text-center">
            Skin cancer warning signs
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {cancerTypes.map((c) => (
              <div
                key={c.name}
                className="bg-card rounded-xl p-5 shadow-card border border-border"
              >
                <div className="mb-3">{c.icon}</div>
                <h3 className="font-semibold mb-2">{c.name}</h3>
                <p className="text-sm text-muted-foreground">{c.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Warning signs */}
      <section className="px-4 md:px-8 py-10 max-w-5xl mx-auto">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <AlertCircle size={22} className="text-primary" /> Warning Signs to
          Watch For
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {warningSigns.map((w) => (
            <div
              key={w.sign}
              className="flex items-start gap-3 bg-card rounded-xl p-4 border border-border shadow-card"
            >
              <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
              <div>
                <p className="font-semibold text-sm">{w.sign}</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {w.detail}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Technology */}
      <section className="px-4 md:px-8 py-10 max-w-5xl mx-auto">
        <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6 md:p-8">
          <h2 className="text-2xl font-bold mb-4">Our Technology</h2>
          <div className="grid md:grid-cols-3 gap-6 text-sm">
            <div>
              <p className="font-semibold mb-1">🤖 AI Risk Scoring</p>
              <p className="text-muted-foreground">
                A prototype rule-based score summarizes reported skin warning signs. It is not a probability or diagnosis.
              </p>
            </div>
            <div>
              <p className="font-semibold mb-1">👨‍⚕️ Doctor Collaboration</p>
              <p className="text-muted-foreground">
                Every screening summary should be reviewed by a dermatologist who adds
                clinical notes and personalized recommendations.
              </p>
            </div>
            <div>
              <p className="font-semibold mb-1">🔒 Privacy First</p>
              <p className="text-muted-foreground">
                All patient data is encrypted. Analytics are fully anonymized.
                Your health information remains private and secure.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 md:px-8 py-10 max-w-5xl mx-auto">
        <div className="bg-primary text-white rounded-2xl p-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-2">
            Ready to Screen?
          </h2>
          <p className="opacity-80 mb-6">
            Use this screening aid to review common skin warning signs.
          </p>
          <Button
            size="lg"
            onClick={() => onNavigate("auth")}
            className="bg-white text-primary hover:bg-white/90 font-bold"
            data-ocid="about.start_screening.button"
          >
            Start Your Screening <ChevronRight size={18} className="ml-1" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border px-4 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()}. Built with ❤️ using{" "}
        <a
          href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
          className="underline"
          target="_blank"
          rel="noreferrer"
        >
          caffeine.ai
        </a>
      </footer>
    </div>
  );
}
