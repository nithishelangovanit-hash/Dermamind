import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowLeft,
  Calendar,
  CheckCircle,
  Download,
  FileText,
  ImageIcon,
  MessageSquare,
  Microscope,
  Upload,
  Video,
  XCircle,
  ZoomIn,
} from "lucide-react";
import { useState } from "react";
import { usePatientStore } from "../context/PatientStore";
import type { Patient, Screen, TestFinding } from "../types";
import { generateClinicalReportPDF } from "../utils/generateClinicalPDF";
import { getRiskColors, getRiskLabel } from "../utils/riskScoring";

interface Props {
  onNavigate: (screen: Screen) => void;
  patient: Patient | null;
}

const testOptions = [
  "Dermatologist consultation",
  "Dermoscopy",
  "Skin biopsy (if advised by clinician)",
  "Mole mapping",
];

function summarizeUploadedFile(fileName: string): {
  findings: TestFinding[];
  summary: string;
} {
  return { findings: [], summary: `File "${fileName}" was uploaded. This prototype does not interpret files; please ask a dermatologist to review it.` };
}

const SPECIALTIES = ["Dermatologist"];
const TIME_SLOTS = [
  "9:00 AM",
  "10:00 AM",
  "11:00 AM",
  "12:00 PM",
  "1:00 PM",
  "2:00 PM",
  "3:00 PM",
  "4:00 PM",
  "5:00 PM",
];
const BOOKED_SLOTS = ["10:00 AM", "1:00 PM", "3:00 PM"];

function getNextSevenDays(): string[] {
  const days: string[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i + 1);
    days.push(
      d.toLocaleDateString("en-IN", {
        weekday: "short",
        month: "short",
        day: "numeric",
      }),
    );
  }
  return days;
}

export default function PatientReportView({ onNavigate, patient }: Props) {
  const { updatePatient } = usePatientStore();
  const [notes, setNotes] = useState("");
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [decision, setDecision] = useState<"approved" | "rejected" | null>(
    null,
  );

  // Test report upload state
  const [uploadedReports, setUploadedReports] = useState<
    { name: string; type: string; findings: TestFinding[]; summary: string }[]
  >([]);

  // Consultation state
  const [consultTab, setConsultTab] = useState("online");
  const [chatMessages, setChatMessages] = useState<
    { id: string; role: "doctor" | "ai"; text: string }[]
  >([
    {
      id: "init-1",
      role: "ai",
      text: "Hello Doctor, I am the AI assistant. How can I help you with this patient's case?",
    },
  ]);
  const [chatInput, setChatInput] = useState("");
  const [selectedSpecialty, setSelectedSpecialty] = useState(SPECIALTIES[0]);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  const [appointmentConfirmed, setAppointmentConfirmed] = useState(false);
  const [videoOpen, setVideoOpen] = useState(false);

  const p = patient;
  if (!p) {
    return (
      <div className="p-6 text-center" data-ocid="report.empty_state">
        <p className="text-muted-foreground">No patient selected.</p>
        <Button
          onClick={() => onNavigate("doctor-dashboard")}
          className="mt-4"
          data-ocid="report.back.button"
        >
          ← Back
        </Button>
      </div>
    );
  }

  const rc = getRiskColors(p.riskZone);
  const aiFindings = p.aiFindings || [];

  function toggleTest(t: string) {
    setSelectedTests((prev) =>
      prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t],
    );
  }

  function handleDownloadPDF() {
    if (!p) return;
    generateClinicalReportPDF(p, notes, selectedTests);
  }

  function handleApprove() {
    setDecision("approved");
    if (p)
      updatePatient(p.id, {
        status: "approved",
        doctorReviewed: true,
        consultationActive: p.riskZone === "red",
        doctorNotes: notes,
        recommendedTests: selectedTests,
      });
  }

  function handleReject() {
    setDecision("rejected");
    if (p)
      updatePatient(p.id, {
        status: "rejected",
        doctorReviewed: true,
        doctorNotes: notes,
        recommendedTests: selectedTests,
      });
  }

  function handleTestUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const parsed = summarizeUploadedFile(file.name);
    setUploadedReports((prev) => [
      ...prev,
      {
        name: file.name,
        type: "Dermatology file",
        ...parsed,
      },
    ]);
    e.target.value = "";
  }

  function sendChat() {
    if (!chatInput.trim()) return;
    const userMsg = chatInput.trim();
    setChatMessages((prev) => [
      ...prev,
      { id: `doc-${prev.length}`, role: "doctor", text: userMsg },
    ]);
    setChatInput("");
    setTimeout(() => {
      setChatMessages((prev) => [
        ...prev,
        {
          id: `ai-${prev.length}`,
          role: "ai",
          text: "Noted. Based on the patient's risk profile, I recommend immediate specialist review. Would you like me to summarize the key findings?",
        },
      ]);
    }, 800);
  }

  const showConsultation =
    p.riskZone === "red" &&
    (p.doctorReviewed === true || decision === "approved");

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onNavigate("doctor-dashboard")}
          data-ocid="report.back.button"
        >
          <ArrowLeft size={16} className="mr-1" /> Back
        </Button>
        <h1 className="text-xl font-bold">Patient Report</h1>
        <Button
          size="sm"
          onClick={handleDownloadPDF}
          className="ml-auto bg-primary hover:bg-primary/90 text-white"
          data-ocid="report.download_pdf.button"
        >
          <Download size={16} className="mr-2" /> Download Full Clinical Report
        </Button>
      </div>

      {/* Patient Info */}
      <div className="bg-card rounded-xl p-5 shadow-card border border-border">
        <h2 className="font-bold mb-4 flex items-center gap-2">
          <FileText size={16} className="text-primary" /> Patient Information
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Name</p>
            <p className="font-semibold">{p.name}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Age</p>
            <p className="font-semibold">{p.age} yrs</p>
          </div>
          <div>
            <p className="text-muted-foreground">Gender</p>
            <p className="font-semibold capitalize">{p.gender || "—"}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Phone</p>
            <p className="font-semibold">{p.phone || "—"}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Place</p>
            <p className="font-semibold">{p.place || "—"}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Submitted</p>
            <p className="font-semibold">{p.submittedAt}</p>
          </div>
        </div>

        {/* Lifestyle */}
        <div className="mt-4 border-t border-border pt-4">
          <h3 className="text-sm font-semibold text-muted-foreground mb-3">
            Lifestyle & Risk Factors
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Smoking</p>
              <p className="font-semibold capitalize">{p.smoking}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Alcohol</p>
              <p className="font-semibold capitalize">{p.alcohol}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Exposure</p>
              <div className="flex flex-wrap gap-1 mt-1">
                {p.exposure.length > 0 ? (
                  p.exposure.map((e) => (
                    <span
                      key={e}
                      className="bg-orange-100 text-orange-700 text-xs px-2 py-0.5 rounded-full"
                    >
                      {e}
                    </span>
                  ))
                ) : (
                  <span className="font-semibold text-muted-foreground">
                    None
                  </span>
                )}
              </div>
            </div>
            {p.existingDiseases && (
              <div className="col-span-2 md:col-span-3">
                <p className="text-muted-foreground">Existing Diseases</p>
                <p className="font-semibold">{p.existingDiseases}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Uploaded Image */}
      <div className="bg-card rounded-xl p-5 shadow-card border border-border">
        <h2 className="font-bold mb-4 flex items-center gap-2">
          <ImageIcon size={16} className="text-primary" /> Uploaded Image
        </h2>
        {p.imageBase64 ? (
          <div className="space-y-3">
            <img
              src={p.imageBase64}
              alt="Patient medical scan"
              className="w-full max-h-64 object-cover rounded-lg border border-border"
            />
            <Dialog>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  data-ocid="report.image_zoom.button"
                >
                  <ZoomIn size={14} /> View Full Size
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-3xl">
                <DialogHeader>
                  <DialogTitle>Uploaded Image — Full View</DialogTitle>
                </DialogHeader>
                <img
                  src={p.imageBase64}
                  alt="Patient medical scan full size"
                  className="w-full rounded-lg"
                />
              </DialogContent>
            </Dialog>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">
            No image uploaded by patient.
          </p>
        )}
      </div>

      {/* AI Risk Score */}
      <div className="bg-card rounded-xl p-5 shadow-card border border-border">
        <h2 className="font-bold mb-4">AI Risk Assessment</h2>
        <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
          <div
            className={`w-24 h-24 rounded-full flex flex-col items-center justify-center text-2xl font-black border-4 ${rc.border} ${rc.bg} ${rc.text}`}
          >
            {p.riskScore}
            <span className="text-xs font-normal">/100</span>
          </div>
          <div className="flex-1">
            <span
              className={`inline-flex px-3 py-1 rounded-full text-sm font-bold ${rc.bg} ${rc.text} mb-3`}
            >
              {getRiskLabel(p.riskZone)}
            </span>
            <div className="space-y-2 text-sm">
              <p className="text-muted-foreground">
                <span className="font-medium text-foreground">
                  Contributing symptoms:
                </span>{" "}
                {p.symptoms.join(", ") || "None reported"}
              </p>
              <p className="text-muted-foreground">
                <span className="font-medium text-foreground">
                  Risk factors:
                </span>{" "}
                {p.riskFactors.join(", ") || "None reported"}
              </p>
              {p.confidenceScore !== undefined && (
                <div className="mt-2">
                  <p className="text-xs text-muted-foreground mb-1">
                    AI Confidence Score
                  </p>
                  <div className="flex items-center gap-2">
                    <Progress
                      value={p.confidenceScore}
                      className="h-2 flex-1"
                    />
                    <span className="text-xs font-semibold text-foreground">
                      {p.confidenceScore}%
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* AI Findings */}
      <div className="bg-card rounded-xl p-5 shadow-card border border-border">
        <h2 className="font-bold mb-4 flex items-center gap-2">
          <span className="text-primary">🧠</span> AI Findings
        </h2>
        <ul className="space-y-2">
          {aiFindings.map((finding, i) => (
            <li
              key={finding}
              className="flex items-start gap-2 text-sm"
              data-ocid={`report.ai_finding.item.${i + 1}`}
            >
              <span className="text-primary mt-0.5 font-bold">•</span>
              <span>{finding}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Symptoms Table */}
      <div className="bg-card rounded-xl shadow-card border border-border">
        <div className="p-4 border-b border-border">
          <h2 className="font-bold">Symptom Breakdown</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm" data-ocid="report.symptoms.table">
            <thead>
              <tr className="bg-muted/30">
                <th className="text-left p-3 text-muted-foreground font-medium">
                  Symptom
                </th>
                <th className="text-left p-3 text-muted-foreground font-medium">
                  Duration
                </th>
                <th className="text-left p-3 text-muted-foreground font-medium">
                  Intensity
                </th>
                <th className="text-left p-3 text-muted-foreground font-medium">
                  Trend
                </th>
              </tr>
            </thead>
            <tbody>
              {p.symptomData &&
              p.symptomData.filter((s) => s.present).length > 0 ? (
                p.symptomData
                  .filter((s) => s.present)
                  .map((s, i) => (
                    <tr
                      key={s.name}
                      className="border-t border-border"
                      data-ocid={`report.symptom.item.${i + 1}`}
                    >
                      <td className="p-3 font-medium">{s.name}</td>
                      <td className="p-3 text-muted-foreground">
                        {s.duration}
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded text-xs font-medium ${
                            s.intensity === "High"
                              ? "bg-red-100 text-red-700"
                              : s.intensity === "Medium"
                                ? "bg-yellow-100 text-yellow-700"
                                : "bg-green-100 text-green-700"
                          }`}
                        >
                          {s.intensity}
                        </span>
                      </td>
                      <td className="p-3 text-muted-foreground">{s.trend}</td>
                    </tr>
                  ))
              ) : (
                <tr>
                  <td
                    colSpan={4}
                    className="p-4 text-center text-muted-foreground text-sm"
                  >
                    No symptoms reported
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Doctor Actions */}
      <div
        className="bg-card rounded-xl p-5 shadow-card border border-border space-y-5"
        data-ocid="report.doctor_actions.panel"
      >
        <h2 className="font-bold">Doctor Actions</h2>

        <div>
          <Label className="mb-2 block">Clinical Notes</Label>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add clinical notes and observations..."
            rows={4}
            data-ocid="report.notes.textarea"
          />
        </div>

        <div>
          <Label className="mb-3 block">Recommended Tests</Label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {testOptions.map((t, i) => (
              <label
                key={t}
                className="flex items-center gap-2 p-2 rounded-lg border border-border cursor-pointer hover:bg-muted/40"
                data-ocid={`report.test.checkbox.${i + 1}`}
              >
                <input
                  type="checkbox"
                  checked={selectedTests.includes(t)}
                  onChange={() => toggleTest(t)}
                  className="w-4 h-4 accent-primary"
                />
                <span className="text-xs font-medium">{t}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="flex gap-3">
          <Button
            onClick={handleApprove}
            className={`flex-1 ${
              decision === "approved"
                ? "bg-green-600 hover:bg-green-700"
                : "bg-green-500 hover:bg-green-600"
            } text-white`}
            data-ocid="report.approve.button"
          >
            <CheckCircle size={16} className="mr-2" /> Approve
          </Button>
          <Button
            onClick={handleReject}
            className={`flex-1 ${
              decision === "rejected"
                ? "bg-red-700 hover:bg-red-800"
                : "bg-primary hover:bg-primary/90"
            } text-white`}
            data-ocid="report.reject.button"
          >
            <XCircle size={16} className="mr-2" /> Reject
          </Button>
        </div>
        {decision && (
          <div
            className={`rounded-lg p-3 text-sm font-medium ${
              decision === "approved"
                ? "bg-green-50 text-green-700"
                : "bg-red-50 text-red-700"
            }`}
            data-ocid={`report.decision.${decision}_state`}
          >
            ✓ Case {decision === "approved" ? "approved" : "rejected"}{" "}
            successfully.
          </div>
        )}
      </div>

      {/* ======================== SECTION A: Structured Clinical AI Report ======================== */}
      <div
        className="bg-card rounded-xl p-5 shadow-card border border-border space-y-4"
        data-ocid="report.clinical_report.panel"
      >
        <div className="flex items-center justify-between">
          <h2 className="font-bold flex items-center gap-2">
            <FileText size={16} className="text-primary" />📋 Structured
            Clinical Report (AI Generated)
          </h2>
          <Button
            size="sm"
            variant="outline"
            onClick={handleDownloadPDF}
            className="gap-2"
            data-ocid="report.clinical_report_pdf.button"
          >
            <Download size={14} /> Download Full Clinical Report
          </Button>
        </div>

        {p.structuredReport ? (
          <div className="space-y-5">
            {/* Report header */}
            <div className="flex flex-wrap items-start gap-3 p-4 bg-muted/30 rounded-lg">
              <div className="flex-1 min-w-0">
                <p className="text-xs text-muted-foreground">Patient</p>
                <p className="font-semibold">{p.name}</p>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-muted-foreground">Generated</p>
                <p className="font-semibold text-sm">
                  {new Date(p.structuredReport.generatedAt).toLocaleString(
                    "en-IN",
                  )}
                </p>
              </div>
              <div>
                <Badge
                  className={`${
                    p.riskZone === "red"
                      ? "bg-red-100 text-red-700 border-red-200"
                      : p.riskZone === "yellow"
                        ? "bg-yellow-100 text-yellow-700 border-yellow-200"
                        : "bg-green-100 text-green-700 border-green-200"
                  } capitalize`}
                >
                  {p.structuredReport.riskZone} zone
                </Badge>
              </div>
            </div>

            {/* Positive Symptoms */}
            {p.structuredReport.symptoms.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold mb-2 text-foreground">
                  Positive Symptoms
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm border rounded-lg overflow-hidden">
                    <thead>
                      <tr className="bg-primary/5">
                        <th className="text-left p-2.5 font-medium text-muted-foreground">
                          Symptom
                        </th>
                        <th className="text-left p-2.5 font-medium text-muted-foreground">
                          Duration
                        </th>
                        <th className="text-left p-2.5 font-medium text-muted-foreground">
                          Intensity
                        </th>
                        <th className="text-left p-2.5 font-medium text-muted-foreground">
                          Trend
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {p.structuredReport.symptoms.map((s, i) => (
                        <tr
                          key={s.name}
                          className={i % 2 === 0 ? "" : "bg-muted/20"}
                        >
                          <td className="p-2.5 font-medium">{s.name}</td>
                          <td className="p-2.5 text-muted-foreground">
                            {s.duration}
                          </td>
                          <td className="p-2.5">
                            <span
                              className={`px-2 py-0.5 rounded text-xs font-medium ${
                                s.intensity === "High"
                                  ? "bg-red-100 text-red-700"
                                  : s.intensity === "Medium"
                                    ? "bg-yellow-100 text-yellow-700"
                                    : "bg-green-100 text-green-700"
                              }`}
                            >
                              {s.intensity}
                            </span>
                          </td>
                          <td className="p-2.5 text-muted-foreground">
                            {s.trend}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Risk Factors */}
            <div>
              <h3 className="text-sm font-semibold mb-2">Risk Factors</h3>
              <div className="flex flex-wrap gap-2">
                {p.structuredReport.riskFactors.length > 0 ? (
                  p.structuredReport.riskFactors.map((rf) => (
                    <Badge
                      key={rf}
                      variant="outline"
                      className="bg-orange-50 text-orange-700 border-orange-200"
                    >
                      {rf}
                    </Badge>
                  ))
                ) : (
                  <span className="text-sm text-muted-foreground">
                    No risk factors reported
                  </span>
                )}
              </div>
            </div>

            {/* Image Findings */}
            <div>
              <h3 className="text-sm font-semibold mb-2">
                Image Findings (ABCDE Rule)
              </h3>
              <p className="text-sm text-muted-foreground bg-muted/30 rounded-lg p-3">
                {p.structuredReport.imageFindings}
              </p>
            </div>

            {/* AI Recommendation */}
            <div>
              <h3 className="text-sm font-semibold mb-2">AI Recommendation</h3>
              <div
                className={`p-4 rounded-lg border-l-4 text-sm font-medium ${
                  p.riskZone === "red"
                    ? "bg-red-50 border-red-500 text-red-800"
                    : p.riskZone === "yellow"
                      ? "bg-yellow-50 border-yellow-500 text-yellow-800"
                      : "bg-green-50 border-green-500 text-green-800"
                }`}
              >
                {p.structuredReport.recommendation}
              </div>
            </div>

            {/* Confidence Score */}
            <div>
              <h3 className="text-sm font-semibold mb-2">
                AI Confidence Score
              </h3>
              <div className="flex items-center gap-3">
                <Progress
                  value={p.structuredReport.confidenceScore}
                  className="h-3 flex-1"
                />
                <span className="text-sm font-bold w-12 text-right">
                  {p.structuredReport.confidenceScore}%
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {p.structuredReport.confidenceScore < 40
                  ? "Low confidence — single symptom detected"
                  : p.structuredReport.confidenceScore < 70
                    ? "Moderate confidence — multiple symptoms considered"
                    : "High confidence — comprehensive symptom profile analyzed"}
              </p>
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground italic">
            Report will be available after next assessment
          </p>
        )}
      </div>

      {/* ======================== SECTION B: Medical Test Report Analysis ======================== */}
      <div
        className="bg-card rounded-xl p-5 shadow-card border border-border space-y-4"
        data-ocid="report.test_analysis.panel"
      >
        <div className="flex items-center justify-between">
          <h2 className="font-bold flex items-center gap-2">
            <Microscope size={16} className="text-primary" />🔬 Medical Test
            Report Analysis
          </h2>
          {uploadedReports.length > 0 && (
            <Button
              size="sm"
              variant="outline"
              onClick={handleDownloadPDF}
              className="gap-2"
              data-ocid="report.test_analysis_pdf.button"
            >
              <Download size={14} /> Download Full Clinical Report
            </Button>
          )}
        </div>

        <p className="text-sm text-muted-foreground">
          Upload skin photos or pathology/dermoscopy reports for clinician review. Files are not analyzed by this prototype.
        </p>

        <label
          className="flex items-center gap-3 border-2 border-dashed border-border rounded-xl p-5 cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-colors"
          data-ocid="report.test_report.dropzone"
        >
          <Upload size={24} className="text-muted-foreground shrink-0" />
          <div>
            <p className="font-medium text-sm">Click to upload test reports</p>
            <p className="text-xs text-muted-foreground">
              Skin images and dermatology reports (PDF or image files)
            </p>
          </div>
          <input
            type="file"
            accept=".pdf,image/*"
            className="sr-only"
            onChange={handleTestUpload}
            data-ocid="report.test_report.upload_button"
          />
        </label>

        {uploadedReports.length === 0 && (
          <p
            className="text-sm text-center text-muted-foreground"
            data-ocid="report.test_analysis.empty_state"
          >
            No reports uploaded yet.
          </p>
        )}

        {uploadedReports.map((rep) => (
          <div
            key={rep.name}
            className="border border-border rounded-xl overflow-hidden"
          >
            <div className="bg-muted/30 px-4 py-2.5 flex items-center gap-2">
              <FileText size={14} className="text-primary" />
              <span className="font-medium text-sm">{rep.name}</span>
              <Badge variant="outline" className="ml-auto text-xs">
                {rep.type}
              </Badge>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/20">
                    <th className="text-left p-3 text-muted-foreground font-medium">
                      Parameter
                    </th>
                    <th className="text-left p-3 text-muted-foreground font-medium">
                      Value
                    </th>
                    <th className="text-left p-3 text-muted-foreground font-medium">
                      Reference Range
                    </th>
                    <th className="text-left p-3 text-muted-foreground font-medium">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rep.findings.map((f) => (
                    <tr
                      key={f.parameter}
                      className={`border-t border-border ${f.isAbnormal ? "bg-red-50/50" : ""}`}
                    >
                      <td className="p-3 font-medium">{f.parameter}</td>
                      <td
                        className={`p-3 font-semibold ${f.isAbnormal ? "text-red-600" : "text-green-700"}`}
                      >
                        {f.value}
                      </td>
                      <td className="p-3 text-muted-foreground text-xs">
                        {f.referenceRange}
                      </td>
                      <td className="p-3">
                        {f.isAbnormal ? (
                          <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">
                            ⚠ Abnormal
                          </Badge>
                        ) : (
                          <Badge className="bg-green-100 text-green-700 border-green-200 text-xs">
                            ✓ Normal
                          </Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-blue-50/50 border-t border-border">
              <p className="text-xs font-semibold text-blue-800 mb-1">
                Simulated AI Findings Summary
              </p>
              <p className="text-xs text-blue-700">{rep.summary}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ======================== SECTION C: Consultation System (RED ZONE ONLY) ======================== */}
      {showConsultation && (
        <div
          className="bg-card rounded-xl p-5 shadow-card border-2 border-red-300 space-y-4"
          data-ocid="report.consultation.panel"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center shrink-0">
              <span className="text-red-600 text-lg">🏥</span>
            </div>
            <div>
              <h2 className="font-bold">Consultation & Appointment System</h2>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                <p className="text-xs text-red-600 font-semibold">
                  Red Zone Patient — Consultation Required
                </p>
              </div>
            </div>
          </div>

          <Tabs
            value={consultTab}
            onValueChange={setConsultTab}
            data-ocid="report.consultation.tab"
          >
            <TabsList className="w-full">
              <TabsTrigger
                value="online"
                className="flex-1 gap-2"
                data-ocid="report.consultation_online.tab"
              >
                <Video size={14} /> Online Consultation
              </TabsTrigger>
              <TabsTrigger
                value="appointment"
                className="flex-1 gap-2"
                data-ocid="report.consultation_appointment.tab"
              >
                <Calendar size={14} /> Book Appointment
              </TabsTrigger>
            </TabsList>

            {/* Online Consultation Tab */}
            <TabsContent value="online" className="space-y-4 mt-4">
              {/* Video Consultation */}
              <div className="border border-border rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <Video size={16} className="text-primary" />
                  <h3 className="font-semibold text-sm">Video Consultation</h3>
                </div>
                <Dialog open={videoOpen} onOpenChange={setVideoOpen}>
                  <DialogTrigger asChild>
                    <Button
                      className="bg-primary hover:bg-primary/90 text-white gap-2"
                      data-ocid="report.video_consultation.button"
                    >
                      <Video size={16} /> Start Video Session
                    </Button>
                  </DialogTrigger>
                  <DialogContent data-ocid="report.video_consultation.dialog">
                    <DialogHeader>
                      <DialogTitle>Video Consultation</DialogTitle>
                    </DialogHeader>
                    <div className="flex flex-col items-center justify-center gap-4 py-8 bg-gray-900 rounded-xl">
                      <div className="w-20 h-20 rounded-full bg-gray-700 flex items-center justify-center">
                        <Video size={32} className="text-white/60" />
                      </div>
                      <p className="text-white/70 text-sm text-center">
                        Video session would launch here
                        <br />
                        (integration pending)
                      </p>
                      <div className="flex gap-2">
                        <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                        <span className="text-xs text-white/50">
                          Ready to connect
                        </span>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => setVideoOpen(false)}
                      data-ocid="report.video_consultation.close_button"
                    >
                      Close
                    </Button>
                  </DialogContent>
                </Dialog>
              </div>

              {/* Chat */}
              <div className="border border-border rounded-xl overflow-hidden">
                <div className="bg-muted/30 px-4 py-2.5 flex items-center gap-2">
                  <MessageSquare size={14} className="text-primary" />
                  <h3 className="font-semibold text-sm">Consultation Chat</h3>
                </div>
                <div className="h-52 overflow-y-auto p-4 space-y-3 bg-white">
                  {chatMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.role === "doctor" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${
                          msg.role === "doctor"
                            ? "bg-primary text-white rounded-br-none"
                            : "bg-muted text-foreground rounded-bl-none"
                        }`}
                      >
                        {msg.role === "ai" && (
                          <p className="text-xs opacity-60 mb-0.5 font-medium">
                            AI Assistant
                          </p>
                        )}
                        {msg.text}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="border-t border-border p-3 flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && sendChat()}
                    placeholder="Type a message..."
                    className="flex-1 text-sm border border-border rounded-lg px-3 py-2 outline-none focus:ring-1 focus:ring-primary"
                    data-ocid="report.consultation_chat.input"
                  />
                  <Button
                    size="sm"
                    className="bg-primary hover:bg-primary/90 text-white"
                    onClick={sendChat}
                    data-ocid="report.consultation_chat_send.button"
                  >
                    Send
                  </Button>
                </div>
              </div>
            </TabsContent>

            {/* Book Appointment Tab */}
            <TabsContent value="appointment" className="space-y-4 mt-4">
              {/* Specialty */}
              <div>
                <Label className="mb-2 block text-sm">Doctor Specialty</Label>
                <div className="flex gap-2 flex-wrap">
                  {SPECIALTIES.map((sp) => (
                    <button
                      key={sp}
                      type="button"
                      onClick={() => setSelectedSpecialty(sp)}
                      className={`px-4 py-2 rounded-lg border text-sm font-medium transition-colors ${
                        selectedSpecialty === sp
                          ? "bg-primary text-white border-primary"
                          : "border-border hover:border-primary/50"
                      }`}
                      data-ocid="report.appointment_specialty.button"
                    >
                      {sp}
                    </button>
                  ))}
                </div>
              </div>

              {/* Date */}
              <div>
                <Label className="mb-2 block text-sm">Select Date</Label>
                <div className="flex gap-2 flex-wrap">
                  {getNextSevenDays().map((day, i) => (
                    <button
                      key={day}
                      type="button"
                      onClick={() => setSelectedDate(day)}
                      className={`px-3 py-2 rounded-lg border text-xs font-medium transition-colors ${
                        selectedDate === day
                          ? "bg-primary text-white border-primary"
                          : "border-border hover:border-primary/50"
                      }`}
                      data-ocid={`report.appointment_date.button.${i + 1}`}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              </div>

              {/* Time Slots */}
              <div>
                <Label className="mb-2 block text-sm">Time Slot</Label>
                <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
                  {TIME_SLOTS.map((slot, i) => {
                    const isBooked = BOOKED_SLOTS.includes(slot);
                    const isSelected = selectedSlot === slot;
                    return (
                      <button
                        key={slot}
                        type="button"
                        disabled={isBooked}
                        onClick={() => !isBooked && setSelectedSlot(slot)}
                        className={`py-2 px-2 rounded-lg border text-xs font-medium transition-colors ${
                          isBooked
                            ? "bg-muted text-muted-foreground border-border cursor-not-allowed opacity-50"
                            : isSelected
                              ? "bg-primary text-white border-primary"
                              : "border-border hover:border-primary/50"
                        }`}
                        data-ocid={`report.appointment_slot.button.${i + 1}`}
                      >
                        {slot}
                        {isBooked && (
                          <span className="block text-[10px] opacity-70">
                            Booked
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {appointmentConfirmed ? (
                <div
                  className="p-4 bg-green-50 border border-green-200 rounded-xl text-sm text-green-700 font-medium"
                  data-ocid="report.appointment.success_state"
                >
                  ✅ Appointment confirmed with {selectedSpecialty} on{" "}
                  {selectedDate} at {selectedSlot}.<br />
                  <span className="text-xs font-normal">
                    Connected with lab test workflow and doctor recommendation
                    system.
                  </span>
                </div>
              ) : (
                <Button
                  className="bg-primary hover:bg-primary/90 text-white w-full"
                  disabled={!selectedDate || !selectedSlot}
                  onClick={() => setAppointmentConfirmed(true)}
                  data-ocid="report.appointment_confirm.button"
                >
                  Confirm Appointment
                </Button>
              )}
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
}
