import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Activity, CheckCircle, Clock, Inbox, Users } from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { usePatientStore } from "../context/PatientStore";
import type { Patient, Screen } from "../types";
import { getRiskColors, getRiskLabel } from "../utils/riskScoring";

interface Props {
  onNavigate: (screen: Screen) => void;
  onSelectPatient: (patient: Patient) => void;
}

const RISK_COLORS: Record<string, string> = {
  High: "#E53935",
  Medium: "#FFC107",
  Low: "#4CAF50",
};

const STATUS_COLORS: Record<string, string> = {
  Pending: "#FFC107",
  Approved: "#4CAF50",
  Rejected: "#90A4AE",
};

export default function DoctorDashboard({
  onNavigate,
  onSelectPatient,
}: Props) {
  const { patients } = usePatientStore();

  const pending = patients.filter((p) => p.status === "pending");
  const highRisk = patients.filter((p) => p.riskZone === "red");
  const approved = patients.filter((p) => p.status === "approved");

  const kpis = [
    {
      label: "Pending Review",
      value: String(pending.length),
      icon: <Clock size={20} className="text-yellow-500" />,
      sub: "Awaiting review",
    },
    {
      label: "High Risk",
      value: String(highRisk.length),
      icon: <Activity size={20} className="text-primary" />,
      sub: "Score ≥ 80",
    },
    {
      label: "Approved",
      value: String(approved.length),
      icon: <CheckCircle size={20} className="text-green-500" />,
      sub: "Reviewed & approved",
    },
    {
      label: "Total Patients",
      value: String(patients.length),
      icon: <Users size={20} className="text-blue-500" />,
      sub: "All submissions",
    },
  ];

  // Chart A: Risk distribution donut
  const riskPieData = [
    {
      name: "High",
      value: patients.filter((p) => p.riskZone === "red").length,
    },
    {
      name: "Medium",
      value: patients.filter((p) => p.riskZone === "yellow").length,
    },
    {
      name: "Low",
      value: patients.filter((p) => p.riskZone === "green").length,
    },
  ];

  // Chart B: Patient status bar
  const statusBarData = [
    { name: "Pending", count: pending.length },
    { name: "Approved", count: approved.length },
    {
      name: "Rejected",
      count: patients.filter((p) => p.status === "rejected").length,
    },
  ];

  // Chart C: Age group analysis
  const ageGroups: Record<
    string,
    { high: number; medium: number; low: number }
  > = {
    "0–20": { high: 0, medium: 0, low: 0 },
    "21–40": { high: 0, medium: 0, low: 0 },
    "41–60": { high: 0, medium: 0, low: 0 },
    "61+": { high: 0, medium: 0, low: 0 },
  };
  for (const p of patients) {
    const grp =
      p.age <= 20
        ? "0–20"
        : p.age <= 40
          ? "21–40"
          : p.age <= 60
            ? "41–60"
            : "61+";
    if (p.riskZone === "red") ageGroups[grp].high += 1;
    else if (p.riskZone === "yellow") ageGroups[grp].medium += 1;
    else ageGroups[grp].low += 1;
  }
  const ageBarData = Object.entries(ageGroups).map(([group, counts]) => ({
    group,
    ...counts,
  }));

  // Chart D: Weekly submission trend
  const weekMap: Record<string, number> = {};
  for (const p of patients) {
    const d = new Date(p.submittedAt);
    const week = `W${Math.ceil(d.getDate() / 7)} ${d.toLocaleString("default", { month: "short" })}`;
    weekMap[week] = (weekMap[week] || 0) + 1;
  }
  const trendData = Object.entries(weekMap)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([week, count]) => ({ week, count }));

  function handleReview(p: Patient) {
    onSelectPatient(p);
    onNavigate("patient-report");
  }

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Doctor Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Review and manage patient screenings
        </p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((k, i) => (
          <div
            key={k.label}
            className="bg-card rounded-xl p-4 shadow-card border border-border"
            data-ocid={`doctor.kpi.item.${i + 1}`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground font-medium">
                {k.label}
              </span>
              {k.icon}
            </div>
            <p className="text-2xl font-bold">{k.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{k.sub}</p>
          </div>
        ))}
      </div>

      {/* ─────────────── Clinical Analytics ─────────────── */}
      <div>
        <div className="mb-4">
          <h2 className="text-lg font-bold">Clinical Analytics</h2>
          <p className="text-sm text-muted-foreground">
            Real-time patient data overview
          </p>
        </div>

        {patients.length === 0 ? (
          <div
            className="bg-card rounded-xl p-12 border border-border text-center"
            data-ocid="doctor.analytics.empty_state"
          >
            <Inbox
              size={48}
              className="text-muted-foreground/40 mx-auto mb-4"
            />
            <p className="font-semibold text-muted-foreground">
              No patient data yet.
            </p>
            <p className="text-sm text-muted-foreground/70 mt-1">
              Analytics will populate as patients submit assessments.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Chart A — Risk Distribution Donut */}
            <div className="bg-card rounded-xl p-5 shadow-card border border-border">
              <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary inline-block" />
                Risk Distribution
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={riskPieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      dataKey="value"
                      paddingAngle={3}
                      label={({ name, percent }) =>
                        percent > 0.05
                          ? `${name} ${Math.round(percent * 100)}%`
                          : ""
                      }
                      labelLine={false}
                    >
                      {riskPieData.map((entry) => (
                        <Cell key={entry.name} fill={RISK_COLORS[entry.name]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend iconSize={10} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart B — Review Status Breakdown */}
            <div className="bg-card rounded-xl p-5 shadow-card border border-border">
              <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-yellow-500 inline-block" />
                Review Status Breakdown
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={statusBarData}
                    margin={{ top: 10, right: 10, bottom: 10, left: 0 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="var(--border)"
                    />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 11 }}
                      width={28}
                    />
                    <Tooltip />
                    <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                      {statusBarData.map((entry) => (
                        <Cell
                          key={entry.name}
                          fill={STATUS_COLORS[entry.name]}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart C — Age Group Analysis */}
            <div className="bg-card rounded-xl p-5 shadow-card border border-border">
              <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500 inline-block" />
                Age Group Analysis
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={ageBarData}
                    margin={{ top: 10, right: 10, bottom: 10, left: 0 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="var(--border)"
                    />
                    <XAxis dataKey="group" tick={{ fontSize: 12 }} />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 11 }}
                      width={28}
                    />
                    <Tooltip />
                    <Legend iconSize={10} />
                    <Bar
                      dataKey="high"
                      stackId="a"
                      fill="#E53935"
                      name="High"
                      radius={[0, 0, 0, 0]}
                    />
                    <Bar
                      dataKey="medium"
                      stackId="a"
                      fill="#FFC107"
                      name="Medium"
                      radius={[0, 0, 0, 0]}
                    />
                    <Bar
                      dataKey="low"
                      stackId="a"
                      fill="#4CAF50"
                      name="Low"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart D — Submission Trends */}
            <div className="bg-card rounded-xl p-5 shadow-card border border-border">
              <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 inline-block" />
                Submission Trends
              </h3>
              <div className="h-64">
                {trendData.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-sm text-muted-foreground">
                    No trend data available yet
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={trendData}
                      margin={{ top: 5, right: 10, bottom: 5, left: 0 }}
                    >
                      <defs>
                        <linearGradient
                          id="trendGrad"
                          x1="0"
                          y1="0"
                          x2="0"
                          y2="1"
                        >
                          <stop
                            offset="5%"
                            stopColor="#E53935"
                            stopOpacity={0.3}
                          />
                          <stop
                            offset="95%"
                            stopColor="#E53935"
                            stopOpacity={0.02}
                          />
                        </linearGradient>
                      </defs>
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="var(--border)"
                      />
                      <XAxis dataKey="week" tick={{ fontSize: 10 }} />
                      <YAxis
                        allowDecimals={false}
                        tick={{ fontSize: 11 }}
                        width={28}
                      />
                      <Tooltip />
                      <Area
                        type="monotone"
                        dataKey="count"
                        stroke="#E53935"
                        strokeWidth={2}
                        fill="url(#trendGrad)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Patient table with tabs */}
      <div className="bg-card rounded-xl shadow-card border border-border">
        <div className="p-4 border-b border-border">
          <h2 className="font-semibold">Patient Submissions</h2>
        </div>
        {patients.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-16 text-center"
            data-ocid="doctor.patients.empty_state"
          >
            <Inbox size={48} className="text-muted-foreground/40 mb-4" />
            <p className="font-semibold text-muted-foreground">
              No patient submissions yet.
            </p>
            <p className="text-sm text-muted-foreground/70 mt-1">
              Patient assessments will appear here once submitted.
            </p>
          </div>
        ) : (
          <Tabs defaultValue="all" className="p-4">
            <TabsList className="mb-4" data-ocid="doctor.patients.tab">
              <TabsTrigger value="all">All ({patients.length})</TabsTrigger>
              <TabsTrigger value="pending">
                Pending ({pending.length})
              </TabsTrigger>
              <TabsTrigger value="high-risk">
                High Risk ({highRisk.length})
              </TabsTrigger>
              <TabsTrigger value="approved">
                Approved ({approved.length})
              </TabsTrigger>
            </TabsList>
            {(["all", "pending", "high-risk", "approved"] as const).map(
              (tab) => {
                const data =
                  tab === "all"
                    ? patients
                    : tab === "pending"
                      ? pending
                      : tab === "high-risk"
                        ? highRisk
                        : approved;
                return (
                  <TabsContent key={tab} value={tab}>
                    <PatientTable patients={data} onReview={handleReview} />
                  </TabsContent>
                );
              },
            )}
          </Tabs>
        )}
      </div>
    </div>
  );
}

function PatientTable({
  patients,
  onReview,
}: { patients: Patient[]; onReview: (p: Patient) => void }) {
  if (patients.length === 0) {
    return (
      <div
        className="py-8 text-center text-sm text-muted-foreground"
        data-ocid="doctor.tab.empty_state"
      >
        No patients in this category.
      </div>
    );
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" data-ocid="doctor.patients.table">
        <thead>
          <tr className="border-b border-border bg-muted/30">
            <th className="text-left p-3 font-medium text-muted-foreground">
              Patient
            </th>
            <th className="text-left p-3 font-medium text-muted-foreground">
              Date
            </th>
            <th className="text-left p-3 font-medium text-muted-foreground">
              Risk Score
            </th>
            <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">
              Place
            </th>
            <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">
              Symptoms
            </th>
            <th className="text-left p-3 font-medium text-muted-foreground">
              Status
            </th>
            <th className="text-left p-3 font-medium text-muted-foreground">
              Action
            </th>
          </tr>
        </thead>
        <tbody>
          {patients.map((p, i) => {
            const rc = getRiskColors(p.riskZone);
            return (
              <tr
                key={p.id}
                className="border-b border-border last:border-0 hover:bg-muted/20"
                data-ocid={`doctor.patient.item.${i + 1}`}
              >
                <td className="p-3">
                  <div className="font-medium">{p.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {p.age}y · {p.phone || "—"}
                  </div>
                </td>
                <td className="p-3 text-muted-foreground">{p.submittedAt}</td>
                <td className="p-3">
                  <span
                    className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold ${rc.bg} ${rc.text}`}
                  >
                    {p.riskScore} · {getRiskLabel(p.riskZone)}
                  </span>
                </td>
                <td className="p-3 text-muted-foreground hidden md:table-cell text-xs">
                  {p.place || "—"}
                </td>
                <td className="p-3 text-muted-foreground hidden md:table-cell text-xs">
                  {p.symptoms.join(", ") || "None"}
                </td>
                <td className="p-3">
                  <span
                    className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${
                      p.status === "approved"
                        ? "bg-green-100 text-green-700"
                        : p.status === "pending"
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-blue-100 text-blue-700"
                    }`}
                  >
                    {p.status}
                  </span>
                </td>
                <td className="p-3">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onReview(p)}
                    className="text-primary border-primary/40 hover:bg-primary/5"
                    data-ocid={`doctor.review.button.${i + 1}`}
                  >
                    Review
                  </Button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
