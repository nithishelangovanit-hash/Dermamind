import { AlertTriangle, Brain, FileText, Inbox, Users } from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { usePatientStore } from "../context/PatientStore";
import { getRiskLabel } from "../utils/riskScoring";

const PIE_COLORS = ["#E53935", "#FFC107", "#4CAF50"];

export default function AdminDashboard() {
  const { patients } = usePatientStore();

  const totalUsers = patients.length;
  const totalReports = patients.length;
  const highRiskCount = patients.filter((p) => p.riskZone === "red").length;

  const kpis = [
    {
      label: "Total Users",
      value: String(totalUsers),
      icon: <Users size={20} className="text-blue-500" />,
      sub: "Patient accounts",
    },
    {
      label: "Total Reports",
      value: String(totalReports),
      icon: <FileText size={20} className="text-purple-500" />,
      sub: "All submissions",
    },
    {
      label: "High Risk Cases",
      value: String(highRiskCount),
      icon: <AlertTriangle size={20} className="text-primary" />,
      sub: "Need immediate review",
    },
    {
      label: "AI Accuracy",
      value: "91%",
      icon: <Brain size={20} className="text-green-500" />,
      sub: "Based on doctor feedback",
    },
  ];

  // Pie chart: risk distribution
  const riskDistData = [
    {
      name: "High Risk",
      value: patients.filter((p) => p.riskZone === "red").length,
    },
    {
      name: "Medium Risk",
      value: patients.filter((p) => p.riskZone === "yellow").length,
    },
    {
      name: "Low Risk",
      value: patients.filter((p) => p.riskZone === "green").length,
    },
  ];

  // Scatter: age vs risk score
  const scatterData = patients.map((p) => ({ age: p.age, score: p.riskScore }));

  // Bar chart: symptom frequency
  const symptomFreq: Record<string, number> = {};
  for (const p of patients) {
    for (const s of p.symptoms) {
      symptomFreq[s] = (symptomFreq[s] || 0) + 1;
    }
  }
  const symptomBarData = Object.entries(symptomFreq)
    .map(([symptom, count]) => ({ symptom: symptom.replace(" ", "\n"), count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  // Line chart: monthly trends
  const monthMap: Record<string, number> = {};
  for (const p of patients) {
    const d = new Date(p.submittedAt);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    monthMap[key] = (monthMap[key] || 0) + 1;
  }
  const lineData = Object.entries(monthMap)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, count]) => ({ month, count }));

  // Chart E: Location distribution (horizontal bar)
  const locationMap: Record<string, number> = {};
  for (const p of patients) {
    const loc = p.place || "Unknown";
    locationMap[loc] = (locationMap[loc] || 0) + 1;
  }
  const locationData = Object.entries(locationMap)
    .map(([place, count]) => ({ place, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  // Chart F: Risk trend by month (stacked area)
  const riskMonthMap: Record<
    string,
    { high: number; medium: number; low: number }
  > = {};
  for (const p of patients) {
    const d = new Date(p.submittedAt);
    const key = d.toLocaleString("default", {
      month: "short",
      year: "2-digit",
    });
    if (!riskMonthMap[key]) riskMonthMap[key] = { high: 0, medium: 0, low: 0 };
    if (p.riskZone === "red") riskMonthMap[key].high += 1;
    else if (p.riskZone === "yellow") riskMonthMap[key].medium += 1;
    else riskMonthMap[key].low += 1;
  }
  const stackedAreaData = Object.entries(riskMonthMap)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, counts]) => ({ month, ...counts }));

  const isEmpty = patients.length === 0;

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          System analytics and patient overview
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((k, i) => (
          <div
            key={k.label}
            className="bg-card rounded-xl p-4 shadow-card border border-border"
            data-ocid={`admin.kpi.item.${i + 1}`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground font-medium">
                {k.label}
              </span>
              {k.icon}
            </div>
            <p className="text-2xl font-bold">{k.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{k.sub}</p>
          </div>
        ))}
      </div>

      {isEmpty ? (
        <div
          className="bg-card rounded-xl p-12 border border-border text-center"
          data-ocid="admin.charts.empty_state"
        >
          <Inbox size={48} className="text-muted-foreground/40 mx-auto mb-4" />
          <p className="font-semibold text-muted-foreground">No data yet.</p>
          <p className="text-sm text-muted-foreground/70 mt-1">
            Patient submissions will appear here once users complete
            assessments.
          </p>
        </div>
      ) : (
        <>
          {/* ─── Existing 4 charts ─── */}
          <div>
            <div className="mb-4">
              <h2 className="text-lg font-bold">Core Analytics</h2>
              <p className="text-sm text-muted-foreground">
                Aggregate patient data overview
              </p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Pie Chart */}
              <div className="bg-card rounded-xl p-5 shadow-card border border-border">
                <h2 className="font-bold text-base mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-primary inline-block" />
                  Risk Level Distribution
                </h2>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={riskDistData}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        dataKey="value"
                        label={({ name, percent }) =>
                          `${name} ${Math.round(percent * 100)}%`
                        }
                        labelLine={false}
                      >
                        {riskDistData.map((_, index) => (
                          <Cell
                            key={PIE_COLORS[index]}
                            fill={PIE_COLORS[index % PIE_COLORS.length]}
                          />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Scatter Plot */}
              <div className="bg-card rounded-xl p-5 shadow-card border border-border">
                <h2 className="font-bold text-base mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500 inline-block" />
                  Age vs Risk Score
                </h2>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart
                      margin={{ top: 10, right: 20, bottom: 20, left: 10 }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="var(--border)"
                      />
                      <XAxis
                        dataKey="age"
                        name="Age"
                        type="number"
                        domain={["auto", "auto"]}
                        label={{
                          value: "Age",
                          position: "insideBottom",
                          offset: -10,
                          fontSize: 11,
                        }}
                      />
                      <YAxis
                        dataKey="score"
                        name="Score"
                        domain={[0, 100]}
                        label={{
                          value: "Score",
                          angle: -90,
                          position: "insideLeft",
                          fontSize: 11,
                        }}
                      />
                      <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                      <Scatter data={scatterData} fill="#E53935" />
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Bar Chart */}
              <div className="bg-card rounded-xl p-5 shadow-card border border-border">
                <h2 className="font-bold text-base mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-orange-500 inline-block" />
                  Symptom Frequency
                </h2>
                <div className="h-64">
                  {symptomBarData.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-sm text-muted-foreground">
                      No symptom data
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={symptomBarData}
                        margin={{ bottom: 30, left: 0, right: 10, top: 10 }}
                      >
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke="var(--border)"
                        />
                        <XAxis
                          dataKey="symptom"
                          tick={{ fontSize: 10 }}
                          interval={0}
                          angle={-30}
                          textAnchor="end"
                          height={50}
                        />
                        <YAxis
                          allowDecimals={false}
                          tick={{ fontSize: 11 }}
                          width={30}
                        />
                        <Tooltip />
                        <Bar
                          dataKey="count"
                          fill="#E53935"
                          radius={[4, 4, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>

              {/* Line Chart */}
              <div className="bg-card rounded-xl p-5 shadow-card border border-border">
                <h2 className="font-bold text-base mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-500 inline-block" />
                  Monthly Report Trends
                </h2>
                <div className="h-64">
                  {lineData.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-sm text-muted-foreground">
                      No monthly data
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={lineData}
                        margin={{ top: 10, right: 20, bottom: 10, left: 0 }}
                      >
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke="var(--border)"
                        />
                        <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                        <YAxis
                          allowDecimals={false}
                          tick={{ fontSize: 11 }}
                          width={30}
                        />
                        <Tooltip />
                        <Line
                          type="monotone"
                          dataKey="count"
                          stroke="#E53935"
                          strokeWidth={2}
                          dot={{ fill: "#E53935" }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* ─── New 2 charts ─── */}
          <div>
            <div className="mb-4">
              <h2 className="text-lg font-bold">Extended Analytics</h2>
              <p className="text-sm text-muted-foreground">
                Geographic and temporal risk insights
              </p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Chart E — Location Distribution */}
              <div className="bg-card rounded-xl p-5 shadow-card border border-border">
                <h2 className="font-bold text-base mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-600 inline-block" />
                  Patient Location Distribution
                </h2>
                <div className="h-72">
                  {locationData.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-sm text-muted-foreground">
                      No location data
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={locationData}
                        layout="vertical"
                        margin={{ top: 5, right: 30, bottom: 5, left: 60 }}
                      >
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke="var(--border)"
                        />
                        <XAxis
                          type="number"
                          allowDecimals={false}
                          tick={{ fontSize: 11 }}
                        />
                        <YAxis
                          type="category"
                          dataKey="place"
                          tick={{ fontSize: 11 }}
                          width={55}
                        />
                        <Tooltip />
                        <Bar
                          dataKey="count"
                          fill="#7C3AED"
                          radius={[0, 4, 4, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>

              {/* Chart F — Risk Trends Over Time (stacked area) */}
              <div className="bg-card rounded-xl p-5 shadow-card border border-border">
                <h2 className="font-bold text-base mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-primary inline-block" />
                  Risk Trends Over Time
                </h2>
                <div className="h-72">
                  {stackedAreaData.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-sm text-muted-foreground">
                      No trend data
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={stackedAreaData}
                        margin={{ top: 5, right: 10, bottom: 5, left: 0 }}
                      >
                        <defs>
                          <linearGradient
                            id="highGrad"
                            x1="0"
                            y1="0"
                            x2="0"
                            y2="1"
                          >
                            <stop
                              offset="5%"
                              stopColor="#E53935"
                              stopOpacity={0.5}
                            />
                            <stop
                              offset="95%"
                              stopColor="#E53935"
                              stopOpacity={0.05}
                            />
                          </linearGradient>
                          <linearGradient
                            id="medGrad"
                            x1="0"
                            y1="0"
                            x2="0"
                            y2="1"
                          >
                            <stop
                              offset="5%"
                              stopColor="#FFC107"
                              stopOpacity={0.5}
                            />
                            <stop
                              offset="95%"
                              stopColor="#FFC107"
                              stopOpacity={0.05}
                            />
                          </linearGradient>
                          <linearGradient
                            id="lowGrad"
                            x1="0"
                            y1="0"
                            x2="0"
                            y2="1"
                          >
                            <stop
                              offset="5%"
                              stopColor="#4CAF50"
                              stopOpacity={0.5}
                            />
                            <stop
                              offset="95%"
                              stopColor="#4CAF50"
                              stopOpacity={0.05}
                            />
                          </linearGradient>
                        </defs>
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke="var(--border)"
                        />
                        <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                        <YAxis
                          allowDecimals={false}
                          tick={{ fontSize: 11 }}
                          width={28}
                        />
                        <Tooltip />
                        <Legend iconSize={10} />
                        <Area
                          type="monotone"
                          dataKey="high"
                          stackId="1"
                          stroke="#E53935"
                          fill="url(#highGrad)"
                          name="High"
                        />
                        <Area
                          type="monotone"
                          dataKey="medium"
                          stackId="1"
                          stroke="#FFC107"
                          fill="url(#medGrad)"
                          name="Medium"
                        />
                        <Area
                          type="monotone"
                          dataKey="low"
                          stackId="1"
                          stroke="#4CAF50"
                          fill="url(#lowGrad)"
                          name="Low"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Patient Overview Table */}
      <div className="bg-card rounded-xl shadow-card border border-border">
        <div className="p-4 border-b border-border">
          <h2 className="font-bold text-base">Patient Overview</h2>
          <p className="text-xs text-muted-foreground mt-1">
            Summary data only — restricted access
          </p>
        </div>
        {isEmpty ? (
          <div
            className="py-12 text-center text-sm text-muted-foreground"
            data-ocid="admin.patients.empty_state"
          >
            No patient data available yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm" data-ocid="admin.patients.table">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="text-left p-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Patient ID
                  </th>
                  <th className="text-left p-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Name
                  </th>
                  <th className="text-left p-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Phone
                  </th>
                  <th className="text-left p-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Place
                  </th>
                  <th className="text-left p-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Risk Factor
                  </th>
                  <th className="text-left p-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Reports
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {patients.map((p, i) => {
                  const riskLabel = getRiskLabel(p.riskZone);
                  const badgeClass =
                    p.riskZone === "red"
                      ? "bg-red-100 text-red-700"
                      : p.riskZone === "yellow"
                        ? "bg-yellow-100 text-yellow-700"
                        : "bg-green-100 text-green-700";
                  return (
                    <tr
                      key={p.id}
                      className="hover:bg-muted/20 transition-colors"
                      data-ocid={`admin.patient.row.${i + 1}`}
                    >
                      <td className="p-3 font-mono text-xs font-semibold">
                        {p.id}
                      </td>
                      <td className="p-3 font-medium">{p.name}</td>
                      <td className="p-3 text-muted-foreground">{p.phone}</td>
                      <td className="p-3 text-muted-foreground">
                        {p.place || "—"}
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${badgeClass}`}
                        >
                          {riskLabel}
                        </span>
                      </td>
                      <td className="p-3 text-center">1</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <footer className="border-t border-border pt-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()}. Built with ❤️ using{" "}
        <a
          href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
          className="underline"
          target="_blank"
          rel="noreferrer"
        >
          caffeine.ai
        </a>
      </footer>
    </div>
  );
}
