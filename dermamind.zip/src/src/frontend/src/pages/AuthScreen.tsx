import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import Logo from "../components/Logo";
import type { Role, Screen, User } from "../types";

interface AuthScreenProps {
  onNavigate: (screen: Screen) => void;
  onLogin: (user: User) => void;
}

export default function AuthScreen({ onNavigate, onLogin }: AuthScreenProps) {
  const [role, setRole] = useState<Role>("patient");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const displayName =
      name ||
      (role === "doctor"
        ? "Dr. Ananya Rao"
        : role === "admin"
          ? "Admin User"
          : "Rahul Sharma");
    onLogin({
      name: displayName,
      email: email || `${role}@dermamind.app`,
      role,
    });
    const dest: Screen =
      role === "patient"
        ? "patient-dashboard"
        : role === "doctor"
          ? "doctor-dashboard"
          : "admin-dashboard";
    onNavigate(dest);
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="bg-card border-b border-border px-6 h-14 flex items-center shadow-xs">
        <button
          type="button"
          onClick={() => onNavigate("intro")}
          data-ocid="auth.back.button"
        >
          <Logo />
        </button>
      </header>

      <div className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="bg-card rounded-2xl shadow-card border border-border p-8">
            <h2 className="text-2xl font-bold mb-1">Welcome to DermaMind</h2>
            <p className="text-sm text-muted-foreground mb-6">
              AI-powered early cancer detection
            </p>

            <Tabs defaultValue="login">
              <TabsList className="w-full mb-6">
                <TabsTrigger
                  value="login"
                  className="flex-1"
                  data-ocid="auth.login.tab"
                >
                  Log In
                </TabsTrigger>
                <TabsTrigger
                  value="signup"
                  className="flex-1"
                  data-ocid="auth.signup.tab"
                >
                  Sign Up
                </TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <RoleSelector role={role} setRole={setRole} />
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="mt-1"
                      data-ocid="auth.email.input"
                    />
                  </div>
                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="mt-1"
                      data-ocid="auth.password.input"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90 text-white"
                    data-ocid="auth.login.submit_button"
                  >
                    Log In
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <RoleSelector role={role} setRole={setRole} />
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      placeholder="Your name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="mt-1"
                      data-ocid="auth.name.input"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email2">Email</Label>
                    <Input
                      id="email2"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="mt-1"
                      data-ocid="auth.signup_email.input"
                    />
                  </div>
                  <div>
                    <Label htmlFor="password2">Password</Label>
                    <Input
                      id="password2"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="mt-1"
                      data-ocid="auth.signup_password.input"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90 text-white"
                    data-ocid="auth.signup.submit_button"
                  >
                    Create Account
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}

function RoleSelector({
  role,
  setRole,
}: { role: Role; setRole: (r: Role) => void }) {
  const roleOptions: { value: Role; label: string; desc: string }[] = [
    { value: "patient", label: "Patient", desc: "Submit screening" },
    { value: "doctor", label: "Doctor", desc: "Review reports" },
    { value: "admin", label: "Admin", desc: "Analytics" },
  ];
  return (
    <div>
      <Label className="mb-2 block">I am a</Label>
      <div className="grid grid-cols-3 gap-2">
        {roleOptions.map((r) => (
          <button
            key={r.value}
            type="button"
            onClick={() => setRole(r.value)}
            data-ocid={`auth.role_${r.value}.toggle`}
            className={`rounded-lg border p-3 text-left transition-all ${
              role === r.value
                ? "border-primary bg-primary/5 text-primary"
                : "border-border hover:border-primary/50"
            }`}
          >
            <div className="font-semibold text-sm">{r.label}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{r.desc}</div>
          </button>
        ))}
      </div>
    </div>
  );
}
