import { Button } from "@/components/ui/button";
import {
  AlertCircle,
  ChevronRight,
  Heart,
  Shield,
  Sun,
  Wind,
} from "lucide-react";
import Logo from "../components/Logo";
import type { Screen } from "../types";

interface IntroScreenProps {
  onNavigate: (screen: Screen) => void;
}

const cancerTypes = [
  { icon: <Sun size={24} className="text-orange-500" />, name: 'Skin Cancer', desc: 'Check for changing spots and moles using the ABCDE and EFG warning signs.' },
];
const warningSigns = [
  'A spot with asymmetry, an irregular border, or uneven colour',
  'A spot larger than 6 mm or changing in size, shape, colour, or elevation',
  'A raised, firm spot that is growing',
  'One mole that looks different from the others',
  'A sore that does not heal, or a spot that itches, crusts, or bleeds',
  'A new or changing dark mark under a nail, on a palm, sole, ear, lip, or scalp',
];
const riskFactors = ['UV or radiation exposure', 'Family history of skin cancer', 'History of severe sunburn', 'Many or unusual moles'];
const prevention = ['Use sun protection', 'Check your skin for changes', 'Avoid tanning beds', 'See a dermatologist about changing spots'];
const keyStats = [
  { value: 'A–E', label: 'ABCDE warning sign checklist', source: 'Screening guide' },
  { value: 'E–F–G', label: 'Elevated, Firm, Growing', source: 'Screening guide' },
  { value: 'One spot', label: 'Notice the Ugly Duckling sign', source: 'Screening guide' },
];
export default function IntroScreen({ onNavigate }: IntroScreenProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-border shadow-xs px-4 md:px-8 h-14 flex items-center justify-between">
        <Logo />
        <Button
          variant="outline"
          size="sm"
          onClick={() => onNavigate("auth")}
          data-ocid="intro.login.button"
        >
          Sign In
        </Button>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/5 to-red-50 px-4 md:px-8 py-16 md:py-24 text-center">
        <div className="max-w-3xl mx-auto">
          <span className="inline-block bg-primary/10 text-primary text-xs font-semibold px-3 py-1 rounded-full mb-4">
            Skin Screening Guide
          </span>
          <h1 className="text-3xl md:text-5xl font-bold text-foreground leading-tight mb-4">
            Skin Cancer Warning Signs
            <br />
            <span className="text-primary">Know What to Watch For</span>
          </h1>
          <p className="text-muted-foreground text-lg mb-3 max-w-xl mx-auto">
            Learn to notice changes in spots and moles. Screening helps you know when to contact a dermatologist; it does not diagnose skin cancer.
          </p>
          <p className="text-primary font-semibold text-base mb-8">
            Screening aid only. This tool does not diagnose skin cancer.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              size="lg"
              onClick={() => onNavigate("auth")}
              className="bg-primary hover:bg-primary/90"
              data-ocid="intro.start_screening.button"
            >
              Start Screening <ChevronRight size={18} className="ml-1" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => onNavigate("about")}
              data-ocid="intro.learn_more.button"
            >
              Learn About DermaMind
            </Button>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="bg-primary px-4 md:px-8 py-6">
        <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-4">
          {keyStats.map((s) => (
            <div key={s.value} className="text-white text-center">
              <p className="text-2xl md:text-3xl font-black">{s.value}</p>
              <p className="text-sm opacity-90 mt-0.5">{s.label}</p>
              <p className="text-xs opacity-60">Source: {s.source}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Skin cancer warning signs */}
      <section className="px-4 md:px-8 py-12 max-w-5xl mx-auto">
        <h2 className="text-2xl font-bold mb-6 text-center">
          Skin cancer warning signs
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {cancerTypes.map((c) => (
            <div
              key={c.name}
              className="bg-card rounded-xl p-5 shadow-card border border-border"
            >
              <div className="mb-3">{c.icon}</div>
              <h3 className="font-semibold mb-1">{c.name}</h3>
              <p className="text-sm text-muted-foreground">{c.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Warning signs + risk factors + prevention */}
      <section className="px-4 md:px-8 py-8 max-w-5xl mx-auto">
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-card rounded-xl p-5 shadow-card border border-border">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <AlertCircle size={18} className="text-primary" /> Warning Signs
            </h3>
            <ul className="space-y-2">
              {warningSigns.map((s) => (
                <li
                  key={s}
                  className="flex items-start gap-2 text-sm text-muted-foreground"
                >
                  <span className="w-1.5 h-1.5 bg-primary rounded-full mt-1.5 flex-shrink-0" />
                  {s}
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-card rounded-xl p-5 shadow-card border border-border">
            <h3 className="font-bold mb-4">⚠️ Risk Factors</h3>
            <ul className="space-y-2">
              {riskFactors.map((r) => (
                <li
                  key={r}
                  className="flex items-start gap-2 text-sm text-muted-foreground"
                >
                  <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full mt-1.5 flex-shrink-0" />
                  {r}
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-card rounded-xl p-5 shadow-card border border-border">
            <h3 className="font-bold mb-4">✅ Prevention</h3>
            <ul className="space-y-2">
              {prevention.map((p) => (
                <li
                  key={p}
                  className="flex items-start gap-2 text-sm text-muted-foreground"
                >
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full mt-1.5 flex-shrink-0" />
                  {p}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Callout */}
      <section className="px-4 md:px-8 py-8 max-w-5xl mx-auto">
        <div className="bg-primary text-white rounded-2xl p-8 text-center">
          <p className="text-2xl md:text-3xl font-bold">
            Screening aid only. It does not diagnose skin cancer.
          </p>
          <p className="mt-3 opacity-80">
            Don't wait. Check your skin and contact a dermatologist about changing spots.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center mt-6">
            <Button
              size="lg"
              onClick={() => onNavigate("auth")}
              className="bg-white text-primary hover:bg-white/90 font-bold"
              data-ocid="intro.hero_cta.button"
            >
              Begin Free Screening
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => onNavigate("about")}
              className="border-white text-white hover:bg-white/10"
              data-ocid="intro.learn_about.button"
            >
              Learn About DermaMind
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border px-4 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()}. Built with ❤️ using{" "}
        <a
          href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
          className="underline"
          target="_blank"
          rel="noreferrer"
        >
          caffeine.ai
        </a>
      </footer>
    </div>
  );
}
