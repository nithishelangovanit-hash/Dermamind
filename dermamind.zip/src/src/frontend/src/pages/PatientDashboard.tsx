import { Button } from "@/components/ui/button";
import { Bell, Calendar, ClipboardList, Inbox, MapPin } from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  RadialBar,
  RadialBarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { usePatientStore } from "../context/PatientStore";
import type { Screen, User } from "../types";

interface PatientDashboardProps {
  onNavigate: (screen: Screen) => void;
  user: User;
}

const SYMPTOM_LABELS: Record<string, string> = {
  asymmetry: "Asymmetry",
  "irregular-border": "Irregular border",
  "uneven-color": "Uneven color",
  evolving: "Evolving spot",
  "skin-change": "Skin Change",
  bleeding: "Bleeding",
  lump: "Lump",
  "night-sweats": "Night Sweats",
};

export default function PatientDashboard({
  onNavigate,
  user,
}: PatientDashboardProps) {
  const { patients } = usePatientStore();
  const mySubmissions = patients.filter((p) => p.userId === user.email);

  const kpis = [
    {
      label: "Assessments",
      value: String(mySubmissions.length),
      icon: <ClipboardList size={20} className="text-primary" />,
      sub: "Total submitted",
    },
    {
      label: "Next Reminder",
      value: "3 months",
      icon: <Calendar size={20} className="text-green-500" />,
      sub: "Follow-up due Jun 2026",
    },
  ];

  const reminders = [
    { title: "Annual Mammography", due: "Due in 3 months", icon: "🩺" },
    { title: "Blood Test (CBC)", due: "Due in 6 months", icon: "🧪" },
    { title: "Doctor Consultation", due: "Due in 1 month", icon: "👨\u200d⚕️" },
  ];

  const statusLabel = (s: string) => {
    if (s === "approved") return "Approved";
    if (s === "rejected") return "Completed";
    return "Under Review";
  };

  const statusStyle = (s: string) => {
    if (s === "approved") return "bg-green-100 text-green-700";
    if (s === "rejected") return "bg-slate-100 text-slate-600";
    return "bg-blue-100 text-blue-700";
  };

  // --- Analytics data derivation ---

  // Chart A: monthly assessment activity
  const monthMap: Record<string, number> = {};
  for (const p of mySubmissions) {
    const d = new Date(p.submittedAt);
    const key = d.toLocaleString("default", {
      month: "short",
      year: "2-digit",
    });
    monthMap[key] = (monthMap[key] || 0) + 1;
  }
  const activityData = Object.entries(monthMap)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, count]) => ({ month, count }));

  // Chart B: symptom frequency
  const symFreq: Record<string, number> = {};
  for (const p of mySubmissions) {
    for (const s of p.symptoms) {
      symFreq[s] = (symFreq[s] || 0) + 1;
    }
  }
  const symData = Object.entries(symFreq)
    .map(([key, count]) => ({ name: SYMPTOM_LABELS[key] || key, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);

  // Chart C: wellness radial
  const healthScore = Math.min(100, mySubmissions.length * 20 + 40);
  const radialData = [
    {
      name: "Health Score",
      value: healthScore,
      fill: "#2196F3",
    },
    {
      name: "Reminders Active",
      value: 30,
      fill: "#4CAF50",
    },
    {
      name: "Assessments Done",
      value: Math.min(100, mySubmissions.length * 10),
      fill: "#E53935",
    },
  ];

  // Chart D: status breakdown
  const underReview = mySubmissions.filter(
    (p) => p.status === "pending",
  ).length;
  const approvedCount = mySubmissions.filter(
    (p) => p.status === "approved",
  ).length;
  const completedCount = mySubmissions.filter(
    (p) => p.status === "rejected",
  ).length;
  const statusPieData = [
    { name: "Under Review", value: underReview },
    { name: "Approved", value: approvedCount },
    { name: "Completed", value: completedCount },
  ].filter((d) => d.value > 0);
  const STATUS_COLORS = ["#FFC107", "#4CAF50", "#90A4AE"];

  const hasSubmissions = mySubmissions.length > 0;

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">
            Hello, {user.name.split(" ")[0]} 👋
          </h1>
          <p className="text-sm text-muted-foreground">Your health dashboard</p>
        </div>
        <Button
          onClick={() => onNavigate("assessment")}
          className="bg-primary hover:bg-primary/90 text-white"
          data-ocid="patient.start_assessment.button"
        >
          <ClipboardList size={16} className="mr-2" /> Start Assessment
        </Button>
      </div>

      {/* KPI cards */}
      <div
        className="grid grid-cols-1 sm:grid-cols-2 gap-4"
        data-ocid="patient.kpi.panel"
      >
        {kpis.map((k, i) => (
          <div
            key={k.label}
            className="bg-card rounded-xl p-5 shadow-card border border-border"
            data-ocid={`patient.kpi.item.${i + 1}`}
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-muted-foreground font-medium">
                {k.label}
              </span>
              {k.icon}
            </div>
            <p className="text-2xl font-bold">{k.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{k.sub}</p>
          </div>
        ))}
      </div>

      {/* ───────────── Health Analytics ───────────── */}
      <div>
        <div className="mb-4">
          <h2 className="text-lg font-bold">Your Health Analytics</h2>
          <p className="text-sm text-muted-foreground">
            Track your screening journey
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Chart A — Assessment Activity */}
          <div
            className="bg-card rounded-xl p-5 shadow-card border border-border"
            data-ocid="patient.analytics.panel"
          >
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-primary inline-block" />
              Assessment Activity
            </h3>
            <div className="h-56">
              {activityData.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center gap-2">
                  <span className="text-3xl">📈</span>
                  <p className="text-sm text-muted-foreground">
                    Complete your first assessment to see your activity trend!
                  </p>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={activityData}
                    margin={{ top: 5, right: 10, bottom: 5, left: 0 }}
                  >
                    <defs>
                      <linearGradient id="actGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop
                          offset="5%"
                          stopColor="#E53935"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="95%"
                          stopColor="#E53935"
                          stopOpacity={0.02}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="var(--border)"
                    />
                    <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 11 }}
                      width={25}
                    />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="count"
                      stroke="#E53935"
                      strokeWidth={2}
                      fill="url(#actGrad)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Chart B — Symptom Frequency */}
          <div className="bg-card rounded-xl p-5 shadow-card border border-border">
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-orange-500 inline-block" />
              Your Reported Symptoms
            </h3>
            <div className="h-56">
              {symData.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center gap-2">
                  <span className="text-3xl">🩺</span>
                  <p className="text-sm text-muted-foreground">
                    No symptom data yet. Submit an assessment to get started.
                  </p>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={symData}
                    margin={{ top: 5, right: 10, bottom: 30, left: 0 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="var(--border)"
                    />
                    <XAxis
                      dataKey="name"
                      tick={{ fontSize: 10 }}
                      interval={0}
                      angle={-30}
                      textAnchor="end"
                      height={50}
                    />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 11 }}
                      width={25}
                    />
                    <Tooltip />
                    <Bar dataKey="count" fill="#E53935" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Chart C — Wellness Overview */}
          <div className="bg-card rounded-xl p-5 shadow-card border border-border">
            <h3 className="font-semibold text-sm mb-1 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-500 inline-block" />
              Wellness Overview
            </h3>
            <p className="text-xs text-muted-foreground mb-3">
              Your personal wellness metrics
            </p>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <RadialBarChart
                  innerRadius="25%"
                  outerRadius="90%"
                  data={radialData}
                  startAngle={180}
                  endAngle={0}
                >
                  <RadialBar
                    dataKey="value"
                    cornerRadius={6}
                    background={{ fill: "var(--muted)" }}
                    label={{
                      position: "insideStart",
                      fill: "#fff",
                      fontSize: 10,
                    }}
                  />
                  <Legend
                    iconSize={10}
                    layout="vertical"
                    verticalAlign="middle"
                    align="right"
                    formatter={(value) => (
                      <span style={{ fontSize: 10 }}>{value}</span>
                    )}
                  />
                  <Tooltip formatter={(val) => [`${val}%`, ""]} />
                </RadialBarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart D — Submission Status */}
          <div className="bg-card rounded-xl p-5 shadow-card border border-border">
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-yellow-500 inline-block" />
              Submission Status
            </h3>
            <div className="h-56">
              {!hasSubmissions ? (
                <div className="h-full flex flex-col items-center justify-center text-center gap-2">
                  <span className="text-3xl">📋</span>
                  <p className="text-sm text-muted-foreground">
                    Submit an assessment to track your status breakdown.
                  </p>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusPieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={75}
                      dataKey="value"
                      paddingAngle={3}
                      label={({ name, percent }) =>
                        percent > 0.05
                          ? `${name} ${Math.round(percent * 100)}%`
                          : ""
                      }
                      labelLine={false}
                    >
                      {statusPieData.map((_, idx) => (
                        <Cell
                          key={STATUS_COLORS[idx % STATUS_COLORS.length]}
                          fill={STATUS_COLORS[idx % STATUS_COLORS.length]}
                        />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend iconSize={10} />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Recent submissions */}
      <div className="bg-card rounded-xl shadow-card border border-border">
        <div className="p-4 border-b border-border">
          <h2 className="font-semibold">Recent Submissions</h2>
        </div>
        {mySubmissions.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-12 text-center"
            data-ocid="patient.submissions.empty_state"
          >
            <Inbox size={40} className="text-muted-foreground/40 mb-3" />
            <p className="text-sm text-muted-foreground">
              No submissions yet. Start your first assessment!
            </p>
            <Button
              size="sm"
              onClick={() => onNavigate("assessment")}
              className="mt-3 bg-primary text-white hover:bg-primary/90"
            >
              Start Assessment
            </Button>
          </div>
        ) : (
          <div>
            <div
              className="mx-4 mt-4 mb-2 flex items-start gap-3 bg-blue-50 border border-blue-200 rounded-lg p-3"
              data-ocid="patient.review_status.success_state"
            >
              <span className="text-blue-500 text-lg leading-none">ℹ️</span>
              <p className="text-sm text-blue-700 font-medium">
                Your report has been successfully submitted and is under medical
                review.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="text-left p-3 font-medium text-muted-foreground">
                      Date
                    </th>
                    <th className="text-left p-3 font-medium text-muted-foreground">
                      Symptoms
                    </th>
                    <th className="text-left p-3 font-medium text-muted-foreground">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {mySubmissions.map((p, i) => (
                    <tr
                      key={p.id}
                      className="border-b border-border last:border-0"
                      data-ocid={`patient.submission.item.${i + 1}`}
                    >
                      <td className="p-3 text-muted-foreground">
                        {p.submittedAt}
                      </td>
                      <td className="p-3">
                        {p.symptoms.length > 0
                          ? `${p.symptoms.length} symptom${
                              p.symptoms.length !== 1 ? "s" : ""
                            }`
                          : "None reported"}
                      </td>
                      <td className="p-3">
                        <span
                          className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${statusStyle(p.status)}`}
                        >
                          {statusLabel(p.status)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Health reminders */}
      <div className="bg-card rounded-xl shadow-card border border-border">
        <div className="p-4 border-b border-border flex items-center gap-2">
          <Bell size={16} className="text-primary" />
          <h2 className="font-semibold">Health Reminders</h2>
        </div>
        <div className="p-4 space-y-3">
          {reminders.map((r, i) => (
            <div
              key={r.title}
              className="flex items-center gap-3 p-3 bg-muted/40 rounded-lg"
              data-ocid={`patient.reminder.item.${i + 1}`}
            >
              <span className="text-xl">{r.icon}</span>
              <div>
                <p className="text-sm font-medium">{r.title}</p>
                <p className="text-xs text-muted-foreground">{r.due}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Labs CTA */}
      <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-primary">Your Recommended Tests</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Dermatologist consultation, dermoscopy, or biopsy if clinically advised
          </p>
        </div>
        <Button
          onClick={() => onNavigate("lab-recommendations")}
          variant="outline"
          className="border-primary text-primary hover:bg-primary/10"
          data-ocid="patient.find_labs.button"
        >
          <MapPin size={16} className="mr-2" /> Find Nearby Labs
        </Button>
      </div>
    </div>
  );
}
