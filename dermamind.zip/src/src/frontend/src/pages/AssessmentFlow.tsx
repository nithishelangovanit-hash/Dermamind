import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle, Info, Loader2, MapPin, Upload } from "lucide-react";
import { useState } from "react";
import { usePatientStore } from "../context/PatientStore";
import type { Patient, Screen, SymptomData, User } from "../types";
import {
  generateAIFindings,
  generateStructuredClinicalReport,
} from "../utils/aiFindings";
import { calculateRiskWithConfidence, getRiskZone } from "../utils/riskScoring";

interface Props {
  onNavigate: (screen: Screen) => void;
  user: User;
}

const STEPS = [
  "Patient Info",
  "Symptoms",
  "Risk Factors",
  "Image Upload",
  "Reports",
  "Review & Submit",
];

const symptomsConfig = [
  { name: "Asymmetry", group: "Skin", explanation: "One half of a spot does not match the other." },
  { name: "Irregular border", group: "Skin", explanation: "Edges are uneven, blurred, or poorly defined." },
  { name: "Uneven color", group: "Skin", explanation: "A spot contains multiple shades or colors." },
  { name: "Diameter over 6 mm", group: "Skin", explanation: "A spot is larger than about 6 mm; smaller spots can still need review." },
  { name: "Evolving spot", group: "Skin", explanation: "A spot changes in size, shape, color, or elevation." },
  { name: "Elevated spot", group: "Skin", explanation: "A spot is raised above the surrounding skin." },
  { name: "Firm spot", group: "Skin", explanation: "A raised spot feels firm or hard." },
  { name: "Growing spot", group: "Skin", explanation: "A spot continues to increase in size." },
  { name: "Ugly Duckling spot", group: "Skin", explanation: "One spot looks different from your other spots or moles." },
  { name: "Bleeding spot", group: "Skin", explanation: "A spot bleeds without a clear injury or repeatedly bleeds." },
  { name: "Itching spot", group: "Skin", explanation: "A spot has persistent or new itching." },
  { name: "Crusting spot", group: "Skin", explanation: "A spot repeatedly crusts or forms a scab." },
  { name: "Non-healing sore", group: "Skin", explanation: "A sore does not heal or repeatedly returns." },
  { name: "New spot", group: "Skin", explanation: "A new or unusual spot has appeared." },
  { name: "Changing mole", group: "Skin", explanation: "A mole has changed since you last checked it." },
  { name: "Dark nail mark", group: "Skin", explanation: "A new or changing dark line or mark is under a nail." },
  { name: "Palm or sole mark", group: "Skin", explanation: "A new or changing spot is on a palm or sole." },
  { name: "Ear or lip spot", group: "Skin", explanation: "A new or changing spot is on an ear or lip." },
  { name: "Scalp spot", group: "Skin", explanation: "A new or changing spot is on the scalp." },
  { name: "Red or pink growth", group: "Skin", explanation: "A new pink or red growth is present." },
  { name: "Pearly bump", group: "Skin", explanation: "A new shiny or pearly bump is present." },
  { name: "Sore after sun exposure", group: "Skin", explanation: "A persistent sore is present on sun-exposed skin." },
  { name: "Rough or scaly patch", group: "Skin", explanation: "A persistent rough, scaly, or crusted patch is present." },
  { name: "Tender spot", group: "Skin", explanation: "A spot is newly tender or painful." },
  { name: "Multiple changing spots", group: "Skin", explanation: "More than one spot has changed recently." },
];

const riskFactorsList = [
  "Smoking history",
  "Family history of cancer",
  "Recent weight loss",
  "Chronic fatigue",
];

const EXPOSURE_OPTIONS = ["Pollution", "Chemicals", "Radiation", "Dust"];

const DURATION_OPTIONS = [
  "1 week",
  "2 weeks",
  "3 weeks",
  "4 weeks",
  "5 weeks",
  "6 weeks",
  "7 weeks",
  "8 weeks",
];

export default function AssessmentFlow({ onNavigate, user }: Props) {
  const { addPatient } = usePatientStore();
  const [step, setStep] = useState(0);

  // Step 0 fields
  const [patientName, setPatientName] = useState("");
  const [age, setAge] = useState("");
  const [phone, setPhone] = useState("");
  const [place, setPlace] = useState("");
  const [gender, setGender] = useState("");
  const [smoking, setSmoking] = useState<
    "non-smoker" | "occasional" | "regular"
  >("non-smoker");
  const [alcohol, setAlcohol] = useState<"no" | "occasional" | "regular">("no");
  const [exposure, setExposure] = useState<string[]>([]);
  const [existingDiseases, setExistingDiseases] = useState("");

  const [symptoms, setSymptoms] = useState<SymptomData[]>(
    symptomsConfig.map((s) => ({
      name: s.name,
      present: false,
      duration: "1 week",
      trend: "Same",
      intensity: "Low",
    })),
  );
  const [riskFactors, setRiskFactors] = useState<string[]>([]);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [expandedExplanation, setExpandedExplanation] = useState<string | null>(
    null,
  );

  function updateSymptom<K extends keyof SymptomData>(
    idx: number,
    key: K,
    val: SymptomData[K],
  ) {
    setSymptoms((prev) =>
      prev.map((s, i) => (i === idx ? { ...s, [key]: val } : s)),
    );
  }
  function toggleRiskFactor(f: string) {
    setRiskFactors((prev) =>
      prev.includes(f) ? prev.filter((x) => x !== f) : [...prev, f],
    );
  }
  function toggleExposure(e: string) {
    setExposure((prev) =>
      prev.includes(e) ? prev.filter((x) => x !== e) : [...prev, e],
    );
  }
  function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setImageBase64(ev.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  }

  function computeFinalRiskAndConfidence(): {
    score: number;
    confidence: number;
  } {
    const { score: base, confidence } = calculateRiskWithConfidence(
      symptoms,
      riskFactors,
    );
    let finalScore = base;
    if (smoking === "regular") finalScore += 15;
    else if (smoking === "occasional") finalScore += 8;
    if (alcohol === "regular") finalScore += 10;
    else if (alcohol === "occasional") finalScore += 5;
    if (exposure.includes("Pollution")) finalScore += 5;
    finalScore += exposure.length * 3;
    if (existingDiseases.trim()) finalScore += 5;
    return { score: Math.min(finalScore, 100), confidence };
  }

  function handleSubmit() {
    setLoading(true);
    setTimeout(() => {
      const { score: finalScore, confidence } = computeFinalRiskAndConfidence();
      const patientDraft: Omit<Patient, "aiFindings" | "structuredReport"> = {
        id: `P${Date.now()}`,
        userId: user.email,
        name: patientName || "Anonymous",
        age: Number(age) || 0,
        gender: gender || "",
        phone,
        place,
        smoking,
        alcohol,
        exposure,
        existingDiseases,
        riskScore: finalScore,
        riskZone: getRiskZone(finalScore),
        status: "pending",
        symptoms: symptoms.filter((s) => s.present).map((s) => s.name),
        symptomData: symptoms,
        riskFactors,
        submittedAt: new Date().toISOString().split("T")[0],
        imageBase64: imageBase64 || undefined,
        confidenceScore: confidence,
      };
      const aiFindings = generateAIFindings(patientDraft as Patient);
      const patientWithFindings: Patient = { ...patientDraft, aiFindings };
      const structuredReport = generateStructuredClinicalReport(
        patientWithFindings,
        confidence,
      );
      const patient: Patient = { ...patientWithFindings, structuredReport };
      addPatient(patient);
      setLoading(false);
      setSubmitted(true);
    }, 2000);
  }

  if (submitted) {
    return (
      <div
        className="flex flex-col items-center justify-center min-h-[60vh] p-8 text-center"
        data-ocid="assessment.success_state"
      >
        <CheckCircle size={64} className="text-green-500 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Report Submitted!</h2>
        <p className="text-muted-foreground mb-2">
          Report submitted for medical review
        </p>
        <p className="text-sm text-muted-foreground mb-6">
          A doctor will review your submission within 24–48 hours.
        </p>
        <Button
          onClick={() => onNavigate("patient-dashboard")}
          className="bg-primary hover:bg-primary/90 text-white"
          data-ocid="assessment.go_dashboard.button"
        >
          Back to Dashboard
        </Button>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto">
      <div className="mb-8">
        <div className="flex items-center gap-1 mb-2">
          {STEPS.map((s, i) => (
            <div
              key={s}
              className={`flex-1 h-1.5 rounded-full transition-all ${
                i <= step ? "bg-primary" : "bg-border"
              }`}
            />
          ))}
        </div>
        <p className="text-sm text-muted-foreground">
          Step {step + 1} of {STEPS.length}:{" "}
          <span className="font-medium text-foreground">{STEPS[step]}</span>
        </p>
      </div>

      {step === 0 && (
        <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-5">
          <h2 className="font-bold text-lg">Patient Information</h2>

          {/* Basic info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>
                Patient Name <span className="text-primary">*</span>
              </Label>
              <Input
                placeholder="Full name"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="mt-1"
                data-ocid="assessment.name.input"
              />
            </div>
            <div>
              <Label>
                Age <span className="text-primary">*</span>
              </Label>
              <Input
                type="number"
                placeholder="e.g. 35"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="mt-1"
                data-ocid="assessment.age.input"
              />
            </div>
            <div>
              <Label>
                Phone Number <span className="text-primary">*</span>
              </Label>
              <Input
                type="tel"
                placeholder="10-digit mobile number"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1"
                data-ocid="assessment.phone.input"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Enter 10-digit mobile number
              </p>
            </div>
            <div>
              <Label>
                Place / Location <span className="text-primary">*</span>
              </Label>
              <div className="relative mt-1">
                <MapPin
                  size={14}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                />
                <Input
                  placeholder="City or town"
                  value={place}
                  onChange={(e) => setPlace(e.target.value)}
                  className="pl-8"
                  data-ocid="assessment.place.input"
                />
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Location data used for pollution-based risk analysis
              </p>
            </div>
            <div>
              <Label>Gender</Label>
              <Select onValueChange={setGender}>
                <SelectTrigger
                  className="mt-1"
                  data-ocid="assessment.gender.select"
                >
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Lifestyle */}
          <div className="border-t border-border pt-4">
            <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide mb-4">
              Lifestyle Information
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Smoking */}
              <div>
                <Label className="mb-2 block">Smoking</Label>
                <div className="space-y-2">
                  {(["non-smoker", "occasional", "regular"] as const).map(
                    (opt) => (
                      <label
                        key={opt}
                        className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                          smoking === opt
                            ? "border-primary bg-primary/5"
                            : "border-border hover:bg-muted/40"
                        }`}
                      >
                        <input
                          type="radio"
                          name="smoking"
                          value={opt}
                          checked={smoking === opt}
                          onChange={() => setSmoking(opt)}
                          className="accent-primary"
                          data-ocid="assessment.smoking.radio"
                        />
                        <span className="text-sm font-medium capitalize">
                          {opt === "non-smoker"
                            ? "Non-smoker"
                            : opt.charAt(0).toUpperCase() + opt.slice(1)}
                        </span>
                      </label>
                    ),
                  )}
                </div>
              </div>

              {/* Alcohol */}
              <div>
                <Label className="mb-2 block">Alcohol Consumption</Label>
                <div className="space-y-2">
                  {(["no", "occasional", "regular"] as const).map((opt) => (
                    <label
                      key={opt}
                      className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                        alcohol === opt
                          ? "border-primary bg-primary/5"
                          : "border-border hover:bg-muted/40"
                      }`}
                    >
                      <input
                        type="radio"
                        name="alcohol"
                        value={opt}
                        checked={alcohol === opt}
                        onChange={() => setAlcohol(opt)}
                        className="accent-primary"
                        data-ocid="assessment.alcohol.radio"
                      />
                      <span className="text-sm font-medium capitalize">
                        {opt === "no"
                          ? "No"
                          : opt.charAt(0).toUpperCase() + opt.slice(1)}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Exposure */}
          <div>
            <Label className="mb-2 block">
              Additional Exposure{" "}
              <span className="text-xs text-muted-foreground font-normal">
                (multi-select)
              </span>
            </Label>
            <div className="grid grid-cols-2 gap-2">
              {EXPOSURE_OPTIONS.map((opt, i) => (
                <label
                  key={opt}
                  className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                    exposure.includes(opt)
                      ? "border-primary bg-primary/5"
                      : "border-border hover:bg-muted/40"
                  }`}
                  data-ocid={`assessment.exposure.checkbox.${i + 1}`}
                >
                  <input
                    type="checkbox"
                    checked={exposure.includes(opt)}
                    onChange={() => toggleExposure(opt)}
                    className="accent-primary w-4 h-4"
                  />
                  <span className="text-sm font-medium">{opt}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Existing diseases */}
          <div>
            <Label className="mb-1 block">
              Existing Diseases{" "}
              <span className="text-xs text-muted-foreground font-normal">
                (optional)
              </span>
            </Label>
            <Textarea
              placeholder="e.g. Diabetes, Hypertension..."
              value={existingDiseases}
              onChange={(e) => setExistingDiseases(e.target.value)}
              rows={2}
              data-ocid="assessment.existing_diseases.textarea"
            />
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-4">
          <h2 className="font-bold text-lg">Symptom Assessment</h2>
          <p className="text-sm text-muted-foreground">
            Tap <span className="font-semibold text-green-600">YES</span> for
            any symptom you are currently experiencing.
          </p>
          {["Skin"].map((group) => (
            <div key={group}>
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                {group} Symptoms
              </h3>
              <div className="space-y-4">
                {symptoms
                  .map((s, idx) => ({ ...s, idx }))
                  .filter((_, i) => symptomsConfig[i]?.group === group)
                  .map(({ name, present, duration, trend, intensity, idx }) => (
                    <div
                      key={name}
                      className={`border-2 rounded-xl p-4 transition-all ${
                        present
                          ? "border-green-400 bg-green-50/50"
                          : "border-border"
                      }`}
                      data-ocid={`assessment.symptom.item.${idx + 1}`}
                    >
                      {/* Symptom name + YES/NO buttons */}
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <div className="flex-1 pt-1">
                          <div className="flex items-center gap-1.5">
                            <span className="font-medium text-sm">{name}</span>
                            <button
                              type="button"
                              onClick={() =>
                                setExpandedExplanation(
                                  expandedExplanation === name ? null : name,
                                )
                              }
                              className="text-blue-400 hover:text-blue-600 transition-colors shrink-0"
                              aria-label={`Info about ${name}`}
                            >
                              <Info size={14} />
                            </button>
                          </div>
                          {expandedExplanation === name && (
                            <p className="text-xs text-blue-600 bg-blue-50 rounded-md px-2 py-1.5 mt-1.5 leading-relaxed border border-blue-100">
                              {
                                symptomsConfig.find((s) => s.name === name)
                                  ?.explanation
                              }
                            </p>
                          )}
                        </div>
                        <div className="flex gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => updateSymptom(idx, "present", true)}
                            className={`px-5 py-2.5 rounded-lg text-sm font-semibold border-2 transition-all min-w-[64px] ${
                              present
                                ? "bg-green-500 text-white border-green-500 shadow-sm"
                                : "bg-transparent text-muted-foreground border-border hover:border-green-400 hover:text-green-600"
                            }`}
                            data-ocid={`assessment.symptom_yes.${idx + 1}`}
                          >
                            YES
                          </button>
                          <button
                            type="button"
                            onClick={() => updateSymptom(idx, "present", false)}
                            className={`px-5 py-2.5 rounded-lg text-sm font-semibold border-2 transition-all min-w-[64px] ${
                              !present
                                ? "bg-muted text-muted-foreground border-border shadow-sm"
                                : "bg-transparent text-muted-foreground border-border hover:border-red-300 hover:text-red-500"
                            }`}
                            data-ocid={`assessment.symptom_no.${idx + 1}`}
                          >
                            NO
                          </button>
                        </div>
                      </div>

                      {/* Conditional details when YES */}
                      {present && (
                        <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-green-200">
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">
                              Duration (in Weeks)
                            </p>
                            <Select
                              defaultValue={duration}
                              onValueChange={(v) =>
                                updateSymptom(idx, "duration", v)
                              }
                            >
                              <SelectTrigger className="text-xs">
                                <SelectValue placeholder="Duration" />
                              </SelectTrigger>
                              <SelectContent>
                                {DURATION_OPTIONS.map((d) => (
                                  <SelectItem key={d} value={d}>
                                    {d}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">
                              Trend
                            </p>
                            <Select
                              defaultValue={trend}
                              onValueChange={(v) =>
                                updateSymptom(
                                  idx,
                                  "trend",
                                  v as SymptomData["trend"],
                                )
                              }
                            >
                              <SelectTrigger className="text-xs">
                                <SelectValue placeholder="Trend" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Improving">
                                  Improving
                                </SelectItem>
                                <SelectItem value="Same">Same</SelectItem>
                                <SelectItem value="Worse">Worse</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">
                              Intensity
                            </p>
                            <Select
                              defaultValue={intensity}
                              onValueChange={(v) =>
                                updateSymptom(
                                  idx,
                                  "intensity",
                                  v as SymptomData["intensity"],
                                )
                              }
                            >
                              <SelectTrigger className="text-xs">
                                <SelectValue placeholder="Intensity" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Low">Low</SelectItem>
                                <SelectItem value="Medium">Medium</SelectItem>
                                <SelectItem value="High">High</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {step === 2 && (
        <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-4">
          <h2 className="font-bold text-lg">Risk Factors</h2>
          <p className="text-sm text-muted-foreground">
            Select all risk factors that apply to you.
          </p>
          <div className="space-y-3">
            {riskFactorsList.map((f, i) => (
              <label
                key={f}
                className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                  riskFactors.includes(f)
                    ? "border-primary bg-primary/5"
                    : "border-border hover:bg-muted/40"
                }`}
                data-ocid={`assessment.risk_factor.checkbox.${i + 1}`}
              >
                <input
                  type="checkbox"
                  checked={riskFactors.includes(f)}
                  onChange={() => toggleRiskFactor(f)}
                  className="accent-primary w-4 h-4"
                />
                <span className="text-sm font-medium">{f}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-5">
          <h2 className="font-bold text-lg">Image Upload</h2>
          <p className="text-sm text-muted-foreground">
            Upload a relevant medical image (skin lesion, scan, etc.) for AI
            analysis.
          </p>

          <label
            className="flex flex-col items-center justify-center gap-3 border-2 border-dashed border-border rounded-xl p-10 cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-colors"
            data-ocid="assessment.image.dropzone"
          >
            <Upload size={36} className="text-muted-foreground" />
            <div className="text-center">
              <p className="font-medium text-sm">Click to upload image</p>
              <p className="text-xs text-muted-foreground mt-1">
                PNG, JPG, JPEG — max 10MB
              </p>
            </div>
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={handleImageUpload}
              data-ocid="assessment.image.upload_button"
            />
          </label>

          {imageBase64 && (
            <div className="mt-4">
              <p className="text-xs text-green-600 font-medium mb-2">
                ✓ Image uploaded
              </p>
              <img
                src={imageBase64}
                alt="Uploaded preview"
                className="max-h-48 rounded-lg object-cover border border-border"
              />
            </div>
          )}
          {!imageBase64 && (
            <p className="text-sm text-center text-muted-foreground">
              Image upload is optional but recommended.
            </p>
          )}
        </div>
      )}

      {step === 4 && (
        <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-5">
          <h2 className="font-bold text-lg">Upload Reports</h2>
          <p className="text-sm text-muted-foreground">
            Optionally attach any previous medical reports or lab results.
          </p>
          <label
            className="flex flex-col items-center justify-center gap-3 border-2 border-dashed border-border rounded-xl p-10 cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-colors"
            data-ocid="assessment.reports.dropzone"
          >
            <Upload size={36} className="text-muted-foreground" />
            <div className="text-center">
              <p className="font-medium text-sm">Click to upload reports</p>
              <p className="text-xs text-muted-foreground mt-1">
                PDF, PNG, JPG — max 10MB
              </p>
            </div>
            <input
              type="file"
              accept=".pdf,image/*"
              className="sr-only"
              data-ocid="assessment.reports.upload_button"
            />
          </label>
          <p className="text-sm text-center text-muted-foreground">
            Report upload is optional.
          </p>
        </div>
      )}

      {step === 5 && (
        <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-5">
          <h2 className="font-bold text-lg">Review & Submit</h2>
          <div className="space-y-3 text-sm">
            <div className="grid grid-cols-2 gap-3 p-4 bg-muted/40 rounded-lg">
              <div>
                <p className="text-muted-foreground text-xs">Name</p>
                <p className="font-medium">{patientName || "—"}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Age</p>
                <p className="font-medium">{age || "—"}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Phone</p>
                <p className="font-medium">{phone || "—"}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Place</p>
                <p className="font-medium">{place || "—"}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Smoking</p>
                <p className="font-medium capitalize">{smoking}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Alcohol</p>
                <p className="font-medium capitalize">{alcohol}</p>
              </div>
              <div className="col-span-2">
                <p className="text-muted-foreground text-xs">Symptoms</p>
                <p className="font-medium">
                  {symptoms
                    .filter((s) => s.present)
                    .map((s) => s.name)
                    .join(", ") || "None"}
                </p>
              </div>
              <div className="col-span-2">
                <p className="text-muted-foreground text-xs">Risk Factors</p>
                <p className="font-medium">
                  {riskFactors.join(", ") || "None"}
                </p>
              </div>
              {imageBase64 && (
                <div className="col-span-2">
                  <p className="text-muted-foreground text-xs">Image</p>
                  <p className="font-medium text-green-600">✓ Image attached</p>
                </div>
              )}
            </div>
          </div>
          <Button
            onClick={handleSubmit}
            disabled={loading}
            className="w-full bg-primary hover:bg-primary/90 text-white"
            data-ocid="assessment.submit.button"
          >
            {loading ? (
              <>
                <Loader2 size={16} className="mr-2 animate-spin" /> Analyzing...
              </>
            ) : (
              "Submit Assessment"
            )}
          </Button>
        </div>
      )}

      {/* Navigation */}
      <div className="flex gap-3 mt-6">
        {step > 0 && (
          <Button
            variant="outline"
            onClick={() => setStep((s) => s - 1)}
            className="flex-1"
            data-ocid="assessment.back.button"
          >
            ← Back
          </Button>
        )}
        {step < STEPS.length - 1 && (
          <Button
            onClick={() => setStep((s) => s + 1)}
            className="flex-1 bg-primary hover:bg-primary/90 text-white"
            data-ocid="assessment.next.button"
          >
            Next →
          </Button>
        )}
      </div>
    </div>
  );
}
