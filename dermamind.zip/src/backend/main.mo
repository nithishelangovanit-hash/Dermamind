import Runtime "mo:core/Runtime";
import Time "mo:core/Time";
import Map "mo:core/Map";
import Array "mo:core/Array";
import Order "mo:core/Order";
import List "mo:core/List";
import Principal "mo:core/Principal";
import Text "mo:core/Text";

import MixinStorage "../src/backend/blob-storage/Mixin";
import Storage "../src/backend/blob-storage/Storage";
import MixinAuthorization "../src/backend/authorization/MixinAuthorization";
import AccessControl "../src/backend/authorization/access-control";

actor {
  type Gender = {
    #male;
    #female;
    #other;
  };

  module Gender {
    public func compare(gender1 : Gender, gender2 : Gender) : Order.Order {
      switch (gender1, gender2) {
        case (#male, #male) { #equal };
        case (#male, _) { #less };
        case (#female, #male) { #greater };
        case (#female, #female) { #equal };
        case (#female, #other) { #less };
        case (#other, #other) { #equal };
        case (#other, _) { #greater };
      };
    };
  };

  type UserRole = {
    #admin;
    #doctor;
    #patient;
  };

  module UserRole {
    public func compare(role1 : UserRole, role2 : UserRole) : Order.Order {
      switch (role1, role2) {
        case (#admin, #admin) { #equal };
        case (#admin, _) { #less };
        case (#doctor, #admin) { #greater };
        case (#doctor, #doctor) { #equal };
        case (#doctor, #patient) { #less };
        case (#patient, #patient) { #equal };
        case (#patient, _) { #greater };
      };
    };
  };

  type Symptom = {
    name : Text;
    severity : ?Nat8;
    durationDays : ?Nat16;
    trend : ?Text;
  };

  module Symptom {
    public func compare(symptom1 : Symptom, symptom2 : Symptom) : Order.Order {
      symptom1.name.compare(symptom2.name);
    };
  };

  type RiskFactor = {
    name : Text;
    description : Text;
  };

  module RiskFactor {
    public func compareByName(riskFactor1 : RiskFactor, riskFactor2 : RiskFactor) : Order.Order {
      riskFactor1.name.compare(riskFactor2.name);
    };
  };

  type PersonalInfo = {
    firstName : Text;
    lastName : Text;
    age : Nat8;
    gender : Gender;
    contact : Text;
  };

  module PersonalInfo {
    public func compareByFirstName(info1 : PersonalInfo, info2 : PersonalInfo) : Order.Order {
      switch (Text.compare(info1.firstName, info2.firstName)) {
        case (#equal) {
          switch (Text.compare(info1.lastName, info2.lastName)) {
            case (#equal) { info1.contact.compare(info2.contact) };
            case (order) { order };
          };
        };
        case (order) { order };
      };
    };
  };

  type UserProfile = {
    principal : Principal;
    role : UserRole;
    personalInfo : PersonalInfo;
  };

  module UserProfile {
    public func compareByFirstName(profile1 : UserProfile, profile2 : UserProfile) : Order.Order {
      PersonalInfo.compareByFirstName(profile1.personalInfo, profile2.personalInfo);
    };
  };

  type RiskZone = {
    #green;
    #yellow;
    #red;
  };

  module RiskZone {
    public func compare(zone1 : RiskZone, zone2 : RiskZone) : Order.Order {
      switch (zone1, zone2) {
        case (#green, #green) { #equal };
        case (#green, _) { #less };
        case (#yellow, #green) { #greater };
        case (#yellow, #yellow) { #equal };
        case (#yellow, #red) { #less };
        case (#red, #red) { #equal };
        case (#red, _) { #greater };
      };
    };
  };

  type ScreeningStatus = {
    #pending;
    #reviewed;
    #approved;
    #rejected;
  };

  module ScreeningStatus {
    public func compare(status1 : ScreeningStatus, status2 : ScreeningStatus) : Order.Order {
      switch (status1, status2) {
        case (#pending, #pending) { #equal };
        case (#pending, _) { #less };
        case (#reviewed, #pending) { #greater };
        case (#reviewed, #reviewed) { #equal };
        case (#reviewed, #approved) { #less };
        case (#reviewed, #rejected) { #less };
        case (#approved, #approved) { #equal };
        case (#approved, #rejected) { #less };
        case (#rejected, #rejected) { #equal };
        case (#rejected, _) { #greater };
        case (_) { #less };
      };
    };
  };

  type AnalyticsStats = {
    totalUsers : Nat;
    totalSubmissions : Nat;
    greenCount : Nat;
    yellowCount : Nat;
    redCount : Nat;
    pendingCount : Nat;
  };

  type DoctorReview = {
    doctorId : Principal;
    notes : Text;
    testRecommendations : [Text];
  };

  module DoctorReview {
    public func compareByDoctorId(review1 : DoctorReview, review2 : DoctorReview) : Order.Order {
      review1.doctorId.compare(review2.doctorId);
    };
  };

  type ScreeningSubmission = {
    id : Nat;
    userId : Principal;
    symptoms : [Symptom];
    riskFactors : [RiskFactor];
    aiRiskScore : Nat8;
    riskZone : RiskZone;
    image : ?Storage.ExternalBlob;
    report : ?Storage.ExternalBlob;
    status : ScreeningStatus;
    doctorReview : ?DoctorReview;
    submittedAt : Time.Time;
  };

  type Lab = {
    name : Text;
    contact : Text;
    address : Text;
    services : [Text];
  };

  module Lab {
    public func compareByName(lab1 : Lab, lab2 : Lab) : Order.Order {
      switch (Text.compare(lab1.name, lab2.name)) {
        case (#equal) { lab1.contact.compare(lab2.contact) };
        case (order) { order };
      };
    };
  };

  public type HealthReminder = {
    patientId : Text;
    message : Text;
    dueDate : Time.Time;
  };

  module HealthReminder {
    public func compareByDueDate(reminder1 : HealthReminder, reminder2 : HealthReminder) : Order.Order {
      if (reminder1.dueDate < reminder2.dueDate) {
        #less;
      } else if (reminder1.dueDate > reminder2.dueDate) {
        #greater;
      } else {
        compareByMessage(reminder1, reminder2);
      };
    };

    func compareByMessage(reminder1 : HealthReminder, reminder2 : HealthReminder) : Order.Order {
      reminder1.message.compare(reminder2.message);
    };
  };

  type ReportStatus = {
    #pending;
    #approved;
    #rejected;
  };

  type MedicalReport = {
    id : Nat;
    userId : Principal;
    doctorId : Principal;
    title : Text;
    description : Text;
    file : ?Storage.ExternalBlob;
    createdAt : Time.Time;
    status : ReportStatus;
  };

  type OutPatientAppointment = {
    id : Nat;
    userId : Principal;
    doctorId : Principal;
    appointmentDate : ?Time.Time;
    appointmentTime : ?Text;
    notes : Text;
    typeOfAppointment : Text;
    hospital : Text;
    createdAt : Time.Time;
    status : Text;
  };

  // Persistent fields
  let users = Map.empty<Principal, UserProfile>();
  let submissions = Map.empty<Nat, ScreeningSubmission>();
  let patientReminders = Map.empty<Principal, [HealthReminder]>();
  let labs = Map.empty<Text, Lab>();
  let medicalReports = Map.empty<Nat, MedicalReport>();
  let appointments = Map.empty<Nat, OutPatientAppointment>();

  // Only persistent vars, not persistent fields!
  var nextSubmissionId = 0;
  var nextReportId = 0;
  var nextAppointmentId = 0;

  include MixinStorage();
  let accessControlState = AccessControl.initState();
  include MixinAuthorization(accessControlState);

  // Helper function to check if caller has a specific custom role
  func hasCustomRole(caller : Principal, requiredRole : UserRole) : Bool {
    switch (users.get(caller)) {
      case (?profile) { profile.role == requiredRole };
      case (null) { false };
    };
  };

  // Helper function to check if caller is admin
  func isCustomAdmin(caller : Principal) : Bool {
    hasCustomRole(caller, #admin);
  };

  // Helper function to check if caller is doctor
  func isDoctor(caller : Principal) : Bool {
    hasCustomRole(caller, #doctor);
  };

  // Helper function to check if caller is patient
  func isPatient(caller : Principal) : Bool {
    hasCustomRole(caller, #patient);
  };

  // Required by frontend: Get caller's own profile
  public query ({ caller }) func getCallerUserProfile() : async ?UserProfile {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view profiles");
    };
    users.get(caller);
  };

  // Required by frontend: Save caller's own profile
  public shared ({ caller }) func saveCallerUserProfile(profile : UserProfile) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can save profiles");
    };

    // Ensure caller cannot change their own principal
    if (profile.principal != caller) {
      Runtime.trap("Cannot change profile principal");
    };

    // Prevent privilege escalation - only admins can assign admin role
    if (profile.role == #admin and not isCustomAdmin(caller)) {
      Runtime.trap("Unauthorized: Only admins can assign admin role");
    };

    // Prevent users from changing to doctor role without admin approval
    switch (users.get(caller)) {
      case (?existingProfile) {
        if (existingProfile.role != #doctor and profile.role == #doctor and not isCustomAdmin(caller)) {
          Runtime.trap("Unauthorized: Only admins can assign doctor role");
        };
      };
      case (null) {
        // New profile - only allow patient role unless admin
        if (profile.role != #patient and not isCustomAdmin(caller)) {
          Runtime.trap("Unauthorized: New users can only register as patients");
        };
      };
    };
    users.add(caller, profile);
  };

  // Required by frontend: Get another user's profile (query-only)
  public query ({ caller }) func getUserProfile(user : Principal) : async ?UserProfile {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view profiles");
    };

    // Allow user to view their own profile
    if (caller == user) {
      return users.get(user);
    };

    // Only admins and doctors can view other users' profiles
    if (not (isCustomAdmin(caller) or isDoctor(caller))) {
      Runtime.trap("Unauthorized: Only admins and doctors can view other profiles");
    };

    users.get(user);
  };

  // Admin-only: Create user profile with specific role for a specific user
  public shared ({ caller }) func createUserProfile(userPrincipal : Principal, personalInfo : PersonalInfo, role : UserRole) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can create user profiles");
    };
    let userProfile : UserProfile = {
      principal = userPrincipal;
      role;
      personalInfo;
    };
    users.add(userPrincipal, userProfile);
  };

  // Patient only: Submit screening
  public shared ({ caller }) func submitScreening(symptoms : [Symptom], riskFactors : [RiskFactor], aiRiskScore : Nat8, riskZone : RiskZone, image : ?Storage.ExternalBlob) : async Nat {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can submit screenings");
    };

    // Check if user has patient role
    if (not isPatient(caller)) {
      Runtime.trap("Unauthorized: Only patients can submit screenings");
    };

    let submissionId = nextSubmissionId;
    let submission : ScreeningSubmission = {
      id = submissionId;
      userId = caller;
      symptoms;
      riskFactors;
      aiRiskScore;
      riskZone;
      image;
      report = null;
      status = #pending;
      doctorReview = null;
      submittedAt = Time.now();
    };
    submissions.add(submissionId, submission);
    nextSubmissionId += 1;
    submissionId;
  };

  // Doctor only: Add doctor review
  public shared ({ caller }) func addDoctorReview(submissionId : Nat, review : DoctorReview, status : ScreeningStatus) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can add reviews");
    };

    // Check if user has doctor role
    if (not isDoctor(caller)) {
      Runtime.trap("Unauthorized: Only doctors can add reviews");
    };

    // Verify the review is from the caller
    if (review.doctorId != caller) {
      Runtime.trap("Unauthorized: Cannot submit review on behalf of another doctor");
    };

    switch (submissions.get(submissionId)) {
      case (null) { Runtime.trap("Submission not found") };
      case (?existingSubmission) {
        let updatedSubmission = {
          existingSubmission with
          doctorReview = ?review;
          status;
        };
        submissions.add(submissionId, updatedSubmission);
      };
    };
  };

  // Doctor or admin only: Add health reminders
  public shared ({ caller }) func addHealthReminders(personalId : Principal, reminders : HealthReminder) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can add reminders");
    };

    // Check if user has doctor or admin roles
    if (not (isDoctor(caller) or isCustomAdmin(caller))) {
      Runtime.trap("Unauthorized: Only doctors and admins can add health reminders");
    };

    let currentReminders = switch (patientReminders.get(personalId)) {
      case (null) { [] };
      case (?existing) { existing };
    };
    let newReminders = currentReminders.concat([reminders]);
    patientReminders.add(personalId, newReminders);
  };

  // Patient can view own reminders, doctors and admins can view any
  public query ({ caller }) func getRemindersByDueDate(personalId : Principal) : async [HealthReminder] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view reminders");
    };

    // Check if user has access to view the reminders
    if (caller != personalId and not (isDoctor(caller) or isCustomAdmin(caller))) {
      Runtime.trap("Unauthorized: Can only view your own reminders");
    };

    switch (patientReminders.get(personalId)) {
      case (null) { [] };
      case (?reminders) {
        reminders.sort(
          HealthReminder.compareByDueDate
        );
      };
    };
  };

  // Admin only: Add lab
  public shared ({ caller }) func addLab(name : Text, contact : Text, address : Text, services : [Text]) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can add labs");
    };
    let lab : Lab = {
      name;
      contact;
      address;
      services;
    };
    labs.add(name, lab);
  };

  // Any authenticated user can view labs
  public query ({ caller }) func getLabsByName() : async [Lab] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view labs");
    };
    labs.values().toArray().sort(
      Lab.compareByName
    );
  };

  // Patient can view own submissions, doctors and admins can view any
  public query ({ caller }) func getPersonalScreeningSubmissions(personalId : Principal) : async [ScreeningSubmission] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view submissions");
    };

    // Check if user has access to view the submissions
    if (caller != personalId and not (isDoctor(caller) or isCustomAdmin(caller))) {
      Runtime.trap("Unauthorized: Can only view your own submissions");
    };

    let submissionsIter = submissions.values();
    submissionsIter.filter(
      func(s) {
        s.userId == personalId;
      }
    ).toArray();
  };

  // Doctor or admin only: Update screening status
  public shared ({ caller }) func updateScreeningStatus(submissionId : Nat, status : ScreeningStatus) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can update status");
    };

    // Check if user has doctor or admin roles
    if (not (isDoctor(caller) or isCustomAdmin(caller))) {
      Runtime.trap("Unauthorized: Only doctors and admins can update screening status");
    };

    switch (submissions.get(submissionId)) {
      case (null) { Runtime.trap("Submission not found") };
      case (?existingSubmission) {
        let updatedSubmission = { existingSubmission with status };
        submissions.add(submissionId, updatedSubmission);
      };
    };
  };

  // Doctor or admin only: Update screening report
  public shared ({ caller }) func updateScreeningReport(submissionId : Nat, report : Storage.ExternalBlob) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can update reports");
    };

    // Check if user has doctor or admin roles
    if (not (isDoctor(caller) or isCustomAdmin(caller))) {
      Runtime.trap("Unauthorized: Only doctors and admins can update screening reports");
    };

    switch (submissions.get(submissionId)) {
      case (null) { Runtime.trap("Submission not found") };
      case (?existingSubmission) {
        let updatedSubmission = {
          existingSubmission with
          report = ?report;
        };
        submissions.add(submissionId, updatedSubmission);
      };
    };
  };

  // Doctor or admin only: Get submissions by risk zone
  public query ({ caller }) func getScreeningSubmissionsByRiskZone(riskZone : RiskZone) : async [ScreeningSubmission] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view submissions");
    };

    // Check if user has doctor or admin roles
    if (not (isDoctor(caller) or isCustomAdmin(caller))) {
      Runtime.trap("Unauthorized: Only doctors and admins can view submissions by risk zone");
    };

    let submissionsIter = submissions.values();
    submissionsIter.filter(
      func(s) {
        s.riskZone == riskZone;
      }
    ).toArray();
  };

  // Admin only: Get analytics stats
  public query ({ caller }) func getAnalyticsStats() : async AnalyticsStats {
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can view analytics");
    };

    var greenCount = 0;
    var yellowCount = 0;
    var redCount = 0;
    var pendingCount = 0;

    for (submission in submissions.values()) {
      switch (submission.riskZone) {
        case (#green) { greenCount += 1 };
        case (#yellow) { yellowCount += 1 };
        case (#red) { redCount += 1 };
      };
      if (submission.status == #pending) {
        pendingCount += 1;
      };
    };

    {
      totalUsers = users.size();
      totalSubmissions = submissions.size();
      greenCount;
      yellowCount;
      redCount;
      pendingCount;
    };
  };

  // Doctor only: Store medical report
  public shared ({ caller }) func storeMedicalReport(doctorId : Principal, title : Text, description : Text, file : ?Storage.ExternalBlob, userId : Principal) : async Nat {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can store medical reports");
    };

    // Verify that the caller is the doctor
    if (caller != doctorId) {
      Runtime.trap("Unauthorized: You can only upload medical reports as yourself");
    };

    // Check if the caller has the doctor role
    if (not isDoctor(caller)) {
      Runtime.trap("Unauthorized: Only approved doctors can upload medical reports");
    };

    // Verify that the patient exists
    switch (users.get(userId)) {
      case (null) { Runtime.trap("Patient not found") };
      case (?userProfile) {
        if (userProfile.role != #patient) {
          Runtime.trap("Invalid patient: User is not a patient");
        };
      };
    };

    let reportId = nextReportId;
    let report = {
      id = reportId;
      userId;
      doctorId;
      title;
      description;
      file;
      createdAt = Time.now();
      status = #pending;
    };

    medicalReports.add(reportId, report);
    nextReportId += 1;
    reportId;
  };

  // Patient can view own reports, doctors and admins can view any
  public query ({ caller }) func getReportsByUser(userId : Principal) : async [MedicalReport] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view reports");
    };

    // Verify that the caller is either the user or a doctor/admin
    if (caller != userId and not (isDoctor(caller) or isCustomAdmin(caller))) {
      Runtime.trap("Unauthorized: Can only view your own reports");
    };

    medicalReports.values().toArray().filter(
      func(report) {
        report.userId == userId;
      }
    );
  };

  // Any authenticated user can view doctors list
  public query ({ caller }) func getDoctors() : async [UserProfile] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view doctors");
    };
    users.values().toArray().filter(
      func(user) {
        user.role == #doctor;
      }
    );
  };

  // Doctor or admin only: Get all patients
  public query ({ caller }) func getPatients() : async [UserProfile] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view patients");
    };

    if (not (isDoctor(caller) or isCustomAdmin(caller))) {
      Runtime.trap("Unauthorized: Only doctors and admins can view patients list");
    };

    users.values().toArray().filter(
      func(user) {
        user.role == #patient;
      }
    );
  };

  // Admin only: Get all reports
  public query ({ caller }) func getAllReports() : async [MedicalReport] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can view all reports");
    };
    medicalReports.values().toArray();
  };

  // Patient only: Book appointment (patients book for themselves)
  public shared ({ caller }) func bookOutPatientAppointment(doctorId : Principal, appointmentDate : ?Time.Time, appointmentTime : ?Text, notes : Text, typeOfAppointment : Text, hospital : Text) : async Nat {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can book appointments");
    };

    // Verify that the caller is a patient
    if (not isPatient(caller)) {
      Runtime.trap("Unauthorized: Only patients can book appointments");
    };

    // Check if the doctor exists and has the doctor role
    switch (users.get(doctorId)) {
      case (null) { Runtime.trap("Doctor not found") };
      case (?doctorProfile) {
        if (doctorProfile.role != #doctor) {
          Runtime.trap("Unauthorized: Only verified doctors can have appointments");
        };
      };
    };

    let appointmentId = nextAppointmentId;
    let appointment = {
      id = appointmentId;
      userId = caller;
      doctorId;
      appointmentDate;
      appointmentTime;
      notes;
      typeOfAppointment;
      hospital;
      createdAt = Time.now();
      status = "pending";
    };

    appointments.add(appointmentId, appointment);
    nextAppointmentId += 1;
    appointmentId;
  };

  // Patient can view own appointments, doctors can view appointments with them, admins can view all
  public query ({ caller }) func getAppointmentsByUser(userId : Principal) : async [OutPatientAppointment] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view appointments");
    };

    // Patient viewing their own appointments
    if (caller == userId) {
      return appointments.values().toArray().filter(
        func(appointment) {
          appointment.userId == userId;
        }
      );
    };

    // Admin can view any user's appointments
    if (isCustomAdmin(caller)) {
      return appointments.values().toArray().filter(
        func(appointment) {
          appointment.userId == userId;
        }
      );
    };

    // Doctor can only view appointments where they are the assigned doctor
    if (isDoctor(caller)) {
      return appointments.values().toArray().filter(
        func(appointment) {
          appointment.userId == userId and appointment.doctorId == caller;
        }
      );
    };

    // Otherwise, unauthorized
    Runtime.trap("Unauthorized: Can only view your own appointments");
  };
};
