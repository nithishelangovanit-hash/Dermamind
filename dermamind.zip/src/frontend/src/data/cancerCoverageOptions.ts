export interface CancerCoverageOption {
  id: string;
  provider: string;
  name: string;
  summary: string;
  importantTerms: string;
  officialUrl: string;
  lastVerified: string;
}

// India-only examples reviewed against the insurers' official product pages.
// Informational directory, not an endorsement or individualized recommendation.
export const cancerCoverageOptions: CancerCoverageOption[] = [
  {
    id: "star-cancer-care-platinum",
    provider: "Star Health",
    name: "Star Cancer Care Platinum",
    summary:
      "The insurer describes this as a cancer-focused health plan for people diagnosed with cancer; check eligibility and acceptance for your own medical history.",
    importantTerms:
      "The product page lists a 30-month pre-existing-disease waiting period. Ask the insurer in writing whether your existing diagnosis and current treatment would be accepted and what would be covered.",
    officialUrl: "https://www.starhealth.in/health-insurance/cancer-care-platinum/",
    lastVerified: "2026-10-19",
  },
  {
    id: "care-cancer-mediclaim",
    provider: "Care Health Insurance",
    name: "Care Cancer Mediclaim",
    summary:
      "A cancer-focused mediclaim product; check eligibility with the insurer if you have a current or previous cancer diagnosis.",
    importantTerms:
      "The product page lists a 36-month pre-existing-disease waiting period and an entry-age range. Acceptance and cover for an existing diagnosis are subject to the current policy wording and underwriting; confirm both in writing.",
    officialUrl: "https://www.careinsurance.com/product/care-cancer-mediclaim",
    lastVerified: "2026-10-19",
  },
  {
    id: "hdfc-ergo-ican",
    provider: "HDFC ERGO",
    name: "iCan Cancer Insurance",
    summary:
      "A cancer-focused product to compare for future cover; check eligibility and the policy wording before applying.",
    importantTerms:
      "The product page says cancer-related expenses for pre-existing cancer or signs and symptoms before the policy start are excluded. Do not treat this as cover for an existing diagnosis.",
    officialUrl: "https://www.hdfcergo.com/health-insurance/ican-cancer-insurance-plan",
    lastVerified: "2026-10-19",
  },
];

export const cancerCoverageChecklist = [
  "Disclose the full diagnosis, symptoms, treatment history, and existing cover in the application.",
  "Check the policy wording for pre-existing-disease exclusions, waiting periods, co-payments, limits, and renewal terms.",
  "Ask the insurer in writing whether the current cancer and planned treatment would be covered if the application is accepted.",
];

export const existingCoverageNote =
  "If you already have health insurance or employer cover, check with your insurer or HR about what it covers.";

export const irdaiHealthInsuranceUrl = "https://irdai.gov.in/health-dept";
