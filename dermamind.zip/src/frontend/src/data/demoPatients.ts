import type { Patient, RiskZone, SymptomEntry } from "../types";
import { calculateRisk } from "../utils/riskEngine";
import { createDefaultSymptoms, SYMPTOM_DEFINITIONS } from "../utils/symptomsData";

function makeSymptoms(yesIds: number[], durationWeek: number | "8+", trend: SymptomEntry["trend"], intensityIndex = 0): SymptomEntry[] {
  const rows = createDefaultSymptoms();
  for (const id of yesIds) {
    const def = SYMPTOM_DEFINITIONS[id - 1];
    const current = rows[id - 1];
    rows[id - 1] = {
      ...current,
      answer: "Yes",
      present: true,
      durationWeek,
      trend,
      frequency: def.freq ? "Frequent" : null,
      intensity: def.intensity ? def.intensity[intensityIndex] : null,
      followUps: Object.fromEntries((def.followUps ?? []).map((q) => [q.key, q.multi ? [q.options?.[0] ?? "Yes"] : q.options?.[0] ?? "Yes"])),
    };
  }
  return rows;
}

function makePatient(index: number, name: string, age: number, yesIds: number[], zone: RiskZone, trend: SymptomEntry["trend"], risk: { familyHistory?: boolean; uv?: boolean; chemical?: boolean } = {}): Patient {
  const symptoms = makeSymptoms(yesIds, zone === "red" ? "8+" : zone === "yellow" ? 5 : 1, trend, zone === "red" ? 2 : zone === "yellow" ? 1 : 0);
  const result = calculateRisk({ symptoms, age, place: "", smokingLevel: "Non-Smoker", alcoholLevel: "Non-Drinker", chemicalExposure: !!risk.chemical, radiationExposure: !!risk.uv, existingDiseases: "", familyHistory: !!risk.familyHistory, skinImageScore: 0 });
  return {
    id: `DEMO-P${index}-2026`, userEmail: `patient${index}@demo.com`, submittedAt: new Date(Date.now() - (31 - index * 5) * 86400000).toISOString(),
    name, age, gender: index % 2 ? "Male" : "Female", phone: `987654321${index}`, place: "Chennai",
    smokingLevel: "Non-Smoker", alcoholLevel: "Non-Drinker", smoking: false, alcohol: false,
    chemicalExposure: !!risk.chemical, radiationExposure: !!risk.uv, existingDiseases: "", familyHistory: !!risk.familyHistory,
    additionalExposure: [], symptoms, uploadedImages: [], skinImageScore: 0,
    riskScore: result.score, confidenceScore: 0, riskZone: result.riskZone, aiFindingsSummary: result.aiFindings, aiRiskFactors: result.aiRiskFactors,
    riskBreakdown: result.riskBreakdown, topContributors: result.topContributors,
    assignedDoctorType: index === 2 || index === 4 ? "Dermatologist" : undefined,
    status: index === 1 || index === 5 ? "pending" : "reviewed", doctorReviewed: index === 3 || index === 4,
    reviewConfirmed: index === 3 || index === 4, doctorNotes: "", clinicalNotes: "", medicalNotes: "",
    recommendedTests: [], recommendationSubmitted: false, appointments: [], demoTestReport: null,
    assessmentDate: new Date(Date.now() - (31 - index * 5) * 86400000).toISOString(), followUpMonths: 3,
  };
}

export function createDemoPatients(): Patient[] {
  return [
    makePatient(1, "Arjun Kumar", 32, [7], "green", "Better"),
    makePatient(2, "Priya Devi", 45, [1, 2, 3], "yellow", "Worse"),
    makePatient(3, "Ravi Shankar", 58, [1, 2, 3, 4, 5, 6, 7, 8], "red", "Worse", { familyHistory: true, uv: true }),
    makePatient(4, "Lakshmi Narayanan", 41, [17], "yellow", "Same"),
    makePatient(5, "Senthil Murugan", 28, [], "green", "Same"),
  ];
}
