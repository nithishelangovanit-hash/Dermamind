export type Screen =
  | "intro"
  | "auth"
  | "patient-dashboard"
  | "assessment"
  | "doctor-dashboard"
  | "patient-report"
  | "lab-recommendations"
  | "admin-dashboard";

export type Role = "patient" | "doctor" | "admin";
export type RiskZone = "red" | "yellow" | "green";
export type SubmissionStatus = "pending" | "reviewed" | "approved" | "rejected";
export type DoctorSpecialty = "Dermatologist";

export interface SymptomEntry {
  id: number;
  name: string;
  group: "ABCDE" | "EFG" | "UD" | "SITE";
  baseScore: number;
  present: boolean;
  answer: "Yes" | "No" | "";
  durationWeek: number | "8+" | "unsure" | null;
  trend: "Better" | "Same" | "Worse" | null;
  frequency: "Rare" | "Occasional" | "Frequent" | null;
  intensity: string | null;
  followUps: Record<string, string | string[]>;
  rule: "ABCDE" | "EFG" | "UD" | "SITE";
  w: number;
  flag: boolean;
  freq: boolean;
  intensityLabels: [string, string, string] | null;
}

export interface TestFinding {
  parameter: string;
  value: string;
  referenceRange: string;
  status: "Normal" | "High" | "Low" | "Abnormal";
}

export interface DemoTestReport {
  generatedAt: string;
  tests: {
    name: string;
    findings: TestFinding[];
    aiSummary: string[];
  }[];
  finalInterpretation: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  doctorName: string;
  specialty: string;
  hospital: string;
  date: string;
  slot: string;
  consultationType: "online" | "offline";
  status: "booked" | "completed" | "rejected";
  doctorAction: "accepted" | "rejected" | "rescheduled" | null;
  rescheduledDate?: string;
  rescheduledSlot?: string;
  bookedAt: string;
}

export interface Patient {
  id: string;
  userEmail: string;
  submittedAt: string;
  // Step 1: Patient Info
  name: string;
  age: number;
  gender: string;
  phone: string;
  place: string;
  // New separate lifestyle fields
  smokingLevel: "Non-Smoker" | "Occasional" | "Frequent";
  alcoholLevel: "Non-Drinker" | "Occasional" | "Frequent";
  // Backward-compat derived fields
  smoking: boolean;
  alcohol: boolean;
  chemicalExposure: boolean;
  radiationExposure: boolean;
  existingDiseases: string;
  familyHistory: boolean;
  // Additional Exposure (multi-select)
  additionalExposure?: string[];
  // Step 2: Symptoms
  symptoms: SymptomEntry[];
  // Step 4: Image
  uploadedImages: string[];
  skinImageScore: number; // 2=normal, 8=suspicious, 15=highly suspicious
  // AI computed
  riskScore: number;
  confidenceScore: number;
  riskZone: RiskZone;
  aiFindingsSummary: string;
  aiRiskFactors: string[];
  riskBreakdown?: Record<string, number>;
  topContributors?: Array<{ name: string; points: number; behavior: string }>;
  assessmentResult?: {
    mlResult: unknown | null;
    ruleResult: unknown;
    finalZone: RiskZone;
    engine: string;
    modelVersion: string | null;
    analysedAt: string;
  };
  // Intelligent doctor routing
  assignedDoctorType?: DoctorSpecialty;
  skinSymptomScore?: number;
  // Status & Doctor actions
  status: SubmissionStatus;
  doctorReviewed: boolean;
  reviewConfirmed: boolean;
  doctorNotes: string;
  // Split note fields (ref-5)
  clinicalNotes?: string;
  medicalNotes?: string;
  recommendedTests: string[];
  recommendationSubmitted?: boolean;
  appointments: Appointment[];
  demoTestReport: DemoTestReport | null;
  // Follow-up date feature
  assessmentDate?: string; // ISO date string of when assessment was completed
  followUpMonths?: number; // User preference: 3, 4, 5, or 6 (defaults to 3)
}

export interface User {
  name: string;
  email: string;
  role: Role;
  specialty?: DoctorSpecialty;
}

export interface Lab {
  id: number;
  name: string;
  city: string;
  distance: number;
  rating: number;
  tests: string[];
  costRange: string;
  category: "low" | "mid" | "high";
}
