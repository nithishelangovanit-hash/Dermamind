import { Toaster } from "@/components/ui/sonner";
import { useEffect, useState } from "react";
import Layout from "./components/Layout";
import { PatientStoreProvider } from "./context/PatientStore";
import AdminDashboard from "./pages/AdminDashboard";
import AssessmentPage from "./pages/AssessmentPage";
import AuthPage from "./pages/AuthPage";
import DoctorDashboard from "./pages/DoctorDashboard";
import IntroPage from "./pages/IntroPage";
import LabRecommendations from "./pages/LabRecommendations";
import PatientDashboard from "./pages/PatientDashboard";
import type { Screen, User } from "./types";

const PUBLIC_SCREENS: Screen[] = ["intro", "auth"];
const USER_KEY = "oncomind_user";
const SCREEN_KEY = "oncomind_screen";

export default function App() {
  const [screen, setScreen] = useState<Screen>(() => {
    try {
      const stored = localStorage.getItem(SCREEN_KEY);
      const user = localStorage.getItem(USER_KEY);
      if (stored && user) return stored as Screen;
    } catch {}
    return "intro";
  });

  const [user, setUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem(USER_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(USER_KEY);
    }
  }, [user]);

  function navigate(s: Screen) {
    setScreen(s);
    if (!PUBLIC_SCREENS.includes(s)) {
      localStorage.setItem(SCREEN_KEY, s);
    } else {
      localStorage.removeItem(SCREEN_KEY);
    }
  }

  function handleLogin(u: User) {
    setUser(u);
    localStorage.setItem(USER_KEY, JSON.stringify(u));
    const dest: Screen =
      u.role === "patient"
        ? "patient-dashboard"
        : u.role === "doctor"
          ? "doctor-dashboard"
          : "admin-dashboard";
    navigate(dest);
  }

  function handleLogout() {
    setUser(null);
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem(SCREEN_KEY);
    setScreen("intro");
  }

  const isPublic = PUBLIC_SCREENS.includes(screen);

  return (
    <PatientStoreProvider>
      <Toaster />
      {isPublic && (
        <>
          {screen === "intro" && <IntroPage onNavigate={navigate} />}
          {screen === "auth" && (
            <AuthPage onNavigate={navigate} onLogin={handleLogin} />
          )}
        </>
      )}
      {!isPublic && !user && (
        <AuthPage onNavigate={navigate} onLogin={handleLogin} />
      )}
      {!isPublic && user && (
        <Layout
          currentScreen={screen}
          user={user}
          onNavigate={navigate}
          onLogout={handleLogout}
        >
          {screen === "patient-dashboard" && (
            <PatientDashboard onNavigate={navigate} user={user} />
          )}
          {screen === "assessment" && (
            <AssessmentPage onNavigate={navigate} user={user} />
          )}
          {screen === "doctor-dashboard" && (
            <DoctorDashboard onNavigate={navigate} user={user} />
          )}
          {screen === "patient-report" && (
            <DoctorDashboard onNavigate={navigate} user={user} />
          )}
          {screen === "lab-recommendations" && <LabRecommendations />}
          {screen === "admin-dashboard" && <AdminDashboard />}
        </Layout>
      )}
    </PatientStoreProvider>
  );
}
