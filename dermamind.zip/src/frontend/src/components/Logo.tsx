// Clean minimal brain icon for DermaMind — no circuit lines, no AI patterns
interface LogoProps {
  variant?: "light" | "dark";
  size?: "sm" | "md" | "lg";
}

export default function Logo({ variant = "dark", size = "md" }: LogoProps) {
  const isLight = variant === "light";

  const titleColor = isLight ? "#ffffff" : "currentColor";
  const subColor = isLight ? "rgba(255,255,255,0.75)" : undefined;
  const subClass = isLight ? "" : "text-muted-foreground";

  // Brain colors: red fill on white bg, white fill on red/dark bg
  const brainFill = isLight ? "#ffffff" : "#E53935";
  const brainStroke = isLight ? "rgba(255,255,255,0.9)" : "#B71C1C";
  const gyriColor = isLight ? "rgba(229,57,53,0.5)" : "rgba(183,28,28,0.55)";

  const sizes = {
    sm: {
      w: 30,
      h: 26,
      titleSize: "0.8125rem",
      titleWeight: "700",
      showSub: false,
    },
    md: { w: 40, h: 34, titleSize: "1rem", titleWeight: "700", showSub: true },
    lg: {
      w: 52,
      h: 44,
      titleSize: "1.25rem",
      titleWeight: "800",
      showSub: true,
    },
  }[size];

  return (
    <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
      {/*
        Simple clean brain SVG — two rounded lobes, medial fissure,
        a few gentle gyri fold lines. No circuit nodes, no AI patterns.
        ViewBox 0 0 64 54
      */}
      <svg
        width={sizes.w}
        height={sizes.h}
        viewBox="0 0 64 54"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        style={{ flexShrink: 0 }}
      >
        {/* ── LEFT HEMISPHERE ─────────────────────────────────────────────── */}
        <path
          d="
            M 6 30
            C 3 26 2 20 4 15
            C 6 9  11 5  17 4
            C 21 3  25 5  27 8
            C 28 10 29 12 29 15
            L 29 38
            C 29 40 27 42 24 43
            C 21 44 17 43 15 41
            C 12 39 10 36 9 33
            C 8 31 7 30 6 30
            Z
          "
          fill={brainFill}
          stroke={brainStroke}
          strokeWidth="1.5"
        />

        {/* ── RIGHT HEMISPHERE ────────────────────────────────────────────── */}
        <path
          d="
            M 58 30
            C 61 26 62 20 60 15
            C 58 9  53 5  47 4
            C 43 3  39 5  37 8
            C 36 10 35 12 35 15
            L 35 38
            C 35 40 37 42 40 43
            C 43 44 47 43 49 41
            C 52 39 54 36 55 33
            C 56 31 57 30 58 30
            Z
          "
          fill={brainFill}
          stroke={brainStroke}
          strokeWidth="1.5"
        />

        {/* ── MEDIAL FISSURE (center groove) ──────────────────────────────── */}
        <path
          d="M 32 7 C 31 14 31 22 32 30 C 33 35 32 40 32 44"
          stroke={brainStroke}
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
        />

        {/* ── BRAIN STEM ──────────────────────────────────────────────────── */}
        <path
          d="M 26 43 C 26 47 38 47 38 43"
          stroke={brainStroke}
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
        />

        {/* ── GYRI FOLDS — LEFT LOBE (natural brain texture, no AI) ───────── */}
        <path
          d="M 12 10 C 16 8 22 9 26 12"
          stroke={gyriColor}
          strokeWidth="1.2"
          fill="none"
          strokeLinecap="round"
        />
        <path
          d="M 8 20 C 13 17 20 17 26 20"
          stroke={gyriColor}
          strokeWidth="1.2"
          fill="none"
          strokeLinecap="round"
        />
        <path
          d="M 9 30 C 14 28 20 28 26 31"
          stroke={gyriColor}
          strokeWidth="1.1"
          fill="none"
          strokeLinecap="round"
        />

        {/* ── GYRI FOLDS — RIGHT LOBE ──────────────────────────────────────── */}
        <path
          d="M 52 10 C 48 8 42 9 38 12"
          stroke={gyriColor}
          strokeWidth="1.2"
          fill="none"
          strokeLinecap="round"
        />
        <path
          d="M 56 20 C 51 17 44 17 38 20"
          stroke={gyriColor}
          strokeWidth="1.2"
          fill="none"
          strokeLinecap="round"
        />
        <path
          d="M 55 30 C 50 28 44 28 38 31"
          stroke={gyriColor}
          strokeWidth="1.1"
          fill="none"
          strokeLinecap="round"
        />
      </svg>

      {/* Text stack */}
      <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
        <span
          style={{
            color: titleColor,
            fontSize: sizes.titleSize,
            fontWeight: sizes.titleWeight,
            lineHeight: 1.2,
            letterSpacing: "-0.01em",
            whiteSpace: "nowrap",
          }}
        >
          DermaMind
        </span>
        {sizes.showSub && (
          <span
            className={subClass}
            style={{
              color: isLight ? subColor : undefined,
              fontSize: size === "lg" ? "0.7rem" : "0.625rem",
              lineHeight: 1.3,
              marginTop: "2px",
              opacity: 0.85,
            }}
          >
            Skin warning signs · screening aid only
          </span>
        )}
      </div>
    </div>
  );
}
