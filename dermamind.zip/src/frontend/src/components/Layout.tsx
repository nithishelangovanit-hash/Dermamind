import {
  Activity,
  Bell,
  ClipboardList,
  FlaskConical,
  Home,
  LayoutDashboard,
  LogOut,
  MapPin,
  Settings,
  Users,
} from "lucide-react";
import type { Screen, User } from "../types";
import Logo from "./Logo";

interface NavItem {
  label: string;
  screen: Screen;
  icon: React.ReactNode;
  roles: Array<"patient" | "doctor" | "admin">;
}

const navItems: NavItem[] = [
  {
    label: "Dashboard",
    screen: "patient-dashboard",
    icon: <Home size={20} />,
    roles: ["patient"],
  },
  {
    label: "Assessment",
    screen: "assessment",
    icon: <ClipboardList size={20} />,
    roles: ["patient"],
  },
  {
    label: "Labs",
    screen: "lab-recommendations",
    icon: <MapPin size={20} />,
    roles: ["patient"],
  },
  {
    label: "Dashboard",
    screen: "doctor-dashboard",
    icon: <LayoutDashboard size={20} />,
    roles: ["doctor"],
  },
  {
    label: "Patients",
    screen: "patient-report",
    icon: <Users size={20} />,
    roles: ["doctor"],
  },
  {
    label: "Labs",
    screen: "lab-recommendations",
    icon: <FlaskConical size={20} />,
    roles: ["doctor"],
  },
  {
    label: "Overview",
    screen: "admin-dashboard",
    icon: <Activity size={20} />,
    roles: ["admin"],
  },
];

interface LayoutProps {
  children: React.ReactNode;
  currentScreen: Screen;
  user: User;
  onNavigate: (screen: Screen) => void;
  onLogout: () => void;
}

export default function Layout({
  children,
  currentScreen,
  user,
  onNavigate,
  onLogout,
}: LayoutProps) {
  const filtered = navItems.filter((n) => n.roles.includes(user.role));

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar - desktop */}
      <aside className="hidden md:flex flex-col w-60 bg-sidebar text-sidebar-foreground flex-shrink-0">
        <div className="p-5 border-b border-sidebar-border">
          <Logo variant="light" />
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {filtered.map((item) => {
            const isActive = currentScreen === item.screen;
            return (
              <button
                type="button"
                key={`${item.label}-${item.screen}`}
                data-ocid={`nav.${item.label.toLowerCase().replace(/\s+/g, "_")}.link`}
                onClick={() => onNavigate(item.screen)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isActive
                    ? "bg-primary text-white"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="p-3 border-t border-sidebar-border">
          <button
            type="button"
            onClick={onLogout}
            data-ocid="nav.logout.button"
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground transition-all"
          >
            <LogOut size={18} />
            Log Out
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="sticky top-0 z-30 bg-card border-b border-border flex items-center justify-between px-4 md:px-6 h-14 shadow-xs">
          <div className="md:hidden">
            <Logo size="sm" />
          </div>
          <div className="hidden md:block text-sm text-muted-foreground">
            Welcome back,{" "}
            <span className="font-semibold text-foreground">{user.name}</span>
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              type="button"
              className="relative p-2 rounded-lg hover:bg-muted transition-colors"
              data-ocid="header.bell.button"
            >
              <Bell size={18} className="text-muted-foreground" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                <span className="text-xs font-bold text-primary">
                  {user.name[0]}
                </span>
              </div>
              <div className="hidden md:block">
                <p className="text-xs font-semibold leading-none">
                  {user.name}
                </p>
                <p className="text-xs text-muted-foreground capitalize">
                  {user.role}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={onLogout}
              className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors"
              data-ocid="header.logout.button"
            >
              <LogOut size={16} className="text-muted-foreground" />
            </button>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto pb-20 md:pb-0">{children}</main>
      </div>

      {/* Bottom nav - mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border z-40 flex">
        {filtered.slice(0, 4).map((item) => {
          const isActive = currentScreen === item.screen;
          return (
            <button
              type="button"
              key={`${item.label}-${item.screen}`}
              onClick={() => onNavigate(item.screen)}
              data-ocid={`bottom_nav.${item.label.toLowerCase().replace(/\s+/g, "_")}.button`}
              className={`flex-1 flex flex-col items-center gap-0.5 py-2 text-xs font-medium transition-colors ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          );
        })}
        <button
          type="button"
          onClick={onLogout}
          className="flex-1 flex flex-col items-center gap-0.5 py-2 text-xs font-medium text-muted-foreground"
          data-ocid="bottom_nav.logout.button"
        >
          <Settings size={20} />
          More
        </button>
      </nav>
    </div>
  );
}
