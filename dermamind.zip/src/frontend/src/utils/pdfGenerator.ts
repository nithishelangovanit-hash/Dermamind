import type { Patient } from "../types";
import { getRiskLabel } from "./riskEngine";

function getRiskZoneMessage(patient: Patient): string {
  if (patient.riskZone === "green")
    return `Screening score ${patient.riskScore}/120. GREEN ZONE. Continue monitoring.`;
  if (patient.riskZone === "yellow")
    return `Screening score ${patient.riskScore}/120. YELLOW ZONE. Dermatologist review is recommended.`;
  return `Screening score ${patient.riskScore}/120. RED ZONE. Arrange a dermatologist review as soon as possible.`;
}

/**
 * User-facing PDF — no AI findings, no test reports, no risk breakdown.
 * Shown only for Yellow/Red zone patients.
 */
export function generateUserReportPDF(patient: Patient): void {
  const presentSymptoms = patient.symptoms.filter((s) => s.present);
  const zoneMessage = getRiskZoneMessage(patient);
  const smokingLevel =
    patient.smokingLevel ?? (patient.smoking ? "Frequent" : "Non-Smoker");
  const alcoholLevel =
    patient.alcoholLevel ?? (patient.alcohol ? "Occasional" : "Non-Drinker");

  const styles = `
    body { font-family: Arial, sans-serif; color: #1a1a1a; margin: 0; padding: 20px; }
    .header { background: #E53935; color: white; padding: 24px; margin: -20px -20px 24px; }
    .header h1 { margin: 0 0 4px; font-size: 20px; }
    .header p { margin: 0; font-size: 12px; opacity: 0.9; }
    .section { margin-bottom: 20px; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; }
    .section-title { background: #fef2f2; border-bottom: 1px solid #e0e0e0; padding: 10px 16px; font-size: 13px; font-weight: bold; color: #c62828; }
    .section-body { padding: 12px 16px; }
    .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .field { margin-bottom: 6px; }
    .label { font-size: 11px; color: #666; }
    .value { font-size: 13px; font-weight: 500; }
    .zone-box { padding: 14px 16px; border-radius: 8px; font-size: 14px; font-weight: bold; margin: 12px 0; }
    .zone-green { background: #e8f5e9; color: #2e7d32; border: 1px solid #c8e6c9; }
    .zone-yellow { background: #fff8e1; color: #e65100; border: 1px solid #ffecb3; }
    .zone-red { background: #ffebee; color: #c62828; border: 1px solid #ffcdd2; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; }
    th { background: #fef2f2; padding: 8px; text-align: left; border-bottom: 2px solid #e0e0e0; }
    td { padding: 7px 8px; border-bottom: 1px solid #f0f0f0; }
    .footer { margin-top: 24px; padding-top: 12px; border-top: 1px solid #e0e0e0; font-size: 11px; color: #999; text-align: center; }
    @media print { body { margin: 0; } }
  `;

  const symptomsTable =
    presentSymptoms.length > 0
      ? `<table>
        <thead><tr><th>Symptom</th><th>Duration</th><th>Frequency</th><th>Trend</th><th>Intensity</th></tr></thead>
        <tbody>
          ${presentSymptoms.map((s) => `<tr><td>${s.name}</td><td>${s.durationWeek === "8+" ? "8+ weeks" : s.durationWeek === "unsure" ? "Not sure" : `Week ${s.durationWeek}`}</td><td>${s.frequency ?? "—"}</td><td>${s.trend ?? "—"}</td><td>${s.intensity ?? "—"}</td></tr>`).join("")}
        </tbody>
      </table>`
      : "<p>No symptoms reported.</p>";

  const zoneClass =
    patient.riskZone === "red"
      ? "zone-red"
      : patient.riskZone === "yellow"
        ? "zone-yellow"
        : "zone-green";

  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>DermaMind Report — ${patient.name}</title>
  <style>${styles}</style>
</head>
<body>
  <div class="header">
    <h1>DermaMind — Personal Risk Report</h1>
    <p>Skin warning-sign screening aid · not a diagnosis</p>
    <p style="margin-top:8px;">Patient ID: ${patient.id} | Generated: ${new Date().toLocaleString()}</p>
  </div>

  <div class="section">
    <div class="section-title">👤 Patient Information</div>
    <div class="section-body grid2">
      <div class="field"><div class="label">Name</div><div class="value">${patient.name}</div></div>
      <div class="field"><div class="label">Patient ID</div><div class="value">${patient.id}</div></div>
      <div class="field"><div class="label">Age</div><div class="value">${patient.age} years</div></div>
      <div class="field"><div class="label">Gender</div><div class="value">${patient.gender}</div></div>
      <div class="field"><div class="label">Phone</div><div class="value">${patient.phone}</div></div>
      <div class="field"><div class="label">Location</div><div class="value">${patient.place}</div></div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">🧬 Lifestyle Habits</div>
    <div class="section-body">
      <div class="grid2">
        <div class="field"><div class="label">Smoking</div><div class="value">${smokingLevel}</div></div>
        <div class="field"><div class="label">Alcohol Consumption</div><div class="value">${alcoholLevel}</div></div>
        <div class="field"><div class="label">Chemical Exposure</div><div class="value">${patient.chemicalExposure ? "Yes" : "No"}</div></div>
        <div class="field"><div class="label">Radiation Exposure</div><div class="value">${patient.radiationExposure ? "Yes" : "No"}</div></div>
        <div class="field"><div class="label">Family History</div><div class="value">${patient.familyHistory ? "Yes" : "No"}</div></div>
        <div class="field"><div class="label">Existing Diseases</div><div class="value">${patient.existingDiseases || "None reported"}</div></div>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">🩺 Reported Symptoms</div>
    <div class="section-body">${symptomsTable}</div>
  </div>

  <div class="section">
    <div class="section-title">🚦 Risk Assessment Result</div>
    <div class="section-body">
      <div class="zone-box ${zoneClass}">${zoneMessage}</div>
      <p style="font-size:12px;color:#666;margin-top:8px;">Submitted: ${new Date(patient.submittedAt).toLocaleDateString()}</p>
    </div>
  </div>

  <div class="footer">
    <p>⚠️ This report is for personal reference only. Consult a qualified physician for medical advice.</p>
    <p>This screening summary is not automatically reviewed by a clinician. Consult a dermatologist about concerning changes.</p>
    <p>DermaMind: prototype rule-based screening aid · not clinically validated</p>
    <p>© ${new Date().getFullYear()} | Built with caffeine.ai</p>
  </div>
</body>
</html>`;

  const w = window.open("", "_blank");
  if (w) {
    w.document.write(html);
    w.document.close();
    setTimeout(() => w.print(), 500);
  }
}

export function generateClinicalReportPDF(patient: Patient): void {
  const presentSymptoms = patient.symptoms.filter((s) => s.present);
  const riskLabel = getRiskLabel(patient.riskZone);
  const smokingLevel =
    patient.smokingLevel ?? (patient.smoking ? "Frequent" : "Non-Smoker");
  const alcoholLevel =
    patient.alcoholLevel ?? (patient.alcohol ? "Occasional" : "Non-Drinker");

  const styles = `
    body { font-family: Arial, sans-serif; color: #1a1a1a; margin: 0; padding: 20px; }
    .header { background: #E53935; color: white; padding: 24px; margin: -20px -20px 24px; }
    .header h1 { margin: 0 0 4px; font-size: 20px; }
    .header p { margin: 0; font-size: 12px; opacity: 0.9; }
    .section { margin-bottom: 20px; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; }
    .section-title { background: #fef2f2; border-bottom: 1px solid #e0e0e0; padding: 10px 16px; font-size: 13px; font-weight: bold; color: #c62828; }
    .section-body { padding: 12px 16px; }
    .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .field { margin-bottom: 6px; }
    .label { font-size: 11px; color: #666; }
    .value { font-size: 13px; font-weight: 500; }
    .risk-badge { display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 13px; font-weight: bold; }
    .risk-red { background: #ffebee; color: #c62828; }
    .risk-yellow { background: #fff8e1; color: #e65100; }
    .risk-green { background: #e8f5e9; color: #2e7d32; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; }
    th { background: #fef2f2; padding: 8px; text-align: left; border-bottom: 2px solid #e0e0e0; }
    td { padding: 7px 8px; border-bottom: 1px solid #f0f0f0; }
    tr:nth-child(even) { background: #fafafa; }
    .bullet { margin: 4px 0; font-size: 12px; }
    .footer { margin-top: 24px; padding-top: 12px; border-top: 1px solid #e0e0e0; font-size: 11px; color: #999; text-align: center; }
    @media print { body { margin: 0; } }
  `;

  const symptomsTable =
    presentSymptoms.length > 0
      ? `<table>
        <thead><tr><th>Symptom</th><th>Group</th><th>Duration</th><th>Frequency</th><th>Trend</th><th>Intensity</th></tr></thead>
        <tbody>
          ${presentSymptoms.map((s) => `<tr><td>${s.name}</td><td>${s.rule}</td><td>${s.durationWeek === "8+" ? "8+ weeks" : s.durationWeek === "unsure" ? "Not sure" : `Week ${s.durationWeek}`}</td><td>${s.frequency ?? "—"}</td><td>${s.trend ?? "—"}</td><td>${s.intensity ?? "—"}</td></tr>`).join("")}
        </tbody>
      </table>`
      : "<p>No symptoms reported.</p>";

  const riskClass =
    patient.riskZone === "red"
      ? "risk-red"
      : patient.riskZone === "yellow"
        ? "risk-yellow"
        : "risk-green";

  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>DermaMind Clinical Report — ${patient.name}</title>
  <style>${styles}</style>
</head>
<body>
  <div class="header">
    <h1>DermaMind — Clinical Screening Report</h1>
    <p>Skin warning-sign screening aid · not a diagnosis</p>
    <p style="margin-top:8px;">Patient ID: ${patient.id} | Generated: ${new Date(patient.submittedAt).toLocaleString()}</p>
  </div>

  <div class="section">
    <div class="section-title">👤 Patient Information</div>
    <div class="section-body grid2">
      <div class="field"><div class="label">Name</div><div class="value">${patient.name}</div></div>
      <div class="field"><div class="label">Patient ID</div><div class="value">${patient.id}</div></div>
      <div class="field"><div class="label">Age</div><div class="value">${patient.age} years</div></div>
      <div class="field"><div class="label">Gender</div><div class="value">${patient.gender}</div></div>
      <div class="field"><div class="label">Phone</div><div class="value">${patient.phone}</div></div>
      <div class="field"><div class="label">Location</div><div class="value">${patient.place}</div></div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">🧬 Lifestyle & Risk Factors</div>
    <div class="section-body">
      <div class="grid2">
        <div class="field"><div class="label">Smoking</div><div class="value">${smokingLevel}</div></div>
        <div class="field"><div class="label">Alcohol Consumption</div><div class="value">${alcoholLevel}</div></div>
        <div class="field"><div class="label">Chemical Exposure</div><div class="value">${patient.chemicalExposure ? "Yes" : "No"}</div></div>
        <div class="field"><div class="label">Radiation Exposure</div><div class="value">${patient.radiationExposure ? "Yes" : "No"}</div></div>
        <div class="field"><div class="label">Family History</div><div class="value">${patient.familyHistory ? "Yes" : "No"}</div></div>
        <div class="field"><div class="label">Existing Diseases</div><div class="value">${patient.existingDiseases || "None reported"}</div></div>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">🩺 Symptom Assessment (YES responses only)</div>
    <div class="section-body">${symptomsTable}</div>
  </div>

  <div class="section">
    <div class="section-title">Rule-based screening assessment</div>
    <div class="section-body">
      <div class="grid2" style="margin-bottom:12px;">
        <div class="field"><div class="label">Screening score</div><div class="value">${patient.riskScore}/120</div></div>
        <div class="field"><div class="label">Risk Zone</div><div class="value"><span class="risk-badge ${riskClass}">${riskLabel}</span></div></div>
        <div class="field"><div class="label">Submitted</div><div class="value">${new Date(patient.submittedAt).toLocaleDateString()}</div></div>
      </div>
      <div style="margin-bottom:10px;"><strong>Rule-based summary:</strong><br/>${patient.aiFindingsSummary}</div>
      <div style="margin-bottom:10px;"><strong>Top contributing symptoms:</strong>${(patient.topContributors ?? []).map((item) => `<div class="bullet">• ${item.name}: ${item.points} points — ${item.behavior}</div>`).join("") || "<div class=\"bullet\">No reported symptoms contributed.</div>"}</div>
      <div style="margin-bottom:10px;"><strong>Risk breakdown by rule:</strong>${Object.entries(patient.riskBreakdown ?? {}).map(([rule, points]) => `<div class="bullet">• ${rule}: ${Math.round(points * 100) / 100} points</div>`).join("")}</div>
      ${patient.aiRiskFactors.length > 0 ? `<div><strong>Risk Factors Identified:</strong>${patient.aiRiskFactors.map((f) => `<div class="bullet">• ${f}</div>`).join("")}</div>` : ""}
    </div>
  </div>

  ${
    patient.doctorNotes
      ? `<div class="section">
    <div class="section-title">📝 Doctor's Notes</div>
    <div class="section-body">${patient.doctorNotes}</div>
  </div>`
      : ""
  }

  ${
    patient.recommendedTests && patient.recommendedTests.length > 0
      ? `<div class="section">
    <div class="section-title">🧪 Recommended Tests</div>
    <div class="section-body">${patient.recommendedTests.map((t) => `<div class="bullet">• ${t}</div>`).join("")}</div>
  </div>`
      : ""
  }

  <div class="footer">
    <p>⚠️ This report is for clinical screening purposes only and does not constitute a medical diagnosis.</p>
    <p>Prototype rule-based scoring. Weights and thresholds are placeholders pending dermatologist review. Not clinically validated.</p>
    <p>Model trained on synthetic data. Prototype, not clinically validated.</p>
    <p>DermaMind: prototype rule-based screening aid · not clinically validated</p>
    <p>© ${new Date().getFullYear()} | Built with caffeine.ai</p>
  </div>
</body>
</html>`;

  const w = window.open("", "_blank");
  if (w) {
    w.document.write(html);
    w.document.close();
    setTimeout(() => w.print(), 500);
  }
}
