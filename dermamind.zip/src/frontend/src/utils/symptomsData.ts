import type { SymptomEntry } from "../types";

export type RuleGroup = "ABCDE" | "EFG" | "UD" | "SITE";
export interface FollowUpDefinition {
  key: string;
  question: string;
  options?: string[];
  multi?: boolean;
}
export interface SymptomDefinition {
  id: number;
  key: string;
  name: string;
  explanation: string;
  rule: RuleGroup;
  w: number;
  flag?: boolean;
  freq?: boolean;
  intensity?: [string, string, string];
  followUps?: FollowUpDefinition[];
}

const follow = (key: string, question: string, options?: string[], multi = false): FollowUpDefinition => ({ key, question, options, multi });

export const SYMPTOM_DEFINITIONS: SymptomDefinition[] = [
  { id: 1, key: "asymmetric_spot", name: "Asymmetric spot", explanation: "One half of the spot does not match the other.", rule: "ABCDE", w: 4, intensity: ["Slight", "Clear", "Marked"], followUps: [follow("halvesDiffer", "Halves differ in?", ["Shape", "Colour", "Both"])] },
  { id: 2, key: "irregular_border", name: "Irregular border", explanation: "Edges may be uneven, ragged, notched, or blurred.", rule: "ABCDE", w: 4, intensity: ["Slightly uneven", "Clearly uneven", "Ragged"], followUps: [follow("edgesAre", "Edges are?", ["Notched", "Blurred", "Both"])] },
  { id: 3, key: "several_colours", name: "Several colours", explanation: "A spot has uneven colour or multiple shades.", rule: "ABCDE", w: 4, intensity: ["2 colours", "3 colours", "4+ colours"], followUps: [follow("coloursSeen", "Colours seen", ["Brown", "Black", "Red", "White", "Blue"], true), follow("darkening", "Darkening over time?", ["Yes", "No"])] },
  { id: 4, key: "wider_than_6mm", name: "Wider than 6 mm", explanation: "Larger than a pencil eraser; some melanomas can be smaller.", rule: "ABCDE", w: 4, intensity: ["6-10 mm", "10-15 mm", "15+ mm"], followUps: [follow("measurement", "Measured or estimated?", ["Measured", "Estimated", "Not sure"]), follow("growthSpeed", "Growth speed?", ["Slow", "Rapid", "No visible growth"])] },
  { id: 5, key: "size_change", name: "Change in size", explanation: "A spot that has changed in size over time.", rule: "ABCDE", w: 5, intensity: ["Slight", "Noticeable", "Marked"], followUps: [follow("previousSizeKnown", "Previous size known?", ["Yes", "No"])] },
  { id: 6, key: "shape_colour_change", name: "Shape or colour change", explanation: "A spot that is evolving in shape or colour.", rule: "ABCDE", w: 5, intensity: ["Slight", "Noticeable", "Marked"], followUps: [follow("whatChanged", "What changed?", ["Shape", "Colour", "Both"])] },
  { id: 7, key: "itching", name: "Itching", explanation: "Itching in or around a spot.", rule: "ABCDE", w: 2, freq: true, intensity: ["Mild", "Moderate", "Severe"], followUps: [follow("trigger", "Trigger?", ["Sweat", "Allergy", "No specific trigger"]), follow("wakesAtNight", "Wakes you at night?", ["Yes", "No"])] },
  { id: 8, key: "bleeding_without_injury", name: "Bleeding without injury", explanation: "A spot that bleeds without a scratch or injury.", rule: "ABCDE", w: 5, flag: true, freq: true, intensity: ["Spotting", "Light", "Heavy"], followUps: [follow("injuryBefore", "Any scratch or injury before?", ["Yes", "No"]), follow("stopsByItself", "Stops by itself?", ["Yes", "No"])] },
  { id: 9, key: "crusting_scabbing", name: "Crusting or scabbing", explanation: "A spot that forms a crust or scab, sometimes healing and returning.", rule: "EFG", w: 3, freq: true, intensity: ["Thin", "Moderate", "Thick"], followUps: [follow("healsReturns", "Heals and returns?", ["Yes", "No"])] },
  { id: 10, key: "pain_tenderness", name: "Pain or tenderness", explanation: "Pain, tenderness, or burning in a spot.", rule: "EFG", w: 2, freq: true, intensity: ["Mild", "Moderate", "Severe"], followUps: [follow("painPattern", "Constant or only on touch?", ["Constant", "Only on touch", "Both"]), follow("burning", "Burning?", ["Yes", "No"])] },
  { id: 11, key: "raised_above_skin", name: "Raised above the skin", explanation: "A spot elevated above the surrounding skin.", rule: "EFG", w: 3, intensity: ["Slightly", "Clearly", "Strongly"], followUps: [follow("wasFlat", "Was it flat before?", ["Yes", "No"])] },
  { id: 12, key: "firm_or_hard", name: "Firm or hard", explanation: "A spot or lump that feels firm or hard.", rule: "EFG", w: 4, intensity: ["Slightly firm", "Firm", "Stony hard"], followUps: [follow("mobility", "Fixed or movable?", ["Fixed", "Movable"]), follow("painfulPressing", "Painful on pressing?", ["Yes", "No"])] },
  { id: 13, key: "growing_fast", name: "Growing fast", explanation: "A spot or lump increasing in size over time.", rule: "EFG", w: 5, intensity: ["Slow", "Moderate", "Rapid"], followUps: [follow("sizeGainWeeks", "Size gain over how many weeks?", ["1-2", "3-4", "5-8"])] },
  { id: 14, key: "hard_lump", name: "Hard lump", explanation: "A firm lump under or on the skin.", rule: "EFG", w: 4, intensity: ["Pea-sized", "Marble-sized", "Larger"], followUps: [follow("mobility", "Fixed or movable?", ["Fixed", "Movable"]), follow("painful", "Painful?", ["Yes", "No"])] },
  { id: 15, key: "shiny_pearly_bump", name: "Shiny or pearly bump", explanation: "A smooth, shiny, or pearly-looking bump.", rule: "EFG", w: 3, intensity: ["Small", "Medium", "Large"], followUps: [follow("colour", "Colour?", ["Pink", "White", "Skin-coloured"]), follow("visibleVessels", "Tiny visible blood vessels?", ["Yes", "No"])] },
  { id: 16, key: "scaly_rough_patch", name: "Scaly or rough patch", explanation: "A rough or scaly patch on the skin.", rule: "EFG", w: 3, freq: true, intensity: ["Mild", "Moderate", "Heavy"], followUps: [follow("sunExposed", "On a sun-exposed area?", ["Yes", "No"]), follow("sandpaper", "Feels like sandpaper?", ["Yes", "No"])] },
  { id: 17, key: "non_healing_sore_4wk", name: "Non-healing sore (4+ weeks)", explanation: "A sore that does not heal or repeatedly opens.", rule: "EFG", w: 5, flag: true, followUps: [follow("size", "Size?", ["Under 5 mm", "5-10 mm", "Over 10 mm"]), follow("reopens", "Reopens after healing?", ["Yes", "No"]), follow("infectionHistory", "Any infection history there?", ["Yes", "No"])] },
  { id: 18, key: "red_swollen_area", name: "Red or swollen area", explanation: "Redness or swelling around a spot.", rule: "EFG", w: 2, freq: true, intensity: ["Slight", "Moderate", "Marked"], followUps: [follow("warmOrTender", "Warm or tender?", ["Yes", "No"]), follow("aroundMole", "Around a mole?", ["Yes", "No"])] },
  { id: 19, key: "open_oozing_spot", name: "Open or oozing spot", explanation: "An open spot with fluid or discharge.", rule: "EFG", w: 3, freq: true, intensity: ["Damp", "Wet", "Dripping"], followUps: [follow("discharge", "Discharge is?", ["Clear fluid", "Blood", "Pus"]), follow("smell", "Any smell?", ["Yes", "No"])] },
  { id: 20, key: "looks_different_from_other_moles", name: "Looks different from other moles", explanation: "One spot stands out from your other moles.", rule: "UD", w: 4, intensity: ["Slightly", "Clearly", "Very different"], followUps: [follow("differentIn", "Different in", ["Colour", "Size", "Shape"], true)] },
  { id: 21, key: "new_spot_last_3_months", name: "New spot in the last 3 months", explanation: "A new spot that appeared recently.", rule: "UD", w: 3, followUps: [follow("bodyLocation", "Body location?", ["Face or neck", "Trunk", "Arms", "Legs", "Hands or feet", "Scalp"]), follow("changedSinceSeen", "Changed since first seen?", ["Yes", "No"])] },
  { id: 22, key: "stands_out_from_skin", name: "Stands out from your skin", explanation: "A spot that looks noticeably different from nearby skin or other moles.", rule: "UD", w: 2, followUps: [follow("someoneNoticed", "Did someone else notice?", ["Yes", "No"])] },
  { id: 23, key: "dark_streak_under_nail", name: "Dark streak under a nail", explanation: "A dark lengthwise streak under a nail, especially if new or widening.", rule: "SITE", w: 5, flag: true, intensity: ["Faint", "Clear", "Very dark"], followUps: [follow("newOrOld", "New or old?", ["New", "Been there a while"]), follow("nailInjury", "Nail injury before?", ["Yes", "No"]), follow("widening", "Is the streak widening?", ["Yes", "No"])] },
  { id: 24, key: "dark_spot_palm_or_sole", name: "Dark spot on palm or sole", explanation: "A dark spot on the palm of a hand or sole of a foot.", rule: "SITE", w: 4, intensity: ["Faint", "Clear", "Very dark"], followUps: [follow("newOrOld", "New or old?", ["New", "Been there a while"]), follow("irregularEdges", "Irregular edges?", ["Yes", "No"]), follow("pressurePoint", "On a pressure point?", ["Yes", "No"])] },
  { id: 25, key: "changing_spot_ear_lip_scalp", name: "Changing spot on ear, lip, or scalp", explanation: "A changing spot on the ear, lip, or scalp.", rule: "SITE", w: 4, intensity: ["Slight", "Noticeable", "Marked"], followUps: [follow("site", "Which site?", ["Ear", "Lip", "Scalp"]), follow("scalyOrBleeds", "Scaly or bleeds easily?", ["Yes", "No"])] },
];

export const SYMPTOM_EXPLANATIONS = Object.fromEntries(SYMPTOM_DEFINITIONS.map((s) => [s.name, s.explanation]));
export const SYMPTOM_CONTEXT_QUESTIONS = Object.fromEntries(SYMPTOM_DEFINITIONS.map((s) => [s.name, s.followUps ?? []]));

export function createDefaultSymptoms(): SymptomEntry[] {
  return SYMPTOM_DEFINITIONS.map((s) => ({
    id: s.id, name: s.name, group: s.rule, baseScore: s.w, present: false,
    answer: "" as const, durationWeek: null, trend: null, frequency: null,
    intensity: null, followUps: {}, rule: s.rule, w: s.w, flag: !!s.flag, freq: !!s.freq,
    intensityLabels: s.intensity ?? null,
  }));
}

export function validateVisibleSymptomAnswers(symptoms: SymptomEntry[]): string[] {
  const errors: string[] = [];
  for (const symptom of symptoms) {
    if (!symptom.answer) { errors.push(`${symptom.name}: choose Yes or No`); continue; }
    if (!symptom.present) continue;
    if (!symptom.durationWeek) errors.push(`${symptom.name}: choose a duration`);
    if (!symptom.trend) errors.push(`${symptom.name}: choose a trend`);
    if (symptom.freq && !symptom.frequency) errors.push(`${symptom.name}: choose a frequency`);
    if (symptom.intensityLabels && !symptom.intensity) errors.push(`${symptom.name}: choose an intensity`);
    for (const q of SYMPTOM_DEFINITIONS[symptom.id - 1].followUps ?? []) {
      const value = symptom.followUps?.[q.key];
      if (q.multi ? !Array.isArray(value) || value.length === 0 : !value) errors.push(`${symptom.name}: answer “${q.question}”`);
    }
  }
  return errors;
}
