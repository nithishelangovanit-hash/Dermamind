import type { RiskZone, SymptomEntry } from "../types";

// Prototype rule-based scoring. Weights and thresholds are placeholders pending dermatologist review.
export const RISK_CONFIG = {
  durationMult: { "1-2": 0.6, "3-4": 0.8, "5-8": 1.0, "8+": 1.2, unsure: 0.8 },
  trendMult: { Better: 0.5, Same: 1.0, Worse: 1.5 },
  intensityMult: [0.8, 1.0, 1.2] as const,
  frequencyMult: { Rare: 0.8, Occasional: 1.0, Frequent: 1.2 },
  riskFactors: { age50Plus: 3, age35To49: 1, familyHistory: 3, radiationOrUv: 3, chemicalExposure: 1, pollution: 0, smoking: 0, alcohol: 0 },
  score: { max: 120, greenMax: 29, yellowMax: 69, redMin: 70 },
  overrides: { abcdeYesCount: 3, redFlagIds: [8, 17, 23] as number[] },
} as const;

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "";
export const ML_FEATURES = {
  Asymmetric_Spot: 1,
  Irregular_Border: 2,
  Multiple_Colours: 3,
  Diameter_Over_6mm: 4,
  Change_in_Size: 5,
  Change_in_Shape_or_Colour: 6,
  Bleeding_Without_Injury: 8,
  Firm_or_Hard: 12,
  Growing_Fast: 13,
  Sore_Not_Healing_4wk: 17,
  Looks_Different_From_Other_Moles: 20,
  Dark_Streak_Under_Nail: 23,
} as const;
export interface ModelConsent { collect_details: boolean; analyse_photo: boolean; use_location: boolean; share_with_doctor: boolean }
export type ModelAnalysis = Record<string, unknown> & { model_version: string };

// Send only the allowlisted binary symptom fields and four consent flags.
export async function analyseModel(symptoms: SymptomEntry[], consent: ModelConsent): Promise<ModelAnalysis | null> {
  if (!API_BASE_URL) return null;
  const binarySymptoms = Object.fromEntries(Object.entries(ML_FEATURES).map(([feature, id]) => [feature, symptoms.find((s) => s.id === id)?.answer === "Yes" || symptoms.find((s) => s.id === id)?.present ? 1 : 0]));
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(`${API_BASE_URL.replace(/\/$/, "")}/analyse`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ symptoms: binarySymptoms, consent }), signal: controller.signal });
    if (!response.ok) return null;
    return await response.json() as ModelAnalysis;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

export interface RiskInput {
  symptoms: SymptomEntry[];
  age: number;
  place: string;
  smokingLevel: "Non-Smoker" | "Occasional" | "Frequent";
  alcoholLevel: "Non-Drinker" | "Occasional" | "Frequent";
  smoking?: boolean;
  alcohol?: boolean;
  chemicalExposure: boolean;
  radiationExposure: boolean;
  existingDiseases: string;
  familyHistory: boolean;
  skinImageScore: number;
}

export interface RiskResult {
  score: number;
  confidence: number;
  riskZone: RiskZone;
  aiFindings: string;
  aiRiskFactors: string[];
  riskBreakdown: Record<string, number>;
  topContributors: Array<{ name: string; points: number; behavior: string }>;
  riskFactorScore: number;
  safetyRuleApplied: boolean;
}

function durationMultiplier(value: SymptomEntry["durationWeek"]): number {
  if (value === "8+") return RISK_CONFIG.durationMult["8+"];
  if (value === "unsure" || value === null) return RISK_CONFIG.durationMult.unsure;
  if (value <= 2) return RISK_CONFIG.durationMult["1-2"];
  if (value <= 4) return RISK_CONFIG.durationMult["3-4"];
  return RISK_CONFIG.durationMult["5-8"];
}

function symptomPoints(s: SymptomEntry): number {
  if (s.answer !== "Yes" && !s.present) return 0;
  const intensityIndex = s.intensityLabels?.indexOf(s.intensity ?? "") ?? -1;
  const intensity = intensityIndex < 0 ? 1 : RISK_CONFIG.intensityMult[intensityIndex as 0 | 1 | 2];
  return s.w * durationMultiplier(s.durationWeek) * RISK_CONFIG.trendMult[s.trend ?? "Same"] * intensity * (s.freq ? RISK_CONFIG.frequencyMult[s.frequency ?? "Occasional"] : 1);
}

function zoneForScore(score: number): RiskZone {
  if (score >= RISK_CONFIG.score.redMin) return "red";
  if (score > RISK_CONFIG.score.greenMax) return "yellow";
  return "green";
}

export function calculateRisk(input: RiskInput): RiskResult {
  const yes = input.symptoms.filter((s) => s.answer === "Yes" || s.present);
  const contributions = yes.map((s) => ({
    name: s.name,
    points: Number(symptomPoints(s).toFixed(2)),
    behavior: [
      `duration ${s.durationWeek === "8+" ? "8+ weeks" : s.durationWeek === "unsure" ? "not sure" : `week ${s.durationWeek ?? "not recorded"}`}`,
      `trend ${s.trend ?? "not recorded"}`,
      ...(s.freq ? [`frequency ${s.frequency ?? "not recorded"}`] : []),
      ...(s.intensityLabels ? [`intensity ${s.intensity ?? "not recorded"}`] : []),
      ...Object.entries(s.followUps ?? {}).map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(", ") : value}`),
    ].join("; "),
  }));
  const factorPoints: string[] = [];
  let riskFactorScore = 0;
  if (input.age >= 50) { riskFactorScore += RISK_CONFIG.riskFactors.age50Plus; factorPoints.push(`Age 50 or more (+${RISK_CONFIG.riskFactors.age50Plus})`); }
  else if (input.age >= 35) { riskFactorScore += RISK_CONFIG.riskFactors.age35To49; factorPoints.push(`Age 35–49 (+${RISK_CONFIG.riskFactors.age35To49})`); }
  if (input.familyHistory) { riskFactorScore += RISK_CONFIG.riskFactors.familyHistory; factorPoints.push(`Family history (+${RISK_CONFIG.riskFactors.familyHistory})`); }
  if (input.radiationExposure) { riskFactorScore += RISK_CONFIG.riskFactors.radiationOrUv; factorPoints.push(`Radiation or UV exposure (+${RISK_CONFIG.riskFactors.radiationOrUv})`); }
  if (input.chemicalExposure) { riskFactorScore += RISK_CONFIG.riskFactors.chemicalExposure; factorPoints.push(`Chemical exposure (+${RISK_CONFIG.riskFactors.chemicalExposure})`); }
  const riskBreakdown: Record<string, number> = { ABCDE: 0, EFG: 0, "Ugly Duckling": 0, "Special sites": 0, "Risk factors": riskFactorScore };
  for (const s of yes) {
    const label = s.rule === "UD" ? "Ugly Duckling" : s.rule === "SITE" ? "Special sites" : s.rule;
    riskBreakdown[label] += symptomPoints(s);
  }
  const raw = contributions.reduce((sum, c) => sum + c.points, 0) + riskFactorScore;
  const score = Math.min(RISK_CONFIG.score.max, Math.round(raw));
  let riskZone = zoneForScore(score);
  const safetyRuleApplied = yes.some((s) => RISK_CONFIG.overrides.redFlagIds.includes(s.id));
  const abcdeYesCount = yes.filter((s) => s.id >= 1 && s.id <= 6).length;
  if ((safetyRuleApplied || abcdeYesCount >= RISK_CONFIG.overrides.abcdeYesCount) && riskZone === "green") riskZone = "yellow";
  const reasons = [...contributions].sort((a, b) => b.points - a.points).slice(0, 3);
  const riskFactors = factorPoints.length ? factorPoints : ["No scored risk factors reported"];
  const aiFindings = `Rule-based screening score: ${score}/120 (${riskZone} zone). This is not a probability or diagnosis.`;
  return {
    score,
    confidence: 0,
    riskZone,
    aiFindings,
    aiRiskFactors: riskFactors,
    riskBreakdown,
    topContributors: reasons,
    riskFactorScore,
    safetyRuleApplied,
  };
}

export function getRiskZone(score: number): RiskZone { return zoneForScore(Number.isFinite(score) ? score : 0); }
export function getRiskLabel(zone: RiskZone): string { return zone === "red" ? "Higher screening concern" : zone === "yellow" ? "Review advised" : "Lower screening concern"; }
export function getRiskColors(zone: RiskZone): { bg: string; text: string; border: string; badge: string } {
  if (zone === "red") return { bg: "bg-red-50", text: "text-red-700", border: "border-red-200", badge: "bg-red-100 text-red-700" };
  if (zone === "yellow") return { bg: "bg-amber-50", text: "text-amber-700", border: "border-amber-200", badge: "bg-amber-100 text-amber-700" };
  return { bg: "bg-green-50", text: "text-green-700", border: "border-green-200", badge: "bg-green-100 text-green-700" };
}
