import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Activity,
  Calendar,
  CheckCircle,
  ClipboardList,
  Download,
  MessageSquare,
  RefreshCcw,
  Search,
  Stethoscope,
  Users,
  Video,
  XCircle,
} from "lucide-react";
import { useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { usePatientStore } from "../context/PatientStore";
import type { Appointment, Patient, Screen, User } from "../types";
import { generateClinicalReportPDF } from "../utils/pdfGenerator";
import { getRiskColors, getRiskLabel } from "../utils/riskEngine";

interface Props {
  onNavigate: (screen: Screen) => void;
  onSelectPatient?: (p: Patient | null) => void;
  user?: User;
}

const TIME_SLOTS = [
  "9:00 AM",
  "10:00 AM",
  "11:00 AM",
  "2:00 PM",
  "3:00 PM",
  "4:00 PM",
];
const NEXT_7_DAYS = Array.from({ length: 7 }, (_, i) => {
  const d = new Date();
  d.setDate(d.getDate() + i + 1);
  return {
    label: d.toLocaleDateString("en-IN", {
      weekday: "short",
      day: "numeric",
      month: "short",
    }),
    value: d.toISOString().split("T")[0],
  };
});

export default function DoctorDashboard({
  onNavigate: _onNavigate,
  user,
}: Props) {
  const { patients, updatePatient } = usePatientStore();
  const [search, setSearch] = useState("");
  const [filterZone, setFilterZone] = useState<
    "all" | "red" | "yellow" | "green"
  >("all");
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [notes, setNotes] = useState("");
  const [clinicalNotes, setClinicalNotes] = useState("");
  const [medicalNotes, setMedicalNotes] = useState("");
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [recommendationNote, setRecommendationNote] = useState("");
  const [customTestInput, setCustomTestInput] = useState("");

  // Determine doctor specialty from logged-in user
  const doctorSpecialty = "Dermatologist";

  // Only show patients where reviewConfirmed === true
  // All skin screening reports are routed to dermatologists.
  const visiblePatients = patients.filter((p) => {
    if (
      p.reviewConfirmed !== true &&
      p.reviewConfirmed !== undefined &&
      p.reviewConfirmed !== null
    ) {
      // strict: must be confirmed
      return false;
    }
    // Existing unconfirmed records remain visible to the dermatologist.
    if (p.reviewConfirmed === undefined) {
      return true;
    }
    if (!p.reviewConfirmed) return false;
    // Filter by assigned type
    if (!p.assignedDoctorType) {
      return true;
    }
    return p.assignedDoctorType === doctorSpecialty;
  });

  const filtered = visiblePatients.filter((p) => {
    const matchSearch =
      !search ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.id.toLowerCase().includes(search.toLowerCase());
    const matchZone = filterZone === "all" || p.riskZone === filterZone;
    return matchSearch && matchZone;
  });

  function openPatient(p: Patient) {
    setSelectedPatient(p);
    setNotes(p.doctorNotes || "");
    setSelectedTests(p.recommendedTests || []);
    // Auto-fill default messages for Yellow/Red zone (ref-4)
    const existingClinical = p.clinicalNotes || p.doctorNotes || "";
    const existingMedical = p.medicalNotes || "";
    if (existingClinical) {
      setClinicalNotes(existingClinical);
    } else if (p.riskZone === "yellow") {
      setClinicalNotes(
        "I declare that you are in the Yellow Zone. You have some chances of early-stage cancer. It is recommended to consult a doctor offline for confirmation.",
      );
    } else if (p.riskZone === "red") {
      setClinicalNotes(
        "I declare that you are in the Red Zone. Your symptoms indicate a higher risk of serious condition. Please take immediate medical action and consult a doctor.",
      );
    } else {
      setClinicalNotes("");
    }
    setMedicalNotes(existingMedical);
    setRecommendationNote(p.doctorNotes || "");
  }

  function handleApprove() {
    if (!selectedPatient) return;
    updatePatient(selectedPatient.id, {
      status: "approved",
      doctorReviewed: true,
      doctorNotes: notes,
      clinicalNotes: clinicalNotes,
      medicalNotes: medicalNotes,
      recommendedTests: selectedTests,
    });
    setSelectedPatient({
      ...selectedPatient,
      status: "approved",
      doctorReviewed: true,
      doctorNotes: notes,
      clinicalNotes,
      medicalNotes,
      recommendedTests: selectedTests,
    });
  }

  function handleReject() {
    if (!selectedPatient) return;
    updatePatient(selectedPatient.id, {
      status: "rejected",
      doctorReviewed: true,
      doctorNotes: notes,
      clinicalNotes: clinicalNotes,
      medicalNotes: medicalNotes,
    });
    setSelectedPatient({
      ...selectedPatient,
      status: "rejected",
      doctorReviewed: true,
      doctorNotes: notes,
      clinicalNotes,
      medicalNotes,
    });
  }

  function handleSubmitRecommendation() {
    if (!selectedPatient) return;
    updatePatient(selectedPatient.id, {
      recommendedTests: selectedTests,
      doctorNotes: clinicalNotes || recommendationNote,
      clinicalNotes: clinicalNotes,
      medicalNotes: medicalNotes,
      recommendationSubmitted: true,
    });
    setSelectedPatient({
      ...selectedPatient,
      recommendedTests: selectedTests,
      doctorNotes: clinicalNotes || recommendationNote,
      clinicalNotes,
      medicalNotes,
      recommendationSubmitted: true,
    });
  }

  // Chart data
  const riskCounts = { green: 0, yellow: 0, red: 0 };
  for (const p of patients) riskCounts[p.riskZone]++;
  const pieData = [
    { name: "Low Risk", value: riskCounts.green, color: "#22c55e" },
    { name: "Moderate", value: riskCounts.yellow, color: "#f59e0b" },
    { name: "High Risk", value: riskCounts.red, color: "#ef4444" },
  ].filter((d) => d.value > 0);

  const symptomFreq: Record<string, number> = {};
  for (const p of patients) {
    for (const s of p.symptoms.filter((x) => x.present)) {
      symptomFreq[s.name] = (symptomFreq[s.name] || 0) + 1;
    }
  }
  const barData = Object.entries(symptomFreq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, count]) => ({ name: name.split(" ")[0], count }));

  const waveData = patients
    .slice()
    .reverse()
    .map((p, i) => ({
      name: `#${i + 1}`,
      score: p.riskScore,
      confidence: p.confidenceScore,
    }));

  const allAppointments = patients.flatMap((p) =>
    (p.appointments || []).map((a) => ({
      ...a,
      patientName: p.name,
      patientId: p.id,
    })),
  );

  // Group the same chart by the skin screening rules.
  const stackedBarData = patients.slice(0, 8).map((p) => ({
    name: p.name.split(" ")[0],
    abcde: p.riskBreakdown?.ABCDE ?? 0,
    efg: p.riskBreakdown?.EFG ?? 0,
    duckling: p.riskBreakdown?.["Ugly Duckling"] ?? 0,
    sites: p.riskBreakdown?.["Special sites"] ?? 0,
    factors: p.riskBreakdown?.["Risk factors"] ?? 0,
  }));

  // Timeline: cumulative cases
  const timelineData = patients
    .slice()
    .reverse()
    .map((_, i) => ({ name: `#${i + 1}`, total: i + 1 }));

  // Funnel data
  const funnelData = [
    { name: "Total Screened", value: patients.length, fill: "#E53935" },
    {
      name: "High Risk (Red)",
      value: patients.filter((p) => p.riskZone === "red").length,
      fill: "#c62828",
    },
    {
      name: "Reviewed",
      value: patients.filter((p) => p.doctorReviewed).length,
      fill: "#8d0000",
    },
  ];

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      {selectedPatient ? (
        <PatientDetailView
          patient={selectedPatient}
          onBack={() => setSelectedPatient(null)}
          notes={notes}
          onNotesChange={setNotes}
          clinicalNotes={clinicalNotes}
          onClinicalNotesChange={setClinicalNotes}
          medicalNotes={medicalNotes}
          onMedicalNotesChange={setMedicalNotes}
          onApprove={handleApprove}
          onReject={handleReject}
          onDownloadPDF={() => generateClinicalReportPDF(selectedPatient)}
          recommendationNote={recommendationNote}
          onRecommendationNoteChange={setRecommendationNote}
          customTestInput={customTestInput}
          onCustomTestInputChange={setCustomTestInput}
          onAddCustomTest={() => {
            if (
              customTestInput.trim() &&
              !selectedTests.includes(customTestInput.trim())
            ) {
              setSelectedTests((prev) => [...prev, customTestInput.trim()]);
              setCustomTestInput("");
            }
          }}
          onToggleTest={(test: string) =>
            setSelectedTests((prev) =>
              prev.includes(test)
                ? prev.filter((t) => t !== test)
                : [...prev, test],
            )
          }
          onRemoveTest={(test: string) =>
            setSelectedTests((prev) => prev.filter((t) => t !== test))
          }
          onSubmitRecommendation={handleSubmitRecommendation}
          selectedTests={selectedTests}
        />
      ) : (
        <Tabs defaultValue="patients">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-xl font-bold">Doctor Dashboard</h1>
              <div className="flex items-center gap-2 mt-1">
                <Stethoscope size={13} className="text-primary" />
                <span className="text-xs text-primary font-semibold">
                  {doctorSpecialty}
                  {doctorSpecialty === "Dermatologist" ? " — Skin Specialist" : " — Cancer Specialist"}
                </span>
                <Badge className="bg-primary/10 text-primary border-0 text-xs">
                  Showing assigned cases only
                </Badge>
              </div>
            </div>
            <TabsList>
              <TabsTrigger value="patients" data-ocid="doctor.patients.tab">
                Patients
              </TabsTrigger>
              <TabsTrigger
                value="appointments"
                data-ocid="doctor.appointments.tab"
              >
                Appointments
              </TabsTrigger>
              <TabsTrigger value="analytics" data-ocid="doctor.analytics.tab">
                Analytics
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="patients" className="space-y-4">
            <div className="flex gap-3 flex-wrap">
              <div className="relative flex-1 min-w-48">
                <Search
                  size={14}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search patients..."
                  className="pl-8"
                  data-ocid="doctor.search.search_input"
                />
              </div>
              <select
                value={filterZone}
                onChange={(e) =>
                  setFilterZone(e.target.value as typeof filterZone)
                }
                className="border border-input rounded-lg px-3 py-2 text-sm bg-background"
                data-ocid="doctor.filter_zone.select"
              >
                <option value="all">All Zones</option>
                <option value="red">High Risk</option>
                <option value="yellow">Moderate</option>
                <option value="green">Low Risk</option>
              </select>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg px-3 py-2">
              <p className="text-xs text-blue-700">
                📋 Reports appear here after patient confirms review.
              </p>
            </div>

            {filtered.length === 0 ? (
              <div
                className="bg-card rounded-xl border border-border p-10 text-center"
                data-ocid="doctor.patients.empty_state"
              >
                <Users
                  size={32}
                  className="mx-auto mb-3 text-muted-foreground"
                />
                <p className="text-sm text-muted-foreground">
                  No patients found. Patients will appear here after they
                  confirm their assessment.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {filtered.map((p, i) => {
                  const colors = getRiskColors(p.riskZone);
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => openPatient(p)}
                      className="w-full bg-card rounded-xl border border-border p-4 flex items-center gap-4 hover:border-primary/30 transition-all text-left"
                      data-ocid={`doctor.patient.item.${i + 1}`}
                    >
                      <div
                        className={`w-10 h-10 ${colors.bg} rounded-full flex items-center justify-center flex-shrink-0`}
                      >
                        <span className={`text-sm font-bold ${colors.text}`}>
                          {p.name[0]}
                        </span>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm">
                            {p.name}
                          </span>
                          <Badge className={`text-xs ${colors.badge} border-0`}>
                            {getRiskLabel(p.riskZone)}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          ID: {p.id} &bull; Age: {p.age} &bull; {p.place}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-medium">
                          {new Date(p.submittedAt).toLocaleDateString("en-IN")}
                        </p>
                        <Badge variant="outline" className="text-xs mt-1">
                          {p.status}
                        </Badge>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="appointments" className="space-y-4">
            <AppointmentsManager
              appointments={allAppointments}
              patients={patients}
              onUpdate={updatePatient}
            />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <DoctorAnalytics
              patients={patients}
              pieData={pieData}
              barData={barData}
              waveData={waveData}
              stackedBarData={stackedBarData}
              timelineData={timelineData}
              funnelData={funnelData}
            />
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}

function PatientDetailView({
  patient,
  onBack,
  notes,
  onNotesChange,
  clinicalNotes,
  onClinicalNotesChange,
  medicalNotes,
  onMedicalNotesChange,
  onApprove,
  onReject,
  onDownloadPDF,
  recommendationNote,
  onRecommendationNoteChange,
  customTestInput,
  onCustomTestInputChange,
  onAddCustomTest,
  onToggleTest,
  onRemoveTest,
  onSubmitRecommendation,
  selectedTests,
}: {
  patient: Patient;
  onBack: () => void;
  notes: string;
  onNotesChange: (v: string) => void;
  clinicalNotes: string;
  onClinicalNotesChange: (v: string) => void;
  medicalNotes: string;
  onMedicalNotesChange: (v: string) => void;
  onApprove: () => void;
  onReject: () => void;
  onDownloadPDF: () => void;
  recommendationNote: string;
  onRecommendationNoteChange: (v: string) => void;
  customTestInput: string;
  onCustomTestInputChange: (v: string) => void;
  onAddCustomTest: () => void;
  onToggleTest: (test: string) => void;
  onRemoveTest: (test: string) => void;
  onSubmitRecommendation: () => void;
  selectedTests: string[];
}) {
  const colors = getRiskColors(patient.riskZone);
  const presentSymptoms = patient.symptoms.filter((s) => s.present);
  const canDownloadPDF = patient.riskZone !== "green";
  const smokingLevel =
    patient.smokingLevel ?? (patient.smoking ? "Frequent" : "Non-Smoker");
  const alcoholLevel =
    patient.alcoholLevel ?? (patient.alcohol ? "Occasional" : "Non-Drinker");

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onBack}
          className="text-muted-foreground hover:text-foreground"
          data-ocid="doctor.back.button"
        >
          ← Back
        </button>
        <h2 className="text-lg font-bold">{patient.name}</h2>
        <Badge className={`${colors.badge} border-0`}>
          {getRiskLabel(patient.riskZone)}
        </Badge>
      </div>

      {/* Patient info */}
      <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
        <h3 className="text-sm font-bold mb-3">👤 Patient Information</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
          {[
            ["ID", patient.id],
            ["Age", `${patient.age} yrs`],
            ["Gender", patient.gender],
            ["Phone", patient.phone],
            ["Place", patient.place],
            ["Smoking", smokingLevel],
            ["Alcohol", alcoholLevel],
            ["Chemical Exp.", patient.chemicalExposure ? "Yes" : "No"],
            ["Radiation Exp.", patient.radiationExposure ? "Yes" : "No"],
            ["Family History", patient.familyHistory ? "Yes" : "No"],
          ].map(([l, v]) => (
            <div key={l}>
              <span className="text-xs text-muted-foreground">{l}: </span>
              <span className="text-xs font-medium">{v}</span>
            </div>
          ))}
          {patient.existingDiseases && (
            <div className="col-span-2 md:col-span-3">
              <span className="text-xs text-muted-foreground">Diseases: </span>
              <span className="text-xs font-medium">
                {patient.existingDiseases}
              </span>
            </div>
          )}
          {patient.additionalExposure &&
            patient.additionalExposure.length > 0 && (
              <div className="col-span-2 md:col-span-3">
                <span className="text-xs text-muted-foreground">
                  Additional Exposure:{" "}
                </span>
                <span className="text-xs font-medium">
                  {patient.additionalExposure.join(", ")}
                </span>
              </div>
            )}
        </div>
      </div>

      {/* Explainable screening summary */}
      <div className={`rounded-xl border p-4 ${colors.bg} ${colors.border}`}>
        <h3 className="text-sm font-bold mb-3">Explainable screening summary</h3>
        <div className="grid grid-cols-3 gap-3 mb-3">
          <div className="bg-card rounded-lg p-3 text-center">
            <div className={`text-xl font-bold ${colors.text}`}>
              {patient.riskScore}
            </div>
            <div className="text-xs text-muted-foreground">Screening score /120</div>
          </div>
          <div className="bg-card rounded-lg p-3 text-center">
            <div className="text-xl font-bold text-foreground">
              {patient.assessmentResult?.engine ?? "rule-based"}
            </div>
            <div className="text-xs text-muted-foreground">Engine used</div>
          </div>
          <div className="bg-card rounded-lg p-3 text-center">
            <div className={`text-sm font-bold ${colors.text}`}>
              {getRiskLabel(patient.riskZone)}
            </div>
            <div className="text-xs text-muted-foreground">Risk Zone</div>
          </div>
        </div>
        <p className="text-sm">{patient.aiFindingsSummary}</p>
        <div className="mt-3"><p className="text-xs font-semibold">Top contributing symptoms</p>{(patient.topContributors ?? []).length ? <ul className="mt-1 space-y-1">{patient.topContributors?.map((item) => <li key={item.name} className="text-xs">{item.name}: {item.points} points <span className="text-muted-foreground">({item.behavior})</span></li>)}</ul> : <p className="text-xs text-muted-foreground">No symptom contributions recorded.</p>}</div>
        <div className="mt-3"><p className="text-xs font-semibold">Risk breakdown by rule</p><div className="mt-1 grid grid-cols-2 gap-x-4 gap-y-1">{Object.entries(patient.riskBreakdown ?? {}).map(([rule, points]) => <div key={rule} className="text-xs flex justify-between"><span>{rule}</span><span>{Math.round(points * 100) / 100}</span></div>)}</div></div>
        <p className="mt-3 text-[11px] text-muted-foreground">Prototype rule-based scoring. Weights and thresholds are placeholders pending dermatologist review. Not clinically validated.</p>
        <p className="text-[11px] text-muted-foreground">Model trained on synthetic data. Prototype, not clinically validated.</p>
        {patient.aiRiskFactors.length > 0 && (
          <ul className="mt-3 space-y-1">
            {patient.aiRiskFactors.map((f) => (
              <li key={f} className="text-xs flex items-start gap-1.5">
                <span className="text-primary mt-0.5">•</span> {f}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Symptoms */}
      {presentSymptoms.length > 0 && (
        <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
          <h3 className="text-sm font-bold mb-3">
            🩺 Reported Symptoms ({presentSymptoms.length})
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-2 font-semibold">Symptom</th>
                  <th className="text-left py-2 font-semibold">Group</th>
                  <th className="text-left py-2 font-semibold">Week</th>
                  <th className="text-left py-2 font-semibold">Frequency</th>
                  <th className="text-left py-2 font-semibold">Trend</th>
                  <th className="text-left py-2 font-semibold">Intensity</th>
                </tr>
              </thead>
              <tbody>
                {presentSymptoms.map((s) => (
                  <tr key={s.id} className="border-b border-border/50">
                    <td className="py-2">{s.name}</td>
                    <td className="py-2">
                      <Badge
                        className="text-xs border-0 bg-amber-100 text-amber-700"
                      >
                        {s.group}
                      </Badge>
                    </td>
                    <td className="py-2">{s.durationWeek === "8+" ? "8+ weeks" : s.durationWeek === "unsure" ? "Not sure" : `Week ${s.durationWeek}`}</td>
                    <td className="py-2">{s.frequency}</td>
                    <td className="py-2">{s.trend}</td>
                    <td className="py-2">{s.intensity}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Images */}
      {patient.uploadedImages.length > 0 && (
        <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
          <h3 className="text-sm font-bold mb-3">📸 Uploaded Images</h3>
          <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
            {patient.uploadedImages.map((img) => (
              <div
                key={img.slice(-20)}
                className="aspect-square rounded-lg overflow-hidden border border-border"
              >
                <img
                  src={img}
                  alt="Uploaded scan"
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Doctor Actions */}
      <div className="bg-card rounded-xl border border-border p-4 space-y-4">
        <h3 className="text-sm font-bold">📝 Doctor Actions</h3>
        <div>
          <Label
            htmlFor="doctor-notes"
            className="text-xs font-semibold mb-1.5 block"
          >
            Clinical Notes
          </Label>
          <Textarea
            id="doctor-notes"
            value={notes}
            onChange={(e) => onNotesChange(e.target.value)}
            placeholder="Add clinical observations, diagnosis notes, or recommendations..."
            rows={3}
            data-ocid="doctor.notes.textarea"
          />
        </div>
        <div className="flex flex-wrap gap-3">
          <Button
            onClick={onApprove}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
            data-ocid="doctor.approve.primary_button"
          >
            <CheckCircle size={16} /> Approve
          </Button>
          <Button
            onClick={onReject}
            variant="outline"
            className="flex items-center gap-2 border-red-200 text-red-700 hover:bg-red-50"
            data-ocid="doctor.reject.delete_button"
          >
            <XCircle size={16} /> Reject
          </Button>
          {canDownloadPDF && (
            <Button
              onClick={onDownloadPDF}
              variant="outline"
              className="flex items-center gap-2"
              data-ocid="doctor.download_pdf.button"
            >
              <Download size={16} /> Download Full Report (PDF)
            </Button>
          )}
        </div>
      </div>

      {/* Recommendation Section */}
      <div className="bg-card rounded-xl border-2 border-primary/30 p-4 space-y-4">
        <h3 className="text-sm font-bold flex items-center gap-2 text-primary">
          <ClipboardList size={16} /> Add Recommendation for Patient
        </h3>

        {patient.recommendationSubmitted ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg p-3 text-sm font-medium">
              <CheckCircle size={16} /> Recommendation submitted successfully.
              Editing is locked.
            </div>
            {patient.recommendedTests?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-muted-foreground mb-2">
                  Recommended Tests:
                </p>
                <p className="text-xs text-muted-foreground italic mb-2">
                  Recommended tests are optional but advised for better
                  diagnosis.
                </p>
                <div className="flex flex-wrap gap-2">
                  {patient.recommendedTests.map((t) => (
                    <Badge
                      key={t}
                      className="bg-primary/10 text-primary border-0"
                    >
                      {t}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {(patient.clinicalNotes || patient.doctorNotes) && (
              <div>
                <p className="text-xs font-semibold text-muted-foreground mb-1">
                  Clinical Notes:
                </p>
                <p className="text-sm bg-muted/40 rounded-lg p-3">
                  {patient.clinicalNotes || patient.doctorNotes}
                </p>
              </div>
            )}
            {patient.medicalNotes && (
              <div>
                <p className="text-xs font-semibold text-muted-foreground mb-1">
                  Medical Notes (Patient-Friendly):
                </p>
                <p className="text-sm bg-muted/40 rounded-lg p-3">
                  {patient.medicalNotes}
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <Label className="text-xs font-semibold mb-1 block">
                📋 Recommended Tests
              </Label>
              <p className="text-xs text-muted-foreground italic mb-2">
                Recommended tests are optional but advised for better diagnosis.
              </p>
              <div className="grid grid-cols-2 gap-2">
                {["Dermoscopy", "Skin biopsy", "Mole mapping", "Dermatology consultation"].map(
                  (test) => (
                    <label
                      key={test}
                      className="flex items-center gap-2 cursor-pointer p-2 rounded-lg border border-border hover:bg-muted/30 text-sm"
                    >
                      <input
                        type="checkbox"
                        checked={selectedTests.includes(test)}
                        onChange={() => onToggleTest(test)}
                        className="accent-primary"
                      />
                      {test}
                    </label>
                  ),
                )}
              </div>
              <div className="flex gap-2 mt-2">
                <Input
                  value={customTestInput}
                  onChange={(e) => onCustomTestInputChange(e.target.value)}
                  placeholder="Add custom test..."
                  className="text-sm"
                  onKeyDown={(e) => e.key === "Enter" && onAddCustomTest()}
                  data-ocid="doctor.custom_test.input"
                />
                <Button
                  size="sm"
                  variant="outline"
                  onClick={onAddCustomTest}
                  data-ocid="doctor.add_custom_test.button"
                >
                  Add
                </Button>
              </div>
              {selectedTests.filter(
                (t) =>
                  !["Dermoscopy", "Skin biopsy", "Mole mapping", "Dermatology consultation"].includes(
                    t,
                  ),
              ).length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedTests
                    .filter(
                      (t) =>
                        !["Dermoscopy", "Skin biopsy", "Mole mapping", "Dermatology consultation"].includes(t),
                    )
                    .map((t) => (
                      <Badge
                        key={t}
                        className="bg-primary/10 text-primary border-0 flex items-center gap-1"
                      >
                        {t}
                        <button
                          type="button"
                          onClick={() => onRemoveTest(t)}
                          className="ml-1 hover:text-red-600"
                        >
                          ×
                        </button>
                      </Badge>
                    ))}
                </div>
              )}
            </div>

            {/* Clinical Notes (ref-5) */}
            <div>
              <Label className="text-xs font-semibold mb-1.5 block">
                🧾 Clinical Notes
              </Label>
              <p className="text-xs text-muted-foreground mb-1">
                Technical observations for medical record
              </p>
              <Textarea
                value={clinicalNotes}
                onChange={(e) => onClinicalNotesChange(e.target.value)}
                placeholder="Technical observations for medical record..."
                rows={3}
                data-ocid="doctor.clinical_notes.textarea"
              />
            </div>

            {/* Medical Notes (ref-5) */}
            <div>
              <Label className="text-xs font-semibold mb-1.5 block">
                📝 Medical Notes
              </Label>
              <p className="text-xs text-muted-foreground mb-1">
                Patient-friendly explanation and guidance
              </p>
              <Textarea
                value={medicalNotes}
                onChange={(e) => onMedicalNotesChange(e.target.value)}
                placeholder="Patient-friendly explanation and guidance..."
                rows={3}
                data-ocid="doctor.medical_notes.textarea"
              />
            </div>

            {/* Legacy note (kept for backward compat, hidden when new fields used) */}
            <div className="hidden">
              <Textarea
                value={recommendationNote}
                onChange={(e) => onRecommendationNoteChange(e.target.value)}
                rows={2}
                data-ocid="doctor.recommendation_note.textarea"
              />
            </div>

            <Button
              onClick={onSubmitRecommendation}
              className="w-full bg-primary hover:bg-primary/90 flex items-center gap-2"
              disabled={
                selectedTests.length === 0 &&
                !clinicalNotes.trim() &&
                !medicalNotes.trim()
              }
              data-ocid="doctor.submit_recommendation.primary_button"
            >
              <CheckCircle size={16} /> Submit Recommendation
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

function AppointmentsManager({
  appointments,
  patients,
  onUpdate,
}: {
  appointments: (Appointment & { patientName: string; patientId: string })[];
  patients: Patient[];
  onUpdate: (id: string, updates: Partial<Patient>) => void;
}) {
  const [rescheduleId, setRescheduleId] = useState<string | null>(null);
  const [newDate, setNewDate] = useState("");
  const [newSlot, setNewSlot] = useState("");

  function updateAppointmentStatus(
    appt: Appointment & { patientId: string },
    action: Appointment["doctorAction"] | "completed",
  ) {
    const patient = patients.find((p) => p.id === appt.patientId);
    if (!patient) return;
    const updated = (patient.appointments || []).map((a) =>
      a.id === appt.id
        ? {
            ...a,
            doctorAction: action === "completed" ? a.doctorAction : action,
            status: action === "completed" ? ("completed" as const) : a.status,
          }
        : a,
    );
    onUpdate(appt.patientId, { appointments: updated });
  }

  function handleReschedule(appt: Appointment & { patientId: string }) {
    const patient = patients.find((p) => p.id === appt.patientId);
    if (!patient || !newDate || !newSlot) return;
    const updated = (patient.appointments || []).map((a) =>
      a.id === appt.id
        ? {
            ...a,
            doctorAction: "rescheduled" as const,
            rescheduledDate: newDate,
            rescheduledSlot: newSlot,
          }
        : a,
    );
    onUpdate(appt.patientId, { appointments: updated });
    setRescheduleId(null);
  }

  if (appointments.length === 0) {
    return (
      <div
        className="bg-card rounded-xl border border-border p-10 text-center"
        data-ocid="doctor.appointments.empty_state"
      >
        <Calendar size={32} className="mx-auto mb-3 text-muted-foreground" />
        <p className="text-sm text-muted-foreground">
          No appointments booked yet.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {appointments.map((appt, i) => (
        <div
          key={appt.id}
          className="bg-card rounded-xl border border-gray-100 shadow-sm p-6"
          data-ocid={`doctor.appointment.item.${i + 1}`}
        >
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <p className="font-semibold text-sm">{appt.patientName}</p>
              <p className="text-xs text-muted-foreground">
                ID: {appt.patientId}
              </p>
              <p className="text-xs text-muted-foreground">
                {appt.date} at {appt.slot} &bull; {appt.specialty}
              </p>
              <p className="text-xs text-muted-foreground">
                {appt.consultationType === "online" ? "Online" : "In-Person"}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {appt.status !== "completed" && (
                <>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-green-700 border-green-200 hover:bg-green-50 text-xs"
                    onClick={() => updateAppointmentStatus(appt, "accepted")}
                    data-ocid={`doctor.accept_appt.button.${i + 1}`}
                  >
                    Accept
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-red-700 border-red-200 hover:bg-red-50 text-xs"
                    onClick={() => updateAppointmentStatus(appt, "rejected")}
                    data-ocid={`doctor.reject_appt.delete_button.${i + 1}`}
                  >
                    Reject
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs"
                    onClick={() => setRescheduleId(appt.id)}
                    data-ocid={`doctor.reschedule_appt.button.${i + 1}`}
                  >
                    <RefreshCcw size={12} /> Reschedule
                  </Button>
                  <Button
                    size="sm"
                    className="text-xs bg-green-600 hover:bg-green-700"
                    onClick={() => updateAppointmentStatus(appt, "completed")}
                    data-ocid={`doctor.complete_appt.button.${i + 1}`}
                  >
                    Mark Complete
                  </Button>
                </>
              )}
              {appt.consultationType === "online" && (
                <>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs flex items-center gap-1"
                    data-ocid={`doctor.video_call.button.${i + 1}`}
                  >
                    <Video size={12} /> Video Call
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs flex items-center gap-1"
                    data-ocid={`doctor.open_chat.button.${i + 1}`}
                  >
                    <MessageSquare size={12} /> Chat
                  </Button>
                </>
              )}
            </div>
          </div>
          {rescheduleId === appt.id && (
            <div
              className="mt-3 pt-3 border-t border-border space-y-3"
              data-ocid={`doctor.reschedule_form.panel.${i + 1}`}
            >
              <p className="text-xs font-semibold">Select New Date:</p>
              <div className="flex flex-wrap gap-2">
                {NEXT_7_DAYS.map((d) => (
                  <button
                    key={d.value}
                    type="button"
                    onClick={() => setNewDate(d.value)}
                    className={`px-2 py-1 rounded text-xs border ${newDate === d.value ? "bg-primary text-white border-primary" : "border-border"}`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap gap-2">
                {TIME_SLOTS.map((slot) => (
                  <button
                    key={slot}
                    type="button"
                    onClick={() => setNewSlot(slot)}
                    className={`px-2 py-1 rounded text-xs border ${newSlot === slot ? "bg-primary text-white border-primary" : "border-border"}`}
                  >
                    {slot}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => handleReschedule(appt)}
                  disabled={!newDate || !newSlot}
                  data-ocid={`doctor.confirm_reschedule.confirm_button.${i + 1}`}
                >
                  Confirm Reschedule
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setRescheduleId(null)}
                  data-ocid={`doctor.cancel_reschedule.cancel_button.${i + 1}`}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function DoctorAnalytics({
  patients,
  pieData,
  barData,
  waveData,
  stackedBarData,
  timelineData,
  funnelData,
}: {
  patients: Patient[];
  pieData: { name: string; value: number; color: string }[];
  barData: { name: string; count: number }[];
  waveData: { name: string; score: number; confidence: number }[];
  stackedBarData: { name: string; abcde: number; efg: number; duckling: number; sites: number; factors: number }[];
  timelineData: { name: string; total: number }[];
  funnelData: { name: string; value: number; fill: string }[];
}) {
  // Case priority (derive from riskZone)
  const priorityData = [
    {
      name: "Low Priority",
      count: patients.filter((p) => p.riskZone === "green").length,
      fill: "#22c55e",
    },
    {
      name: "Medium Priority",
      count: patients.filter((p) => p.riskZone === "yellow").length,
      fill: "#f59e0b",
    },
    {
      name: "High Priority",
      count: patients.filter((p) => p.riskZone === "red").length,
      fill: "#ef4444",
    },
  ];

  // Breakdown of scores by the configured skin-screening rules.
  const clusterData = [
    {
      name: "ABCDE",
      value: patients.reduce((sum, p) => sum + (p.riskBreakdown?.ABCDE ?? 0), 0),
      fill: "#E53935",
    },
    {
      name: "EFG",
      value: patients.reduce((sum, p) => sum + (p.riskBreakdown?.EFG ?? 0), 0),
      fill: "#f59e0b",
    },
    {
      name: "Ugly Duckling",
      value: patients.reduce((sum, p) => sum + (p.riskBreakdown?.["Ugly Duckling"] ?? 0), 0),
      fill: "#8b5cf6",
    },
    { name: "Special sites", value: patients.reduce((sum, p) => sum + (p.riskBreakdown?.["Special sites"] ?? 0), 0), fill: "#0ea5e9" },
    { name: "Risk factors", value: patients.reduce((sum, p) => sum + (p.riskBreakdown?.["Risk factors"] ?? 0), 0), fill: "#22c55e" },
  ].filter((d) => d.value > 0);

  // Daily case load: last 7 days
  const last7 = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const dateStr = d.toISOString().split("T")[0];
    return {
      name: d.toLocaleDateString("en-IN", { weekday: "short", day: "numeric" }),
      cases: patients.filter((p) => p.submittedAt?.startsWith(dateStr)).length,
    };
  });

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-3 gap-4">
        {[
          {
            label: "Total Patients",
            value: patients.length,
            icon: <Users size={16} />,
            color: "text-primary",
          },
          {
            label: "High Risk",
            value: patients.filter((p) => p.riskZone === "red").length,
            icon: <Activity size={16} />,
            color: "text-red-600",
          },
          {
            label: "Reviewed",
            value: patients.filter((p) => p.doctorReviewed).length,
            icon: <CheckCircle size={16} />,
            color: "text-green-600",
          },
        ].map((card) => (
          <div
            key={card.label}
            className="bg-card rounded-xl border border-border p-4 text-center"
          >
            <div className={`flex justify-center mb-1 ${card.color}`}>
              {card.icon}
            </div>
            <div className={`text-2xl font-bold ${card.color}`}>
              {card.value}
            </div>
            <div className="text-xs text-muted-foreground">{card.label}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Wave */}
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="text-sm font-semibold mb-3">Risk Score Trend</h3>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart
              data={waveData}
              margin={{ top: 10, right: 20, left: 0, bottom: 10 }}
            >
              <defs>
                <linearGradient id="docGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#E53935" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#E53935" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} domain={[0, 120]} />
              <Tooltip />
              <Area
                type="monotone"
                dataKey="score"
                stroke="#E53935"
                fill="url(#docGrad)"
                strokeWidth={2}
                name="Risk Score"
              />
              <Area
                type="monotone"
                dataKey="confidence"
                stroke="#f59e0b"
                fill="none"
                strokeWidth={1.5}
                name="Confidence %"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Pie */}
        {pieData.length > 0 && (
          <div className="bg-card rounded-xl border border-border p-5">
            <h3 className="text-sm font-semibold mb-3">Risk Distribution</h3>
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={65}
                  dataKey="value"
                >
                  {pieData.map((entry) => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Legend iconSize={10} />
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Top Symptoms Bar */}
        {barData.length > 0 && (
          <div className="bg-card rounded-xl border border-border p-5">
            <h3 className="text-sm font-semibold mb-3">
              Top Reported Symptoms
            </h3>
            <ResponsiveContainer width="100%" height={140}>
              <BarChart
                data={barData}
                margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 9 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Bar
                  dataKey="count"
                  fill="#E53935"
                  radius={[4, 4, 0, 0]}
                  name="Count"
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Rule group score breakdown */}
        {stackedBarData.length > 0 && (
          <div className="bg-card rounded-xl border border-border p-5">
            <h3 className="text-sm font-semibold mb-3">
              Risk breakdown by rule
            </h3>
            <ResponsiveContainer width="100%" height={140}>
              <BarChart
                data={stackedBarData}
                margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 9 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Legend iconSize={10} />
                <Bar dataKey="abcde" stackId="a" fill="#E53935" name="ABCDE" />
                <Bar dataKey="efg" stackId="a" fill="#f59e0b" name="EFG" />
                <Bar dataKey="duckling" stackId="a" fill="#8b5cf6" name="Ugly Duckling" />
                <Bar dataKey="sites" stackId="a" fill="#0ea5e9" name="Special sites" />
                <Bar dataKey="factors" stackId="a" fill="#22c55e" name="Risk factors" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Timeline */}
        {timelineData.length > 0 && (
          <div className="bg-card rounded-xl border border-border p-5">
            <h3 className="text-sm font-semibold mb-3">Case Flow (Timeline)</h3>
            <ResponsiveContainer width="100%" height={140}>
              <LineChart
                data={timelineData}
                margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="total"
                  stroke="#E53935"
                  strokeWidth={2}
                  dot
                  name="Total Cases"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Funnel */}
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="text-sm font-semibold mb-3">Screening Funnel</h3>
          {funnelData.every((d) => d.value === 0) ? (
            <p className="text-xs text-muted-foreground py-8 text-center">
              No data yet
            </p>
          ) : (
            <ResponsiveContainer width="100%" height={140}>
              <BarChart
                layout="vertical"
                data={funnelData}
                margin={{ top: 5, right: 20, left: 80, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis type="number" tick={{ fontSize: 10 }} />
                <YAxis
                  dataKey="name"
                  type="category"
                  tick={{ fontSize: 9 }}
                  width={80}
                />
                <Tooltip />
                <Bar dataKey="value" radius={[0, 4, 4, 0]} name="Count">
                  {funnelData.map((entry) => (
                    <Cell key={entry.name} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* NEW: Case Priority Chart */}
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="text-sm font-semibold mb-3">
            Case Priority Distribution
          </h3>
          <ResponsiveContainer width="100%" height={140}>
            <BarChart
              data={priorityData}
              margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Bar dataKey="count" radius={[4, 4, 0, 0]} name="Cases">
                {priorityData.map((entry) => (
                  <Cell key={entry.name} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* NEW: Symptom Cluster Chart */}
        {clusterData.length > 0 && (
          <div className="bg-card rounded-xl border border-border p-5">
            <h3 className="text-sm font-semibold mb-3">Symptom Cluster</h3>
            <ResponsiveContainer width="100%" height={140}>
              <PieChart>
                <Pie
                  data={clusterData}
                  cx="50%"
                  cy="50%"
                  innerRadius={35}
                  outerRadius={60}
                  dataKey="value"
                >
                  {clusterData.map((entry) => (
                    <Cell key={entry.name} fill={entry.fill} />
                  ))}
                </Pie>
                <Legend iconSize={10} />
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* NEW: Daily Case Load */}
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="text-sm font-semibold mb-3">
            Daily Case Load (Last 7 Days)
          </h3>
          <ResponsiveContainer width="100%" height={140}>
            <BarChart
              data={last7}
              margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
              <Tooltip />
              <Bar
                dataKey="cases"
                fill="#E53935"
                radius={[4, 4, 0, 0]}
                name="Cases"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
