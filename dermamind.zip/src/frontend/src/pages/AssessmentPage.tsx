import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  AlertCircle,
  CheckCircle,
  ChevronLeft,
  ChevronRight,
  Info,
  Upload,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { usePatientStore } from "../context/PatientStore";
import type {
  DoctorSpecialty,
  Patient,
  Screen,
  SymptomEntry,
  User,
} from "../types";
import type { RiskResult } from "../utils/riskEngine";
import { API_BASE_URL, analyseModel, calculateRisk, type ModelAnalysis, type ModelConsent } from "../utils/riskEngine";
import {
  SYMPTOM_CONTEXT_QUESTIONS,
  SYMPTOM_EXPLANATIONS,
  createDefaultSymptoms,
  validateVisibleSymptomAnswers,
} from "../utils/symptomsData";

interface Props {
  onNavigate: (screen: Screen) => void;
  user: User;
}

type Step = 0 | 1 | 2 | 3 | 4 | 5 | 6;

type SmokingLevel = "Non-Smoker" | "Occasional" | "Frequent";
type AlcoholLevel = "Non-Drinker" | "Occasional" | "Frequent";

interface PatientInfo {
  name: string;
  age: string;
  gender: string;
  phone: string;
  place: string;
  smokingLevel: SmokingLevel;
  alcoholLevel: AlcoholLevel;
  chemicalExposure: boolean;
  radiationExposure: boolean;
  existingDiseases: string;
  familyHistory: boolean;
  additionalExposure: string[];
}

const STEPS = [
  "Consent",
  "Patient Info",
  "Symptoms",
  "Risk Factors",
  "Image Upload",
  "Review",
  "Submitting",
];

export default function AssessmentFlow({ onNavigate, user }: Props) {
  const { addPatient, updatePatient } = usePatientStore();
  const [step, setStep] = useState<Step>(0);
  const [consentGiven, setConsentGiven] = useState(false);
  const [consentError, setConsentError] = useState(false);

  const [info, setInfo] = useState<PatientInfo>({
    name: "",
    age: "",
    gender: "",
    phone: "",
    place: "",
    smokingLevel: "Non-Smoker",
    alcoholLevel: "Non-Drinker",
    chemicalExposure: false,
    radiationExposure: false,
    existingDiseases: "",
    familyHistory: false,
    additionalExposure: [],
  });
  const [infoErrors, setInfoErrors] = useState<
    Partial<Record<keyof PatientInfo, string>>
  >({});

  const [symptoms, setSymptoms] = useState<SymptomEntry[]>(
    createDefaultSymptoms(),
  );
  const [expandedInfo, setExpandedInfo] = useState<number | null>(null);
  const [symptomErrors, setSymptomErrors] = useState<string[]>([]);

  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [imageConsent, setImageConsent] = useState(false);
  const [skinImageScore, setSkinImageScore] = useState(2);

  const [submitConsentGiven, setSubmitConsentGiven] = useState(false);
  const [submitConsentError, setSubmitConsentError] = useState(false);

  const [submittingStep, setSubmittingStep] = useState(0);
  const [riskResult, setRiskResult] = useState<RiskResult | null>(null);
  const [modelAnalysis, setModelAnalysis] = useState<ModelAnalysis | null>(null);
  const [modelConsent, setModelConsent] = useState<ModelConsent | null>(null);
  const [analysisEngine, setAnalysisEngine] = useState("rule-based");
  const [savedPatientId, setSavedPatientId] = useState<string | null>(null);
  const [showDoctorConsent, setShowDoctorConsent] = useState(false);
  const [assignedDoctor, setAssignedDoctor] = useState<DoctorSpecialty | null>(
    null,
  );

  function validateInfo(): boolean {
    const errors: Partial<Record<keyof PatientInfo, string>> = {};
    if (!info.name.trim()) errors.name = "Name is required";
    const age = Number.parseInt(info.age);
    if (!info.age || Number.isNaN(age) || age < 1 || age > 120)
      errors.age = "Valid age (1-120) required";
    if (!info.gender) errors.gender = "Please select gender";
    if (!info.phone.trim() || !/^\d{10}$/.test(info.phone.trim()))
      errors.phone = "10-digit phone number required";
    if (!info.place.trim()) errors.place = "City/place is required";
    setInfoErrors(errors);
    return Object.keys(errors).length === 0;
  }

  function handleConsentNext() {
    if (!consentGiven) {
      setConsentError(true);
      return;
    }
    setConsentError(false);
    setStep(1);
  }

  function handleInfoNext() {
    if (!validateInfo()) return;
    setStep(2);
  }

  function updateSymptom(id: number, updates: Partial<SymptomEntry>) {
    setSymptoms((prev) =>
      prev.map((s) => s.id !== id ? s : updates.answer === "No"
        ? { ...s, ...updates, present: false, durationWeek: null, trend: null, frequency: null, intensity: null, followUps: {} }
        : { ...s, ...updates }),
    );
  }

  function handleSymptomsNext() {
    const errors = validateVisibleSymptomAnswers(symptoms);
    setSymptomErrors(errors);
    if (errors.length === 0) setStep(3);
  }

  function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files || []);
    for (const file of files) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const base64 = ev.target?.result as string;
        setUploadedImages((prev) => [...prev, base64]);
        setSkinImageScore(8);
      };
      reader.readAsDataURL(file);
    }
  }

  async function handleSubmit() {
    if (!submitConsentGiven) {
      setSubmitConsentError(true);
      return;
    }
    setSubmitConsentError(false);
    setStep(6);
    setSubmittingStep(1);
    const ruleResult = calculateRisk({
      symptoms, age: Number.parseInt(info.age), place: info.place,
      smokingLevel: info.smokingLevel, alcoholLevel: info.alcoholLevel,
      smoking: info.smokingLevel !== 'Non-Smoker', alcohol: info.alcoholLevel !== 'Non-Drinker',
      chemicalExposure: info.chemicalExposure, radiationExposure: info.radiationExposure,
      existingDiseases: info.existingDiseases, familyHistory: info.familyHistory, skinImageScore: 0,
    });
    const consent: ModelConsent = {
      collect_details: consentGiven,
      analyse_photo: uploadedImages.length > 0 && imageConsent,
      use_location: !!info.place.trim(),
      share_with_doctor: false,
    };
    setModelConsent(consent);
    setSubmittingStep(2);
    const mlResult = await analyseModel(symptoms, consent);
    setModelAnalysis(mlResult);
    const rawModelZone = (mlResult?.step2_model_check as { zone?: string } | undefined)?.zone;
    const mlZone = rawModelZone?.toLowerCase();
    const rank: Record<string, number> = { green: 0, yellow: 1, red: 2 };
    const finalZone = mlZone && rank[mlZone] > rank[ruleResult.riskZone] ? mlZone as RiskResult['riskZone'] : ruleResult.riskZone;
    const result: RiskResult = { ...ruleResult, riskZone: finalZone };
    const engine = mlResult ? 'combined' : API_BASE_URL ? 'rule-based fallback' : 'rule-based';
    setAnalysisEngine(engine);
    const patientId = `PT-${Date.now()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
    const patient: Patient = {
      id: patientId, userEmail: user.email, submittedAt: new Date().toISOString(),
      name: info.name, age: Number.parseInt(info.age), gender: info.gender, phone: info.phone, place: info.place,
      smokingLevel: info.smokingLevel, alcoholLevel: info.alcoholLevel,
      smoking: info.smokingLevel !== 'Non-Smoker', alcohol: info.alcoholLevel !== 'Non-Drinker',
      chemicalExposure: info.chemicalExposure, radiationExposure: info.radiationExposure,
      existingDiseases: info.existingDiseases, familyHistory: info.familyHistory,
      additionalExposure: info.additionalExposure, symptoms, uploadedImages, skinImageScore: 0,
      riskScore: ruleResult.score, confidenceScore: 0, riskZone: finalZone,
      aiFindingsSummary: ruleResult.aiFindings, aiRiskFactors: ruleResult.aiRiskFactors,
      riskBreakdown: ruleResult.riskBreakdown, topContributors: ruleResult.topContributors,
      assessmentResult: { mlResult, ruleResult, finalZone, engine, modelVersion: mlResult?.model_version ?? null, analysedAt: new Date().toISOString() },
      status: 'pending', doctorReviewed: false, reviewConfirmed: false, doctorNotes: '', clinicalNotes: '', medicalNotes: '',
      recommendedTests: [], appointments: [], demoTestReport: null, assessmentDate: new Date().toISOString(), followUpMonths: 3,
    };
    addPatient(patient);
    setRiskResult(result);
    setSavedPatientId(patientId);
    setSubmittingStep(4);
  }
  function handleConfirmAndSendToDoctor() {
    if (!savedPatientId) return;
    // Calculate routing
    const doctorType: DoctorSpecialty = "Dermatologist";
    setAssignedDoctor(doctorType);
    setShowDoctorConsent(true);
  }

  async function handleConsentYes() {
    if (!savedPatientId || !assignedDoctor) return;
    let nextMl = modelAnalysis;
    let nextZone = riskResult?.riskZone;
    let nextEngine = analysisEngine;
    if (modelConsent) {
      const shared = { ...modelConsent, share_with_doctor: true };
      nextMl = await analyseModel(symptoms, shared);
      setModelConsent(shared);
      setModelAnalysis(nextMl);
      if (nextMl) {
        const rawZone = (nextMl.step2_model_check as { zone?: string } | undefined)?.zone?.toLowerCase();
        const rank: Record<string, number> = { green: 0, yellow: 1, red: 2 };
        if (rawZone && nextZone && rank[rawZone] > rank[nextZone]) nextZone = rawZone as RiskResult["riskZone"];
        nextEngine = "combined";
      } else if (API_BASE_URL) nextEngine = "rule-based fallback";
      setAnalysisEngine(nextEngine);
    }
    updatePatient(savedPatientId, {
      reviewConfirmed: true,
      assignedDoctorType: assignedDoctor,
      ...(nextZone ? { riskZone: nextZone } : {}),
      assessmentResult: {
        mlResult: nextMl,
        ruleResult: riskResult,
        finalZone: nextZone ?? riskResult?.riskZone ?? "green",
        engine: nextEngine,
        modelVersion: nextMl?.model_version ?? null,
        analysedAt: new Date().toISOString(),
      },
    });
    setShowDoctorConsent(false);
    onNavigate("patient-dashboard");
  }

  function handleConsentNo() {
    setShowDoctorConsent(false);
    onNavigate("patient-dashboard");
  }

  const presentCount = symptoms.filter((s) => s.present).length;

  function getRiskZoneDisplay() {
    if (!riskResult) return null;
    if (riskResult.riskZone === "green") {
      return {
        emoji: "🟢",
        zone: "GREEN ZONE",
        msg: "You are in the GREEN ZONE. Continue monitoring and contact a dermatologist if anything changes.",
        cls: "bg-green-50 border-green-200 text-green-800",
        badgeCls: "bg-green-100 text-green-800",
      };
    }
    if (riskResult.riskZone === "yellow") {
      return {
        emoji: "🟡",
        zone: "YELLOW ZONE",
        msg: "You are in the YELLOW ZONE. A dermatologist review is advised. This rule-based screening score is not a probability or diagnosis.",
        cls: "bg-amber-50 border-amber-200 text-amber-800",
        badgeCls: "bg-amber-100 text-amber-800",
      };
    }
    return {
      emoji: "🔴",
      zone: "RED ZONE",
      msg: "You are in the RED ZONE. Please arrange a dermatologist review as soon as possible. This rule-based screening score is not a probability or diagnosis.",
      cls: "bg-red-50 border-red-200 text-red-800",
      badgeCls: "bg-red-100 text-red-800",
    };
  }

  const inputCheck = modelAnalysis?.step1_input_check as { passed?: boolean; issues?: string[] } | undefined;
  const modelCheck = modelAnalysis?.step2_model_check as { zone?: string; confidence?: string } | undefined;
  const doctorReview = modelAnalysis?.step3_doctor_review as { status?: string } | undefined;
  const nextStep = (modelAnalysis?.FINAL_OUTPUT as { next_step?: string } | undefined)?.next_step
    ?? (riskResult?.riskZone === "green" ? "Continue monitoring and re-check if anything changes." : riskResult?.riskZone === "yellow" ? "Book a dermatologist visit soon." : "See a dermatologist as soon as possible.");

  // suppress unused warning for imageConsent
  void imageConsent;

  return (
    <div className="min-h-full bg-background">
      {step > 0 && step < 6 && (
        <div className="sticky top-0 z-20 bg-card border-b border-border px-4 py-3">
          <div className="max-w-2xl mx-auto">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-muted-foreground">
                Step {step} of 5
              </span>
              <span className="text-xs text-muted-foreground">
                {STEPS[step]}
              </span>
            </div>
            <Progress value={(step / 5) * 100} className="h-1.5" />
          </div>
        </div>
      )}

      <div className="max-w-2xl mx-auto px-4 py-6">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div
              key="consent"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="bg-card rounded-2xl border border-border shadow-card p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <AlertCircle size={22} className="text-primary" />
                </div>
                <h2 className="text-xl font-bold mb-2">Before You Begin</h2>
                <p className="text-sm text-muted-foreground mb-5">
                  DermaMind is a skin cancer screening aid — not a diagnostic tool.
                </p>
                <div className="space-y-3 mb-5 text-sm">
                  <div className="flex items-start gap-2">
                    <CheckCircle
                      size={16}
                      className="text-green-600 mt-0.5 flex-shrink-0"
                    />
                    <p>
                      This assessment screens for skin cancer warning signs only.
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle
                      size={16}
                      className="text-green-600 mt-0.5 flex-shrink-0"
                    />
                    <p>
                      Results are not a diagnosis. You may choose to request dermatologist review.
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle
                      size={16}
                      className="text-green-600 mt-0.5 flex-shrink-0"
                    />
                    <p>
                      Your answers are saved in this browser. If you request review, the report appears in this app's dermatologist dashboard.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3 cursor-pointer mb-4">
                  <Checkbox
                    checked={consentGiven}
                    onCheckedChange={(v) => {
                      setConsentGiven(!!v);
                      setConsentError(false);
                    }}
                    data-ocid="assessment.consent.checkbox"
                    className="mt-0.5"
                  />
                  <span className="text-sm">
                    I understand this is a screening tool, not a diagnosis. I
                    consent to include my answers in a dermatologist review request.
                  </span>
                </div>
                {consentError && (
                  <p className="text-xs text-destructive mb-3">
                    Please accept the consent to continue.
                  </p>
                )}
                <Button
                  onClick={handleConsentNext}
                  className="w-full"
                  data-ocid="assessment.consent.primary_button"
                >
                  I Agree &amp; Continue{" "}
                  <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="info"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
            >
              <h2 className="text-xl font-bold mb-5">Personal Information</h2>
              <div className="bg-card rounded-2xl border border-border shadow-card p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label className="text-xs font-semibold">Full Name *</Label>
                    <Input
                      value={info.name}
                      onChange={(e) =>
                        setInfo({ ...info, name: e.target.value })
                      }
                      placeholder="Enter your full name"
                      className="mt-1"
                      data-ocid="assessment.name.input"
                    />
                    {infoErrors.name && (
                      <p className="text-xs text-destructive mt-1">
                        {infoErrors.name}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label className="text-xs font-semibold">Age *</Label>
                    <Input
                      value={info.age}
                      onChange={(e) =>
                        setInfo({ ...info, age: e.target.value })
                      }
                      type="number"
                      placeholder="Age"
                      min={1}
                      max={120}
                      className="mt-1"
                      data-ocid="assessment.age.input"
                    />
                    {infoErrors.age && (
                      <p className="text-xs text-destructive mt-1">
                        {infoErrors.age}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label className="text-xs font-semibold">Gender *</Label>
                    <select
                      value={info.gender}
                      onChange={(e) =>
                        setInfo({ ...info, gender: e.target.value })
                      }
                      className="mt-1 w-full border border-input rounded-lg px-3 py-2 text-sm bg-background"
                      data-ocid="assessment.gender.select"
                    >
                      <option value="">Select gender</option>
                      <option>Male</option>
                      <option>Female</option>
                      <option>Other</option>
                    </select>
                    {infoErrors.gender && (
                      <p className="text-xs text-destructive mt-1">
                        {infoErrors.gender}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label className="text-xs font-semibold">
                      Phone (10 digits) *
                    </Label>
                    <Input
                      value={info.phone}
                      onChange={(e) =>
                        setInfo({ ...info, phone: e.target.value })
                      }
                      placeholder="9876543210"
                      maxLength={10}
                      className="mt-1"
                      data-ocid="assessment.phone.input"
                    />
                    {infoErrors.phone && (
                      <p className="text-xs text-destructive mt-1">
                        {infoErrors.phone}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label className="text-xs font-semibold">
                      City / Place *
                    </Label>
                    <Input
                      value={info.place}
                      onChange={(e) =>
                        setInfo({ ...info, place: e.target.value })
                      }
                      placeholder="Delhi, Mumbai, etc."
                      className="mt-1"
                      data-ocid="assessment.place.input"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Used to estimate air quality (AQI) risk
                    </p>
                    {infoErrors.place && (
                      <p className="text-xs text-destructive mt-1">
                        {infoErrors.place}
                      </p>
                    )}
                  </div>
                </div>

                <div className="pt-2 border-t border-border">
                  <p className="text-xs font-semibold mb-4 text-muted-foreground uppercase tracking-wider">
                    Lifestyle Habits
                  </p>

                  <div className="mb-4">
                    <Label className="text-sm font-semibold mb-2 block">
                      Smoking
                    </Label>
                    <div className="grid grid-cols-3 gap-2">
                      {(
                        [
                          "Non-Smoker",
                          "Occasional",
                          "Frequent",
                        ] as SmokingLevel[]
                      ).map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() =>
                            setInfo({ ...info, smokingLevel: opt })
                          }
                          className={`py-2.5 px-2 rounded-xl border-2 text-xs font-semibold transition-all text-center ${
                            info.smokingLevel === opt
                              ? "bg-primary text-white border-primary"
                              : "border-border hover:border-primary/50 bg-background"
                          }`}
                          data-ocid={`assessment.smoking_${opt.toLowerCase().replace(/-/g, "_")}.button`}
                        >
                          {opt === "Non-Smoker"
                            ? "🚭 "
                            : opt === "Occasional"
                              ? "💨 "
                              : "🚬 "}
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="mb-4">
                    <Label className="text-sm font-semibold mb-2 block">
                      Alcohol Consumption
                    </Label>
                    <div className="grid grid-cols-3 gap-2">
                      {(
                        [
                          "Non-Drinker",
                          "Occasional",
                          "Frequent",
                        ] as AlcoholLevel[]
                      ).map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() =>
                            setInfo({ ...info, alcoholLevel: opt })
                          }
                          className={`py-2.5 px-2 rounded-xl border-2 text-xs font-semibold transition-all text-center ${
                            info.alcoholLevel === opt
                              ? "bg-primary text-white border-primary"
                              : "border-border hover:border-primary/50 bg-background"
                          }`}
                          data-ocid={`assessment.alcohol_${opt.toLowerCase().replace(/-/g, "_")}.button`}
                        >
                          {opt === "Non-Drinker"
                            ? "🚫 "
                            : opt === "Occasional"
                              ? "🍷 "
                              : "🍺 "}
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {(
                      [
                        { key: "chemicalExposure", label: "Chemical Exposure" },
                        {
                          key: "radiationExposure",
                          label: "Radiation Exposure",
                        },
                      ] as const
                    ).map(({ key, label }) => (
                      <div
                        key={key}
                        className="flex items-center gap-2 cursor-pointer"
                      >
                        <Checkbox
                          checked={info[key] as boolean}
                          onCheckedChange={(v) =>
                            setInfo({ ...info, [key]: !!v })
                          }
                          data-ocid={`assessment.${key}.checkbox`}
                        />
                        <span className="text-sm">{label}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Additional Exposure Section */}
                <div className="pt-2 border-t border-border">
                  <p className="text-xs font-semibold mb-3 text-muted-foreground uppercase tracking-wider">
                    Additional Exposure
                  </p>
                  <p className="text-xs text-muted-foreground mb-3">
                    Select any environmental or occupational exposures that
                    apply (multi-select allowed):
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    {(
                      [
                        {
                          id: "Pollution",
                          icon: "🌫️",
                          desc: "Air/environmental pollution",
                        },
                        {
                          id: "Chemical Exposure",
                          icon: "⚗️",
                          desc: "Pesticides, chemicals, industrial fumes",
                        },
                        {
                          id: "Radiation Exposure",
                          icon: "☢️",
                          desc: "Radiation, radon, UV exposure",
                        },
                        {
                          id: "Dust / Industrial Exposure",
                          icon: "🏭",
                          desc: "Asbestos, coal dust, silica",
                        },
                      ] as const
                    ).map(({ id, icon, desc }) => {
                      const isSelected = info.additionalExposure.includes(id);
                      return (
                        <button
                          key={id}
                          type="button"
                          onClick={() => {
                            const current = info.additionalExposure;
                            setInfo({
                              ...info,
                              additionalExposure: isSelected
                                ? current.filter((x) => x !== id)
                                : [...current, id],
                            });
                          }}
                          className={`p-3 rounded-xl border-2 text-left transition-all ${
                            isSelected
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/40 bg-background"
                          }`}
                          data-ocid={`assessment.exposure_${id.toLowerCase().replace(/[^a-z0-9]/g, "_")}.toggle`}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-base">{icon}</span>
                            <div
                              className={`w-3.5 h-3.5 rounded border-2 flex items-center justify-center flex-shrink-0 ml-auto ${
                                isSelected
                                  ? "bg-primary border-primary"
                                  : "border-muted-foreground/40"
                              }`}
                            >
                              {isSelected && (
                                <svg
                                  width="8"
                                  height="6"
                                  viewBox="0 0 8 6"
                                  fill="none"
                                  role="img"
                                  aria-label="Selected"
                                >
                                  <path
                                    d="M1 3L3 5L7 1"
                                    stroke="white"
                                    strokeWidth="1.5"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                  />
                                </svg>
                              )}
                            </div>
                          </div>
                          <p className="text-xs font-semibold leading-tight">
                            {id}
                          </p>
                          <p className="text-xs text-muted-foreground mt-0.5 leading-tight">
                            {desc}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Family History of Cancer — standalone question */}
                <div className="pt-2 border-t border-border">
                  <p className="text-xs font-semibold mb-3 text-muted-foreground uppercase tracking-wider">
                    Family History
                  </p>
                  <div
                    className={`rounded-xl border-2 p-4 transition-all ${
                      info.familyHistory
                        ? "border-amber-400 bg-amber-50"
                        : "border-border bg-background"
                    }`}
                  >
                    <div className="flex items-start gap-3 mb-2">
                      <span className="text-xl">🧬</span>
                      <div className="flex-1">
                        <p className="text-sm font-semibold leading-snug">
                          Family History of Cancer
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Has any immediate family member (parent, sibling) been
                          diagnosed with cancer?
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-3">
                      <button
                        type="button"
                        onClick={() =>
                          setInfo({ ...info, familyHistory: true })
                        }
                        className={`flex-1 py-2.5 rounded-xl text-sm font-semibold border-2 transition-all ${
                          info.familyHistory
                            ? "bg-amber-500 text-white border-amber-500"
                            : "border-border hover:border-amber-400 bg-background text-foreground"
                        }`}
                        data-ocid="assessment.familyHistory_yes.button"
                      >
                        ✅ Yes
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setInfo({ ...info, familyHistory: false })
                        }
                        className={`flex-1 py-2.5 rounded-xl text-sm font-semibold border-2 transition-all ${
                          !info.familyHistory
                            ? "bg-green-500 text-white border-green-500"
                            : "border-border hover:border-green-400 bg-background text-foreground"
                        }`}
                        data-ocid="assessment.familyHistory_no.button"
                      >
                        ❌ No
                      </button>
                    </div>
                    {info.familyHistory && (
                      <p className="text-xs text-amber-700 font-medium mt-2 flex items-center gap-1">
                        ⚠️ Family history adds +6 pts to your risk score.
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <Label className="text-xs font-semibold">
                    Existing Diseases / Medical Conditions
                  </Label>
                  <Input
                    value={info.existingDiseases}
                    onChange={(e) =>
                      setInfo({ ...info, existingDiseases: e.target.value })
                    }
                    placeholder="e.g. Diabetes, Hypertension, Asthma (or leave blank)"
                    className="mt-1"
                    data-ocid="assessment.diseases.input"
                  />
                </div>
              </div>
              <div className="flex gap-3 mt-4">
                <Button
                  variant="outline"
                  onClick={() => setStep(0)}
                  data-ocid="assessment.info_back.button"
                >
                  <ChevronLeft size={16} /> Back
                </Button>
                <Button
                  onClick={handleInfoNext}
                  className="flex-1"
                  data-ocid="assessment.info_next.primary_button"
                >
                  Continue to Symptoms <ChevronRight size={16} />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="symptoms"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
            >
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-bold">Symptom Assessment</h2>
                <Badge variant="outline" className="text-xs">
                  {presentCount} selected
                </Badge>
              </div>
              <SymptomGroup
                title="Skin warning signs"
                desc="Choose Yes or No for each. Answer every detail shown after selecting Yes."
                symptoms={symptoms}
                onUpdate={updateSymptom}
                expandedInfo={expandedInfo}
                onToggleInfo={setExpandedInfo}
              />
              {symptomErrors.length > 0 && <div className="mb-4 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-xs text-destructive"><p className="font-semibold">Complete every visible answer before continuing:</p><ul className="mt-1 list-disc pl-4">{symptomErrors.slice(0, 8).map((error) => <li key={error}>{error}</li>)}</ul>{symptomErrors.length > 8 && <p>And {symptomErrors.length - 8} more.</p>}</div>}
              <div className="flex gap-3 mt-4">
                <Button
                  variant="outline"
                  onClick={() => setStep(1)}
                  data-ocid="assessment.symptoms_back.button"
                >
                  <ChevronLeft size={16} /> Back
                </Button>
                <Button
                  onClick={handleSymptomsNext}
                  className="flex-1"
                  data-ocid="assessment.symptoms_next.primary_button"
                >
                  Continue <ChevronRight size={16} />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="risk"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
            >
              <h2 className="text-xl font-bold mb-5">Risk Factor Summary</h2>
              <div className="bg-card rounded-2xl border border-border shadow-card p-6 space-y-4">
                <InfoRow label="Age" value={info.age} />
                <InfoRow label="Location" value={`${info.place} — 0 points`} />
                <InfoRow label="Smoking" value={`${info.smokingLevel} — 0 points`} />
                <InfoRow label="Alcohol" value={`${info.alcoholLevel} — 0 points`} />
                <InfoRow
                  label="Chemical Exposure"
                  value={info.chemicalExposure ? "Yes (+1 pt)" : "No"}
                />
                <InfoRow
                  label="Radiation Exposure"
                  value={info.radiationExposure ? "Yes (+3 pts)" : "No"}
                />
                <InfoRow
                  label="Family History"
                  value={info.familyHistory ? "Yes (+3 pts)" : "No"}
                />
                <InfoRow
                  label="Existing Diseases"
                  value={info.existingDiseases || "None"}
                />
                <InfoRow
                  label="Symptoms Reported"
                  value={`${presentCount} out of 25`}
                />
              </div>
              <div className="flex gap-3 mt-4">
                <Button
                  variant="outline"
                  onClick={() => setStep(2)}
                  data-ocid="assessment.risk_back.button"
                >
                  <ChevronLeft size={16} /> Back
                </Button>
                <Button
                  onClick={() => setStep(4)}
                  className="flex-1"
                  data-ocid="assessment.risk_next.primary_button"
                >
                  Continue to Image Upload <ChevronRight size={16} />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="image"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
            >
              <h2 className="text-xl font-bold mb-2">Skin Image Upload</h2>
              <p className="text-sm text-muted-foreground mb-5">
                Optional: Upload images of any moles, spots, or skin lesions for
                ABCDE-based AI evaluation.
              </p>
              <div className="bg-card rounded-2xl border border-border shadow-card p-6">
                <div className="border-2 border-dashed border-border rounded-xl p-8 text-center cursor-pointer hover:border-primary/50 transition-colors relative">
                  <Upload
                    size={28}
                    className="mx-auto mb-3 text-muted-foreground"
                  />
                  <p className="text-sm font-medium mb-1">
                    Click to upload or drag &amp; drop
                  </p>
                  <p className="text-xs text-muted-foreground">
                    JPG, PNG up to 10MB
                  </p>
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleImageUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    data-ocid="assessment.image.upload_button"
                  />
                </div>
                {uploadedImages.length > 0 && (
                  <div className="mt-4 grid grid-cols-3 gap-3">
                    {uploadedImages.map((img) => (
                      <div
                        key={img.slice(-20)}
                        className="relative aspect-square rounded-lg overflow-hidden border border-border"
                      >
                        <img
                          src={img}
                          alt="Uploaded scan"
                          className="w-full h-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setUploadedImages((prev) =>
                              prev.filter((x) => x !== img),
                            )
                          }
                          className="absolute top-1 right-1 w-5 h-5 bg-black/50 rounded-full flex items-center justify-center text-white"
                        >
                          <X size={10} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                {uploadedImages.length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs font-semibold mb-2">
                      AI Evaluation Score:
                    </p>
                    <div className="flex gap-2">
                      {[
                        { label: "Normal", value: 2 },
                        { label: "Suspicious", value: 8 },
                        { label: "Highly Suspicious", value: 15 },
                      ].map((opt) => (
                        <button
                          key={opt.label}
                          type="button"
                          onClick={() => setSkinImageScore(opt.value)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                            skinImageScore === opt.value
                              ? "bg-primary text-white border-primary"
                              : "border-border hover:border-primary/50"
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      Based on visual inspection, select the most appropriate
                      evaluation.
                    </p>
                  </div>
                )}
                <div className="flex items-start gap-3 cursor-pointer mt-5 p-3 bg-muted rounded-lg">
                  <Checkbox
                    checked={imageConsent}
                    onCheckedChange={(v) => setImageConsent(!!v)}
                    data-ocid="assessment.image_consent.checkbox"
                    className="mt-0.5"
                  />
                  <span className="text-xs">
                    I consent to share these images for medical review by
                    authorized doctors only.
                  </span>
                </div>
              </div>
              <div className="flex gap-3 mt-4">
                <Button
                  variant="outline"
                  onClick={() => setStep(3)}
                  data-ocid="assessment.image_back.button"
                >
                  <ChevronLeft size={16} /> Back
                </Button>
                <Button
                  onClick={() => setStep(5)}
                  className="flex-1"
                  data-ocid="assessment.image_next.primary_button"
                >
                  Review &amp; Submit <ChevronRight size={16} />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 5 && (
            <motion.div
              key="review"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
            >
              <h2 className="text-xl font-bold mb-5">
                Review Your Information
              </h2>
              <div className="space-y-4">
                <ReviewSection
                  title="Personal Information"
                  onEdit={() => setStep(1)}
                  editOcid="assessment.edit_info.edit_button"
                >
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <InfoRow label="Name" value={info.name} />
                    <InfoRow label="Age" value={`${info.age} yrs`} />
                    <InfoRow label="Gender" value={info.gender} />
                    <InfoRow label="Phone" value={info.phone} />
                    <InfoRow label="Place" value={info.place} />
                    <InfoRow
                      label="Family History"
                      value={info.familyHistory ? "Yes" : "No"}
                    />
                  </div>
                </ReviewSection>
                <ReviewSection
                  title="Lifestyle"
                  onEdit={() => setStep(1)}
                  editOcid="assessment.edit_lifestyle.edit_button"
                >
                  <div className="flex flex-wrap gap-2">
                    <Badge
                      className={`border-0 ${info.smokingLevel !== "Non-Smoker" ? "bg-red-100 text-red-700" : "bg-green-100 text-green-700"}`}
                    >
                      Smoking: {info.smokingLevel}
                    </Badge>
                    <Badge
                      className={`border-0 ${info.alcoholLevel !== "Non-Drinker" ? "bg-amber-100 text-amber-700" : "bg-green-100 text-green-700"}`}
                    >
                      Alcohol: {info.alcoholLevel}
                    </Badge>
                    {info.chemicalExposure && (
                      <Badge className="bg-orange-100 text-orange-700 border-0">
                        Chemical Exp.
                      </Badge>
                    )}
                    {info.radiationExposure && (
                      <Badge className="bg-purple-100 text-purple-700 border-0">
                        Radiation Exp.
                      </Badge>
                    )}
                    {info.additionalExposure.map((exp) => (
                      <Badge
                        key={exp}
                        className="bg-blue-100 text-blue-700 border-0"
                      >
                        {exp}
                      </Badge>
                    ))}
                  </div>
                </ReviewSection>
                <ReviewSection
                  title={`Symptoms (${presentCount} reported)`}
                  onEdit={() => setStep(2)}
                  editOcid="assessment.edit_symptoms.edit_button"
                >
                  {presentCount === 0 ? (
                    <p className="text-sm text-muted-foreground">
                      No symptoms reported
                    </p>
                  ) : (
                    <div className="space-y-1">
                      {symptoms
                        .filter((s) => s.present)
                        .map((s) => (
                          <div
                            key={s.id}
                            className="flex items-center justify-between text-sm"
                          >
                            <span>{s.name}</span>
                            <span className="text-xs text-muted-foreground">
                              {s.durationWeek === "8+" ? "8+ weeks" : s.durationWeek === "unsure" ? "Not sure" : `Week ${s.durationWeek}`} | {s.trend}{s.frequency ? ` | ${s.frequency}` : ""}{s.intensity ? ` | ${s.intensity}` : ""}
                            </span>
                          </div>
                        ))}
                    </div>
                  )}
                </ReviewSection>
                {uploadedImages.length > 0 && (
                  <ReviewSection
                    title={`Images (${uploadedImages.length} uploaded)`}
                    onEdit={() => setStep(4)}
                    editOcid="assessment.edit_images.edit_button"
                  >
                    <div className="flex gap-2">
                      {uploadedImages.slice(0, 4).map((img) => (
                        <div
                          key={img.slice(-20)}
                          className="w-12 h-12 rounded-lg overflow-hidden border border-border"
                        >
                          <img
                            src={img}
                            alt="Uploaded scan"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  </ReviewSection>
                )}
                <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
                  <div className="flex items-start gap-3 cursor-pointer">
                    <Checkbox
                      checked={submitConsentGiven}
                      onCheckedChange={(v) => {
                        setSubmitConsentGiven(!!v);
                        setSubmitConsentError(false);
                      }}
                      data-ocid="assessment.submit_consent.checkbox"
                      className="mt-0.5"
                    />
                    <span className="text-sm">
                      I confirm the information above is accurate and consent to
                      submitting it for AI analysis and medical review.
                    </span>
                  </div>
                  {submitConsentError && (
                    <p className="text-xs text-destructive mt-2">
                      Please accept consent before submitting.
                    </p>
                  )}
                </div>
              </div>
              <div className="flex gap-3 mt-4">
                <Button
                  variant="outline"
                  onClick={() => setStep(4)}
                  data-ocid="assessment.review_back.button"
                >
                  <ChevronLeft size={16} /> Back
                </Button>
                <Button
                  onClick={handleSubmit}
                  className="flex-1 bg-primary"
                  data-ocid="assessment.submit.primary_button"
                >
                  Confirm &amp; Submit Report
                </Button>
              </div>
            </motion.div>
          )}

          {step === 6 && (
            <motion.div
              key="submitting"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-12"
            >
              {submittingStep < 4 ? (
                <div className="max-w-sm mx-auto">
                  <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                  </div>
                  <h2 className="text-xl font-bold mb-6">
                    Processing Your Report
                  </h2>
                  <div
                    className="space-y-3"
                    data-ocid="assessment.loading_state"
                  >
                    {[
                      "Step 1 — Input check",
                      "Step 2 — Model check",
                      "Step 3 — Doctor review",
                    ].map((label, i) => (
                      <div
                        key={label}
                        className={`flex items-center gap-3 p-3 rounded-lg transition-all ${
                          submittingStep > i + 1
                            ? "bg-green-50 text-green-700"
                            : submittingStep === i + 1
                              ? "bg-primary/10 text-primary font-semibold"
                              : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {submittingStep > i + 1 ? (
                          <CheckCircle size={16} />
                        ) : submittingStep === i + 1 ? (
                          <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border-2 border-muted-foreground/30" />
                        )}
                        <span className="text-sm">{label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : showDoctorConsent && assignedDoctor ? (
                /* Doctor consent prompt */
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="max-w-md mx-auto"
                  data-ocid="assessment.doctor_consent_state"
                >
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle size={28} className="text-primary" />
                  </div>
                  <h2 className="text-xl font-bold mb-2">
                    Share With a Specialist?
                  </h2>
                  <p className="text-sm text-muted-foreground mb-5">
                    Do you want to request dermatologist review? The report will appear in this app's dermatologist dashboard.
                  </p>
                  <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 mb-5 text-left">
                    <p className="text-xs font-semibold text-muted-foreground mb-1">
                      Recommended Specialist
                    </p>
                    <p className="font-bold text-primary text-base">
                      {assignedDoctor} (Skin Specialist)
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Based on your symptom profile, you have been matched to a{" "}
                      {assignedDoctor}.
                    </p>
                  </div>
                  <div className="space-y-3">
                    <Button
                      onClick={handleConsentYes}
                      className="w-full bg-primary"
                      data-ocid="assessment.confirm_send.primary_button"
                    >
                      <CheckCircle size={16} className="mr-2" />
                      Yes, Share My Report
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleConsentNo}
                      className="w-full"
                      data-ocid="assessment.go_to_dashboard.primary_button"
                    >
                      No, Keep Private — Go to Dashboard
                    </Button>
                  </div>
                </motion.div>
              ) : (
                /* Risk result + confirm button */
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="max-w-md mx-auto"
                  data-ocid="assessment.success_state"
                >
                  {/* Risk score display — ALWAYS shown first */}
                  {riskResult &&
                    (() => {
                      const display = getRiskZoneDisplay();
                      if (!display) return null;
                      return (
                        <div
                          className={`rounded-2xl border-2 p-5 mb-5 ${display.cls}`}
                        >
                          <div className="text-3xl mb-2">{display.emoji}</div>
                          <div className="text-4xl font-black mb-1">
                            {riskResult.score}/120
                          </div>
                          <div className="text-xs font-semibold mb-2">Screening score</div>
                          <div
                            className={`inline-block px-3 py-1 rounded-full text-xs font-bold mb-3 ${display.badgeCls}`}
                          >
                            {display.zone}
                          </div>
                          <p className="font-semibold text-sm leading-snug">
                            {display.msg}
                          </p>
                          <div className="mt-4 rounded-xl bg-white/70 p-3 text-left space-y-2">
                            <p className="text-xs font-semibold">Next step: {nextStep}</p>
                            <p className="text-xs font-semibold">Top reasons from your answers</p>
                            {(riskResult.topContributors.length ? riskResult.topContributors : []).map((reason) => <p key={reason.name} className="text-xs">• {reason.name}</p>)}
                            {riskResult.topContributors.length === 0 && <p className="text-xs">• No symptoms were reported.</p>}
                            <div className="border-t border-border/50 pt-2 text-[11px] text-muted-foreground">
                              <p>Step 1 Input check: {inputCheck?.passed === false ? (inputCheck.issues ?? []).join("; ") : "Passed"}</p>
                              <p>Step 2 Model check: {modelCheck ? `${modelCheck.zone ?? "Complete"} zone, ${modelCheck.confidence ?? "confidence unavailable"} confidence` : API_BASE_URL ? "Model unavailable; using the rule-based fallback." : "Model disabled; using rule-based screening."}</p>
                              <p>Step 3 Doctor review: {doctorReview?.status ?? "Pending dermatologist review"}</p>
                            </div>
                          </div>
                        </div>
                      );
                    })()}

                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-5">
                    <p className="text-sm text-blue-800 font-medium">
                      Your request will be routed for dermatologist review. Timing depends on clinician availability.
                    </p>
                  </div>

                  <div className="space-y-3">
                    <Button
                      onClick={handleConfirmAndSendToDoctor}
                      className="w-full bg-primary"
                      data-ocid="assessment.confirm_and_send.primary_button"
                    >
                      <CheckCircle size={16} className="mr-2" />
                      Confirm &amp; Send to Doctor
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => onNavigate("patient-dashboard")}
                      className="w-full"
                      data-ocid="assessment.go_to_dashboard.button"
                    >
                      Go to Dashboard (Review Later)
                    </Button>
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <span className="text-xs text-muted-foreground">{label}:</span>
      <span className="ml-1.5 text-xs font-medium">{value}</span>
    </div>
  );
}

function ReviewSection({
  title,
  children,
  onEdit,
  editOcid,
}: {
  title: string;
  children: React.ReactNode;
  onEdit: () => void;
  editOcid: string;
}) {
  return (
    <div className="bg-card rounded-xl border border-border p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold">{title}</h3>
        <button
          type="button"
          onClick={onEdit}
          data-ocid={editOcid}
          className="text-xs text-primary hover:underline"
        >
          Edit
        </button>
      </div>
      {children}
    </div>
  );
}

function SymptomGroup({
  title,
  desc,
  symptoms,
  onUpdate,
  expandedInfo,
  onToggleInfo,
}: {
  title: string;
  desc: string;
  symptoms: SymptomEntry[];
  onUpdate: (id: number, updates: Partial<SymptomEntry>) => void;
  expandedInfo: number | null;
  onToggleInfo: (id: number | null) => void;
}) {
  return (
    <div className="mb-6">
      <h3 className="text-base font-bold mb-1">{title}</h3>
      <p className="text-xs text-muted-foreground mb-3">{desc}</p>
      <div className="space-y-3">
        {symptoms.map((s) => (
          <SymptomCard
            key={s.id}
            symptom={s}
            onUpdate={onUpdate}
            infoOpen={expandedInfo === s.id}
            onToggleInfo={() =>
              onToggleInfo(expandedInfo === s.id ? null : s.id)
            }
          />
        ))}
      </div>
    </div>
  );
}

function SymptomCard({ symptom, onUpdate, infoOpen, onToggleInfo }: { symptom: SymptomEntry; onUpdate: (id: number, updates: Partial<SymptomEntry>) => void; infoOpen: boolean; onToggleInfo: () => void }) {
  const explanation = SYMPTOM_EXPLANATIONS[symptom.name] || '';
  const contextQs = SYMPTOM_CONTEXT_QUESTIONS[symptom.name] || [];
  return (
    <div className={`bg-card rounded-xl border transition-all ${symptom.present ? 'border-primary/40 shadow-sm' : 'border-border'}`}>
      <div className="p-4"><div className="flex items-start justify-between gap-3"><div className="flex-1"><div className="flex items-center gap-2"><span className="text-sm font-semibold">{symptom.name}</span><button type="button" onClick={onToggleInfo} className="text-muted-foreground hover:text-primary"><Info size={14} /></button></div>{infoOpen && <p className="text-xs text-muted-foreground mt-1.5 bg-muted rounded-lg p-2">{explanation}</p>}</div><div className="flex gap-2 flex-shrink-0">{(['Yes', 'No'] as const).map((answer) => <button key={answer} type="button" onClick={() => onUpdate(symptom.id, { answer, present: answer === 'Yes' })} className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${symptom.answer === answer ? answer === 'Yes' ? 'bg-green-500 text-white' : 'bg-muted-foreground/20 text-foreground' : 'bg-muted text-muted-foreground hover:bg-primary/10'}`}>{answer}</button>)}</div></div></div>
      {symptom.answer === 'Yes' && <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="px-4 pb-4 border-t border-border pt-3 space-y-4">
        <div><p className="text-xs font-semibold mb-2">Duration <span className="text-destructive">*</span></p><div className="flex flex-wrap gap-1.5">{[1, 2, 3, 4, 5, 6, 7, 8].map((week) => <button key={week} type="button" onClick={() => onUpdate(symptom.id, { durationWeek: week })} className={`px-2.5 py-2 rounded-lg text-xs font-semibold border ${symptom.durationWeek === week ? 'bg-primary text-white border-primary' : 'border-border hover:border-primary/50'}`}>Week {week}</button>)}{(['8+', 'unsure'] as const).map((value) => <button key={value} type="button" onClick={() => onUpdate(symptom.id, { durationWeek: value })} className={`px-2.5 py-2 rounded-lg text-xs font-semibold border ${symptom.durationWeek === value ? 'bg-primary text-white border-primary' : 'border-border hover:border-primary/50'}`}>{value === '8+' ? '8+ weeks' : 'Not sure'}</button>)}</div></div>
        <AnswerChoices label="Trend" required values={['Better', 'Same', 'Worse']} selected={symptom.trend} onSelect={(value) => onUpdate(symptom.id, { trend: value as SymptomEntry['trend'] })} />
        {symptom.freq && <AnswerChoices label="Frequency" required values={['Rare', 'Occasional', 'Frequent']} selected={symptom.frequency} description="Rare = once or twice in the period; Occasional = a few times a week; Frequent = daily or constant." onSelect={(value) => onUpdate(symptom.id, { frequency: value as SymptomEntry['frequency'] })} />}
        {symptom.intensityLabels && <AnswerChoices label="Intensity" required values={symptom.intensityLabels} selected={symptom.intensity} onSelect={(value) => onUpdate(symptom.id, { intensity: value })} />}
        {contextQs.length > 0 && <div className="space-y-3 border-t border-border/50 pt-3"><p className="text-xs font-semibold text-muted-foreground">Follow-up details</p>{contextQs.map((q) => { const answer = symptom.followUps?.[q.key]; const options = q.options ?? ['Measured', 'Estimated', 'Not sure']; const choose = (value: string) => { const current = Array.isArray(answer) ? answer : []; const next = q.multi ? (current.includes(value) ? current.filter((v) => v !== value) : [...current, value]) : value; onUpdate(symptom.id, { followUps: { ...symptom.followUps, [q.key]: next } }); }; return <div key={q.key}><p className="text-xs font-medium mb-1.5">{q.question}{q.multi ? ' (select all that apply)' : ''}</p><div className="flex flex-wrap gap-2">{options.map((option) => { const selected = Array.isArray(answer) ? answer.includes(option) : answer === option; return <button key={option} type="button" onClick={() => choose(option)} className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${selected ? 'bg-primary/80 text-white border-primary/80' : 'border-border hover:border-primary/50 bg-muted/50'}`}>{option}</button>; })}</div></div>; })}</div>}
      </motion.div>}
    </div>
  );
}
function AnswerChoices({ label, values, selected, required, description, onSelect }: { label: string; values: readonly string[]; selected: string | null; required?: boolean; description?: string; onSelect: (value: string) => void }) {
  return <div><p className="text-xs font-semibold mb-2">{label}{required && <span className="text-destructive"> *</span>}</p>{description && <p className="text-xs text-muted-foreground mb-2">{description}</p>}<div className="flex flex-wrap gap-2">{values.map((value) => <button key={value} type="button" onClick={() => onSelect(value)} className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${selected === value ? "bg-primary text-white border-primary" : "border-border hover:border-primary/50"}`}>{value}</button>)}</div></div>;
}

