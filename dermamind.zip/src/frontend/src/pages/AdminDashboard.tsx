import { Badge } from "@/components/ui/badge";
import {
  Activity,
  AlertTriangle,
  Lock,
  Shield,
  Trash2,
  Users,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  PolarAngleAxis,
  PolarGrid,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
  ZAxis,
} from "recharts";
import { usePatientStore } from "../context/PatientStore";

export default function AdminDashboard() {
  const { patients, clearAllPatients } = usePatientStore();
  const [showConfirm, setShowConfirm] = useState(false);
  const [cleared, setCleared] = useState(false);

  function handleClearConfirm() {
    clearAllPatients();
    setShowConfirm(false);
    setCleared(true);
    setTimeout(() => setCleared(false), 4000);
  }

  const riskCounts = { green: 0, yellow: 0, red: 0 };
  for (const p of patients) riskCounts[p.riskZone]++;

  // Donut chart data
  const donutData = [
    { name: "Low Risk", value: riskCounts.green, color: "#22c55e" },
    { name: "Moderate", value: riskCounts.yellow, color: "#f59e0b" },
    { name: "High Risk", value: riskCounts.red, color: "#ef4444" },
  ];

  // Monthly submissions
  const monthMap: Record<string, number> = {};
  for (const p of patients) {
    const month = new Date(p.submittedAt).toLocaleDateString("en-IN", {
      month: "short",
      year: "2-digit",
    });
    monthMap[month] = (monthMap[month] || 0) + 1;
  }
  const lineData = Object.entries(monthMap).map(([month, count]) => ({
    month,
    count,
  }));

  // Age vs risk scatter
  const ageGroups = [
    { label: "Under 35", min: 0, max: 34 },
    { label: "35–49", min: 35, max: 49 },
    { label: "50+", min: 50, max: 120 },
  ];
  const scatterData = ageGroups.map((group) => {
    const members = patients.filter((p) => p.age >= group.min && p.age <= group.max);
    return { age: group.label, score: members.length ? members.reduce((sum, p) => sum + p.riskScore, 0) / members.length : 0, z: members.length };
  }).filter((group) => group.z > 0);

  // Symptom frequency bar
  const symptomFreq: Record<string, number> = {};
  for (const p of patients) {
    for (const s of p.symptoms.filter((x) => x.present)) {
      symptomFreq[s.name] = (symptomFreq[s.name] || 0) + 1;
    }
  }
  const barData = Object.entries(symptomFreq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, count]) => ({ name: name.split(" ")[0], count }));

  // Area/wave data
  const waveData = patients
    .slice()
    .reverse()
    .map((p, i) => ({
      name: `#${i + 1}`,
      score: p.riskScore,
      submissions: i + 1,
    }));

  // Radar data
  const radarData = [
    {
      factor: "Smokers",
      value: patients.filter(
        (p) =>
          p.smoking ||
          p.smokingLevel === "Frequent" ||
          p.smokingLevel === "Occasional",
      ).length,
    },
    {
      factor: "Family Hist.",
      value: patients.filter((p) => p.familyHistory).length,
    },
    {
      factor: "Chem. Exp.",
      value: patients.filter((p) => p.chemicalExposure).length,
    },
    {
      factor: "Rad. Exp.",
      value: patients.filter((p) => p.radiationExposure).length,
    },
    { factor: "Age >50", value: patients.filter((p) => p.age > 50).length },
    { factor: "High Risk", value: riskCounts.red },
  ];

  // Histogram: risk score distribution
  const histBins = [
    { range: "Green 0–29", min: 0, max: 29 },
    { range: "Yellow 30–69", min: 30, max: 69 },
    { range: "Red 70–120", min: 70, max: 120 },
  ];
  const histData = histBins.map((bin) => ({
    range: bin.range,
    count: patients.filter(
      (p) => p.riskScore >= bin.min && p.riskScore <= bin.max,
    ).length,
    fill: bin.min >= 70 ? "#ef4444" : bin.min >= 30 ? "#f59e0b" : "#22c55e",
  }));

  // Zone distribution (already in donutData) — add separate prominent zone bar
  const zoneBarData = [
    { name: "Green (Low)", count: riskCounts.green, fill: "#22c55e" },
    { name: "Yellow (Mod)", count: riskCounts.yellow, fill: "#f59e0b" },
    { name: "Red (High)", count: riskCounts.red, fill: "#ef4444" },
  ];

  // Growth trend: submissions per day last 7 days
  const growthTrend = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const dateStr = d.toISOString().split("T")[0];
    return {
      name: d.toLocaleDateString("en-IN", { weekday: "short", day: "numeric" }),
      submissions: patients.filter((p) => p.submittedAt?.startsWith(dateStr))
        .length,
    };
  });

  // System usage: cumulative daily users
  const systemUsage = growthTrend.map((d, i) => ({
    name: d.name,
    total: growthTrend.slice(0, i + 1).reduce((s, x) => s + x.submissions, 0),
    daily: d.submissions,
  }));

  const summaryCards = [
    {
      label: "Total Submissions",
      value: patients.length,
      color: "text-primary",
      icon: <Activity size={18} />,
    },
    {
      label: "High Risk",
      value: riskCounts.red,
      color: "text-red-600",
      icon: <Shield size={18} />,
    },
    {
      label: "Moderate Risk",
      value: riskCounts.yellow,
      color: "text-amber-600",
      icon: <Activity size={18} />,
    },
    {
      label: "Low Risk",
      value: riskCounts.green,
      color: "text-green-600",
      icon: <Users size={18} />,
    },
  ];

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-6">
      {/* Confirmation Modal */}
      <AnimatePresence>
        {showConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
            data-ocid="admin.clear_data.dialog"
          >
            <motion.div
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.92, opacity: 0 }}
              className="bg-card rounded-2xl border border-red-200 shadow-xl p-6 w-full max-w-md"
            >
              <div className="flex items-start gap-3 mb-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
                  <AlertTriangle size={20} className="text-red-600" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-foreground">
                    Delete All Patient Data?
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                    Are you sure you want to delete all patient data? This will
                    permanently remove all assessments, appointments, and
                    records from all dashboards.{" "}
                    <span className="font-semibold text-red-600">
                      This action cannot be undone.
                    </span>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowConfirm(false)}
                  className="flex-shrink-0 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label="Close"
                  data-ocid="admin.clear_data.close_button"
                >
                  <X size={18} />
                </button>
              </div>
              <div className="flex gap-3 justify-end mt-5">
                <button
                  type="button"
                  onClick={() => setShowConfirm(false)}
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-muted text-muted-foreground hover:bg-muted/80 transition-colors"
                  data-ocid="admin.clear_data.cancel_button"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleClearConfirm}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-red-600 text-white hover:bg-red-700 transition-colors flex items-center gap-2"
                  data-ocid="admin.clear_data.confirm_button"
                >
                  <Trash2 size={14} />
                  Yes, Clear All Data
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success Toast */}
      <AnimatePresence>
        {cleared && (
          <motion.div
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-green-600 text-white text-sm font-medium px-5 py-3 rounded-xl shadow-lg flex items-center gap-2"
            data-ocid="admin.clear_data.success_state"
          >
            <span className="text-base">✓</span>
            All patient data has been cleared successfully.
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold">Admin Dashboard</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Aggregate analytics — Privacy-first view
            </p>
          </div>
          <div className="flex items-center gap-1.5 bg-primary/5 border border-primary/20 rounded-lg px-3 py-1.5">
            <Lock size={12} className="text-primary" />
            <span className="text-xs text-primary font-medium">
              Restricted Access
            </span>
          </div>
        </div>
      </motion.div>

      {/* Clear All Data Section */}
      <div className="rounded-xl border border-red-200 bg-red-50/60 p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-red-100 flex items-center justify-center mt-0.5">
            <AlertTriangle size={16} className="text-red-600" />
          </div>
          <div>
            <p className="text-sm font-semibold text-red-700">
              Data Management
            </p>
            <p className="text-xs text-red-600/80 mt-0.5">
              Permanently removes all patient assessments, appointments, and
              records from every dashboard.
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowConfirm(true)}
          className="flex-shrink-0 flex items-center gap-2 px-4 py-2 rounded-lg bg-red-600 text-white text-sm font-semibold hover:bg-red-700 active:scale-95 transition-all shadow-sm"
          data-ocid="admin.clear_data_button"
        >
          <Trash2 size={14} />
          Clear All Patient Data
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <div
            key={card.label}
            className="bg-card rounded-xl border border-gray-100 shadow-sm p-6"
          >
            <div className={`flex items-center gap-2 mb-2 ${card.color}`}>
              {card.icon}
              <span className="text-xs font-semibold">{card.label}</span>
            </div>
            <div className={`text-3xl font-bold ${card.color}`}>
              {card.value}
            </div>
          </div>
        ))}
      </div>

      {/* Patient list */}
      <section>
        <h2 className="text-base font-bold mb-3 flex items-center gap-2">
          <Users size={16} className="text-primary" /> Patient Overview
          <span className="text-xs text-muted-foreground font-normal">
            (Limited view only)
          </span>
        </h2>
        {patients.length === 0 ? (
          <div
            className="bg-card rounded-xl border border-border p-8 text-center"
            data-ocid="admin.patients.empty_state"
          >
            <Activity
              size={28}
              className="mx-auto mb-3 text-muted-foreground"
            />
            <p className="text-sm text-muted-foreground">
              No patient submissions yet.
            </p>
          </div>
        ) : (
          <div className="bg-card rounded-xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted border-b border-border">
                    <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">
                      Case
                    </th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">
                      Age group
                    </th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">
                      Screening score
                    </th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">
                      Risk zone
                    </th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">
                      Reports
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {patients.map((p, i) => (
                    <tr
                      key={p.id}
                      className="border-b border-border/50 hover:bg-muted/30 transition-colors"
                      data-ocid={`admin.patient.row.${i + 1}`}
                    >
                      <td className="px-4 py-3 text-xs font-mono text-muted-foreground">
                        Case {i + 1}
                      </td>
                      <td className="px-4 py-3 text-xs font-medium">
                        {p.age < 35 ? "Under 35" : p.age < 50 ? "35–49" : "50+"}
                      </td>
                      <td className="px-4 py-3 text-xs">{p.riskScore}/120</td>
                      <td className="px-4 py-3">
                        <Badge
                          className={`text-xs border-0 ${
                            p.riskZone === "red"
                              ? "bg-red-100 text-red-700"
                              : p.riskZone === "yellow"
                                ? "bg-amber-100 text-amber-700"
                                : "bg-green-100 text-green-700"
                          }`}
                        >
                          {p.riskZone === "red"
                            ? "High"
                            : p.riskZone === "yellow"
                              ? "Moderate"
                              : "Low"}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-xs">1</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
          <Lock size={10} /> Admin view uses anonymized case summaries; direct identifiers are hidden.
        </p>
      </section>

      {/* Analytics Charts */}
      {patients.length > 0 && (
        <section>
          <h2 className="text-base font-bold mb-4">Aggregate Analytics</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {/* Area/Wave chart */}
            <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Risk Score Trend (Area/Wave)
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart
                  data={waveData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <defs>
                    <linearGradient id="adminWave" x1="0" y1="0" x2="0" y2="1">
                      <stop
                        offset="5%"
                        stopColor="#E53935"
                        stopOpacity={0.25}
                      />
                      <stop offset="95%" stopColor="#E53935" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 10 }}
                    label={{
                      value: "Submissions",
                      position: "insideBottom",
                      offset: -2,
                      fontSize: 9,
                    }}
                  />
                  <YAxis
                    tick={{ fontSize: 10 }}
                    label={{
                      value: "Risk Score",
                      angle: -90,
                      position: "insideLeft",
                      fontSize: 9,
                    }}
                    domain={[0, 120]}
                  />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="score"
                    stroke="#E53935"
                    fill="url(#adminWave)"
                    strokeWidth={2}
                    name="Risk Score"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Donut chart (replaces pie) */}
            <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Risk Distribution (Donut)
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={donutData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={75}
                    dataKey="value"
                    label
                  >
                    {donutData.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                  <Legend iconSize={10} />
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Monthly line chart */}
            {lineData.length > 0 && (
              <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">
                  Monthly Submissions
                </h3>
                <ResponsiveContainer width="100%" height={220}>
                  <LineChart
                    data={lineData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                    <YAxis
                      tick={{ fontSize: 10 }}
                      label={{
                        value: "Count",
                        angle: -90,
                        position: "insideLeft",
                        fontSize: 9,
                      }}
                    />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="count"
                      stroke="#E53935"
                      strokeWidth={2}
                      dot
                      name="Submissions"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Age vs Risk scatter */}
            {scatterData.length > 0 && (
              <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">
                  Average score by age group
                </h3>
                <ResponsiveContainer width="100%" height={220}>
                  <ScatterChart
                    margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis
                      dataKey="age"
                      type="category"
                      tick={{ fontSize: 10 }}
                      label={{
                        value: "Age group",
                        position: "insideBottom",
                        offset: -2,
                        fontSize: 9,
                      }}
                    />
                    <YAxis
                      dataKey="score"
                      type="number"
                      tick={{ fontSize: 10 }}
                      label={{
                        value: "Score",
                        angle: -90,
                        position: "insideLeft",
                        fontSize: 9,
                      }}
                    />
                    <ZAxis dataKey="z" range={[40, 80]} />
                    <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                    <Scatter
                      data={scatterData}
                      fill="#E53935"
                      fillOpacity={0.7}
                      name="Age group"
                    />
                  </ScatterChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Bar chart */}
            {barData.length > 0 && (
              <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">
                  Symptom Frequency
                </h3>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart
                    data={barData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis
                      tick={{ fontSize: 10 }}
                      label={{
                        value: "Count",
                        angle: -90,
                        position: "insideLeft",
                        fontSize: 9,
                      }}
                    />
                    <Tooltip />
                    <Bar
                      dataKey="count"
                      fill="#E53935"
                      radius={[4, 4, 0, 0]}
                      name="Count"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Radar chart */}
            <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Risk Factor Radar
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <RadarChart
                  data={radarData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <PolarGrid />
                  <PolarAngleAxis dataKey="factor" tick={{ fontSize: 10 }} />
                  <Radar
                    name="Count"
                    dataKey="value"
                    stroke="#E53935"
                    fill="#E53935"
                    fillOpacity={0.25}
                  />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </div>

            {/* NEW: Histogram */}
            <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Risk Score Distribution (Histogram)
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart
                  data={histData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="range" tick={{ fontSize: 9 }} />
                  <YAxis
                    tick={{ fontSize: 10 }}
                    label={{
                      value: "Patients",
                      angle: -90,
                      position: "insideLeft",
                      fontSize: 9,
                    }}
                  />
                  <Tooltip />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]} name="Patients">
                    {histData.map((entry) => (
                      <Cell key={entry.range} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* NEW: Zone Distribution Chart */}
            <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Zone Distribution
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart
                  data={zoneBarData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis
                    tick={{ fontSize: 10 }}
                    label={{
                      value: "Patients",
                      angle: -90,
                      position: "insideLeft",
                      fontSize: 9,
                    }}
                    allowDecimals={false}
                  />
                  <Tooltip />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]} name="Patients">
                    {zoneBarData.map((entry) => (
                      <Cell key={entry.name} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* NEW: Growth Trend Chart */}
            <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Growth Trend (Last 7 Days)
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart
                  data={growthTrend}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <defs>
                    <linearGradient id="growthGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop
                        offset="5%"
                        stopColor="#E53935"
                        stopOpacity={0.25}
                      />
                      <stop offset="95%" stopColor="#E53935" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 9 }} />
                  <YAxis
                    tick={{ fontSize: 10 }}
                    allowDecimals={false}
                    label={{
                      value: "New",
                      angle: -90,
                      position: "insideLeft",
                      fontSize: 9,
                    }}
                  />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="submissions"
                    stroke="#E53935"
                    fill="url(#growthGrad)"
                    strokeWidth={2}
                    name="New Submissions"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* NEW: System Usage Chart */}
            <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                System Usage (Daily &amp; Cumulative)
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart
                  data={systemUsage}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <defs>
                    <linearGradient id="usageGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop
                        offset="5%"
                        stopColor="#f59e0b"
                        stopOpacity={0.25}
                      />
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 9 }} />
                  <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                  <Tooltip />
                  <Legend iconSize={10} />
                  <Area
                    type="monotone"
                    dataKey="total"
                    stroke="#f59e0b"
                    fill="url(#usageGrad)"
                    strokeWidth={2}
                    name="Cumulative"
                  />
                  <Area
                    type="monotone"
                    dataKey="daily"
                    stroke="#E53935"
                    fill="none"
                    strokeWidth={1.5}
                    name="Daily"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
