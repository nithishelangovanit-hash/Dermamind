import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  Activity,
  AlertCircle,
  Bell,
  Building2,
  Calendar,
  CalendarCheck,
  CheckCircle,
  ClipboardList,
  Download,
  FlaskConical,
  MessageSquare,
  RefreshCcw,
  Shield,
  Stethoscope,
  Video,
} from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  PolarAngleAxis,
  PolarGrid,
  Radar,
  RadarChart,
  RadialBar,
  RadialBarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { usePatientStore } from "../context/PatientStore";
import {
  cancerCoverageChecklist,
  cancerCoverageOptions,
  existingCoverageNote,
  irdaiHealthInsuranceUrl,
} from "../data/cancerCoverageOptions";
import type { Appointment, Patient, Screen, User } from "../types";
import { generateUserReportPDF } from "../utils/pdfGenerator";
import { getRiskColors, getRiskLabel } from "../utils/riskEngine";

interface Props {
  onNavigate: (screen: Screen) => void;
  user: User;
}

const DOCTORS_PRIVATE = [
  { hospital: 'Apollo Hospitals', specialty: 'Dermatologist', location: 'Greams Road, Chennai', availability: 'Mon–Sat, 9AM–5PM', type: 'Private', fee: '₹800–₹1200' },
  { hospital: 'Fortis Malar Hospital', specialty: 'Dermatologist', location: 'Adyar, Chennai', availability: 'Mon–Fri, 10AM–4PM', type: 'Private', fee: '₹600–₹900' },
  { hospital: 'Global Hospitals', specialty: 'Dermatologist', location: 'Perumbakkam, Chennai', availability: 'Mon–Sat, 9AM–5PM', type: 'Private', fee: '₹700–₹1100' },
];

const DOCTORS_GOVT = [
  { hospital: 'Rajiv Gandhi Govt General Hospital', specialty: 'Dermatologist', location: 'Park Town, Chennai', availability: 'Mon–Sat, 8AM–2PM', type: 'Government', fee: '₹0–₹50 (Free/Nominal)' },
  { hospital: 'Adyar Cancer Institute (WIA)', specialty: 'Dermatologist', location: 'Adyar, Chennai', availability: 'Mon–Fri, 9AM–3PM', type: 'Government', fee: '₹0–₹100 (Subsidized)' },
  { hospital: 'Kilpauk Medical College Hospital', specialty: 'Dermatologist', location: 'Kilpauk, Chennai', availability: 'Mon–Sat, 8AM–2PM', type: 'Government', fee: '₹0–₹50 (Free/Nominal)' },
];

const LABS = [
  { name: 'Aarthi Scans & Labs', location: 'T Nagar, Chennai', tests: ['Dermoscopy', 'Mole mapping', 'Skin biopsy'], cost: '₹500–₹4000' },
  { name: 'Apollo Diagnostics', location: 'Anna Nagar, Chennai', tests: ['Skin biopsy', 'Dermatology consultation'], cost: '₹400–₹5000' },
  { name: 'Neuberg Diagnostics', location: 'Velachery, Chennai', tests: ['Dermoscopy', 'Skin biopsy'], cost: '₹300–₹3500' },
  { name: 'Metropolis Healthcare', location: 'Nungambakkam, Chennai', tests: ['Dermoscopy', 'Mole mapping'], cost: '₹400–₹4000' },
];

const BOOKING_DOCTORS = [
  { name: 'Dr. Ramesh Nair', specialty: 'Dermatologist', exp: '15 yrs', hospital: 'Apollo Hospital', available: 'Mon, Wed, Fri' },
  { name: 'Dr. Priya Sharma', specialty: 'Dermatologist', exp: '12 yrs', hospital: 'AIIMS Delhi', available: 'Tue, Thu, Sat' },
];
const TIME_SLOTS = [
  "9:00 AM",
  "10:00 AM",
  "11:00 AM",
  "2:00 PM",
  "3:00 PM",
  "4:00 PM",
];

const NEXT_7_DAYS = Array.from({ length: 7 }, (_, i) => {
  const d = new Date();
  d.setDate(d.getDate() + i + 1);
  return {
    label: d.toLocaleDateString("en-IN", {
      weekday: "short",
      day: "numeric",
      month: "short",
    }),
    value: d.toISOString().split("T")[0],
  };
});

export default function PatientDashboard({ onNavigate, user }: Props) {
  const { patients, updatePatient } = usePatientStore();
  const myPatients = patients.filter((p) => p.userEmail === user.email);
  const latest = myPatients[0] || null;

  const showConsultation = latest?.riskZone === "red" && latest?.doctorReviewed;
  const showDoctorRecommendation = !!(
    latest?.recommendationSubmitted &&
    (latest?.riskZone === "yellow" || latest?.riskZone === "red")
  );
  const appointments = myPatients.flatMap((p) => p.appointments || []);

  const [consultType, setConsultType] = useState<"online" | "offline" | null>(
    null,
  );
  const [selectedDoctor, setSelectedDoctor] = useState<number | null>(null);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const [consultStep, setConsultStep] = useState<1 | 2 | 3>(1);

  function handleBookAppointment() {
    if (
      (!selectedDoctor && selectedDoctor !== 0) ||
      !selectedDate ||
      !selectedSlot ||
      !latest
    )
      return;
    const doc = BOOKING_DOCTORS[selectedDoctor];
    const appt: Appointment = {
      id: `APT-${Date.now()}`,
      patientId: latest.id,
      patientName: latest.name,
      doctorName: doc.name,
      specialty: doc.specialty,
      hospital: doc.hospital,
      date: selectedDate,
      slot: selectedSlot,
      consultationType: consultType!,
      status: "booked",
      doctorAction: null,
      bookedAt: new Date().toISOString(),
    };
    updatePatient(latest.id, {
      appointments: [...(latest.appointments || []), appt],
    });
    setBookingConfirmed(true);
  }

  // Wave chart data
  const waveData = myPatients
    .slice()
    .reverse()
    .map((p, i) => ({
      name: `Report ${i + 1}`,
      score: p.riskScore,
      confidence: p.confidenceScore,
    }));

  // Risk pie
  const riskCounts = { green: 0, yellow: 0, red: 0 };
  for (const p of myPatients) riskCounts[p.riskZone]++;
  const pieData = [
    { name: "Low Risk", value: riskCounts.green, color: "#22c55e" },
    { name: "Moderate", value: riskCounts.yellow, color: "#f59e0b" },
    { name: "High Risk", value: riskCounts.red, color: "#ef4444" },
  ].filter((d) => d.value > 0);

  // Radar chart data
  const latestPresent = latest ? latest.symptoms.filter((s) => s.present) : [];
  const radarData = latestPresent.slice(0, 8).map((s) => ({
    symptom: s.name.split(" ")[0],
    score: s.w,
  }));

  // Heatmap data groups reported duration and relative intensity.
  const heatmapData: Record<string, Record<string, number>> = {
    Higher: {},
    Moderate: {},
    Lower: {},
  };
  for (const s of latestPresent) {
    const wk = s.durationWeek === "8+" ? "8+" : s.durationWeek === "unsure" ? "Not sure" : String(s.durationWeek ?? "Not sure");
    const index = s.intensityLabels?.indexOf(s.intensity ?? "") ?? 1;
    const level = index <= 0 ? "Lower" : index >= 2 ? "Higher" : "Moderate";
    heatmapData[level][wk] = (heatmapData[level][wk] || 0) + 1;
  }
  const heatmapMax = Math.max(
    ...Object.values(heatmapData).flatMap((row) =>
      Object.values(row).map(Number),
    ),
    1,
  );

  // Gauge data
  const gaugeScore = latest ? latest.riskScore : 0;
  const gaugePct = Math.min(Math.round((gaugeScore / 120) * 100), 100);
  const gaugeColor =
    gaugeScore >= 70 ? "#ef4444" : gaugeScore >= 30 ? "#f59e0b" : "#22c55e";
  const gaugeData = [{ name: "Risk", value: gaugePct, fill: gaugeColor }];

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-6">
      {/* Welcome */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold">
              Welcome, {user.name.split(" ")[0]} 👋
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Your DermaMind health dashboard
            </p>
          </div>
          <Button
            onClick={() => onNavigate("assessment")}
            size="sm"
            data-ocid="patient.reassess.primary_button"
            className="flex items-center gap-1.5"
          >
            <RefreshCcw size={14} /> New Assessment
          </Button>
        </div>
      </motion.div>

      {/* Follow-Up Date Banner */}
      {latest?.assessmentDate && (
        <FollowUpBanner
          assessmentDate={latest.assessmentDate}
          followUpMonths={latest.followUpMonths ?? 3}
          onChangeMonths={(months) =>
            updatePatient(latest.id, { followUpMonths: months })
          }
        />
      )}

      {/* Reminder banner */}
      <div className="flex items-center gap-3 bg-primary/5 border border-primary/20 rounded-xl p-4">
        <Bell size={18} className="text-primary flex-shrink-0" />
        <p className="text-sm">
          <span className="font-semibold">Health Reminder:</span> Re-screen
            every few months for self-awareness. This tool does not detect or diagnose cancer.
        </p>
      </div>

      {/* Assigned Doctor / Routing Status */}
      {latest?.reviewConfirmed && latest?.assignedDoctorType && (
        <section>
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start gap-3">
            <Stethoscope
              size={18}
              className="text-blue-600 flex-shrink-0 mt-0.5"
            />
            <div>
              <p className="text-sm font-semibold text-blue-800">
                Your report has been assigned to:{" "}
                <span className="text-primary">
                  {latest.assignedDoctorType}
                  {" (Skin Specialist)"}
                </span>
              </p>
              <div className="flex items-center gap-2 mt-1">
                <Badge className="bg-blue-100 text-blue-700 border-0 text-xs">
                  Under Doctor Review
                </Badge>
                <span className="text-xs text-blue-600">
                  Review expected within 24 hours
                </span>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* My Reports */}
      <section>
        <h2 className="text-base font-bold mb-3 flex items-center gap-2">
          <ClipboardList size={16} className="text-primary" /> My Reports
        </h2>
        {myPatients.length === 0 ? (
          <div
            className="bg-card rounded-xl border border-border p-8 text-center"
            data-ocid="patient.reports.empty_state"
          >
            <Activity
              size={32}
              className="mx-auto mb-3 text-muted-foreground"
            />
            <p className="text-sm text-muted-foreground">
              No assessments submitted yet.
            </p>
            <Button
              size="sm"
              className="mt-3"
              onClick={() => onNavigate("assessment")}
              data-ocid="patient.start_assessment.primary_button"
            >
              Start Your First Assessment
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {myPatients.map((p, i) => (
              <ReportCard key={p.id} patient={p} index={i + 1} />
            ))}
          </div>
        )}
      </section>

      {/* Charts */}
      {myPatients.length > 0 && (
        <div className="space-y-5">
          {/* Row 1: Wave + Pie */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Screening score trend
              </h3>
              <ResponsiveContainer width="100%" height={160}>
                <AreaChart
                  data={waveData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <defs>
                    <linearGradient
                      id="patientGrad"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop offset="5%" stopColor="#E53935" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#E53935" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} domain={[0, 120]} />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="score"
                    stroke="#E53935"
                    fill="url(#patientGrad)"
                    strokeWidth={2}
                    name="Screening score"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            {pieData.length > 0 && (
              <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">
                  Risk Distribution
                </h3>
                <ResponsiveContainer width="100%" height={160}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={65}
                      dataKey="value"
                    >
                      {pieData.map((entry) => (
                        <Cell key={entry.name} fill={entry.color} />
                      ))}
                    </Pie>
                    <Legend iconSize={10} />
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          {/* Row 2: Radar + Gauge */}
          {latestPresent.length > 0 && (
            <div className="grid md:grid-cols-2 gap-6">
              {/* Radar */}
              <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">
                  Symptom Profile (Radar)
                </h3>
                <ResponsiveContainer width="100%" height={200}>
                  <RadarChart
                    data={radarData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                  >
                    <PolarGrid />
                    <PolarAngleAxis dataKey="symptom" tick={{ fontSize: 9 }} />
                    <Radar
                      name="Symptom"
                      dataKey="score"
                      stroke="#E53935"
                      fill="#E53935"
                      fillOpacity={0.25}
                    />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </div>

              {/* Gauge */}
              <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">
                  Risk Level Gauge
                </h3>
                <div className="relative">
                  <ResponsiveContainer width="100%" height={180}>
                    <RadialBarChart
                      cx="50%"
                      cy="70%"
                      innerRadius="60%"
                      outerRadius="100%"
                      startAngle={180}
                      endAngle={0}
                      data={gaugeData}
                    >
                      <RadialBar
                        dataKey="value"
                        cornerRadius={6}
                        background={{ fill: "#f0f0f0" }}
                      >
                        <Cell fill={gaugeColor} />
                      </RadialBar>
                    </RadialBarChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex flex-col items-center justify-end pb-4">
                    <span
                      className="text-2xl font-bold"
                      style={{ color: gaugeColor }}
                    >
                      {gaugeScore}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      / 120 Screening score
                    </span>
                    <span
                      className="text-xs font-semibold mt-0.5"
                      style={{ color: gaugeColor }}
                    >
                      {gaugeScore >= 70
                        ? "RED ZONE"
                        : gaugeScore >= 30
                          ? "YELLOW ZONE"
                          : "GREEN ZONE"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Row 3: Heatmap */}
          {latestPresent.length > 0 && (
            <div className="bg-card rounded-xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Symptom Heatmap (Week vs Intensity)
              </h3>
              <div className="overflow-x-auto">
                <div className="min-w-max">
                  <div className="flex gap-1 mb-1 ml-16">
                    {["1", "2", "3", "4", "5", "6", "7", "8", "8+", "Not sure"].map((w) => (
                      <div
                        key={w}
                        className="w-9 text-center text-xs text-muted-foreground"
                      >
                        {w === "Not sure" ? "?" : w === "8+" ? "8+" : `W${w}`}
                      </div>
                    ))}
                  </div>
                  {(["Higher", "Moderate", "Lower"] as const).map((intensity) => (
                    <div
                      key={intensity}
                      className="flex items-center gap-1 mb-1"
                    >
                      <div className="w-14 text-xs font-medium text-right pr-2">
                        {intensity}
                      </div>
                      {["1", "2", "3", "4", "5", "6", "7", "8", "8+", "Not sure"].map((w) => {
                        const count = heatmapData[intensity][w] || 0;
                        const opacity = count / heatmapMax;
                        return (
                          <div
                            key={w}
                            className="w-9 h-9 rounded-md flex items-center justify-center text-xs font-bold"
                            style={{
                              backgroundColor:
                                count > 0
                                  ? `rgba(229,57,53,${0.15 + opacity * 0.85})`
                                  : "#f5f5f5",
                              color:
                                opacity > 0.5
                                  ? "white"
                                  : count > 0
                                    ? "#c62828"
                                    : "#ccc",
                            }}
                          >
                            {count > 0 ? count : ""}
                          </div>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Cells show symptom count by reported duration and intensity from
                your latest assessment.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Row 4: Risk Breakdown + Progress + Comparison */}
      {latest && (
        <div className="space-y-5">
          {/* Risk breakdown by rule */}
          <div className="bg-card rounded-xl border border-border p-5">
            <h3 className="text-sm font-semibold mb-3">Risk breakdown by rule</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <ResponsiveContainer width="100%" height={180}>
                <PieChart><Pie data={Object.entries(latest.riskBreakdown ?? {}).map(([name, value]) => ({ name, value: Math.round(value) })).filter((item) => item.value > 0)} cx="50%" cy="50%" innerRadius={35} outerRadius={65} dataKey="value">{Object.keys(latest.riskBreakdown ?? {}).map((name, index) => <Cell key={name} fill={["#E53935", "#f59e0b", "#0ea5e9", "#8b5cf6", "#22c55e"][index % 5]} />)}</Pie><Legend iconSize={10} /><Tooltip /></PieChart>
              </ResponsiveContainer>
              <div className="flex flex-col justify-center gap-2">{Object.entries(latest.riskBreakdown ?? {}).map(([name, value]) => <div key={name} className="flex justify-between text-xs"><span>{name}</span><span className="font-semibold">{Math.round(value)} points</span></div>)}</div>
            </div>
          </div>
          {/* Risk Progress Bar */}
          <div className="bg-card rounded-xl border border-border p-5">
            <h3 className="text-sm font-semibold mb-3">
              Screening score zones (0 — 120)
            </h3>
            <div className="relative">
              <div className="flex h-7 rounded-full overflow-hidden">
                <div
                  className="bg-green-400 flex items-center justify-center text-xs font-bold text-white"
                  style={{ width: "24.2%" }}
                >
                  Green 0–29
                </div>
                <div
                  className="bg-amber-400 flex items-center justify-center text-xs font-bold text-white"
                  style={{ width: "33.3%" }}
                >
                  Yellow 30–69
                </div>
                <div
                  className="bg-red-500 flex items-center justify-center text-xs font-bold text-white"
                  style={{ width: "42.5%" }}
                >
                  Red 70–120
                </div>
              </div>
              <div
                className="absolute top-1/2 -translate-y-1/2 w-4 h-8 bg-foreground rounded-full border-2 border-card shadow"
                style={{
                  left: `calc(${Math.min((latest.riskScore / 120) * 100, 97)}% - 8px)`,
                }}
              />
            </div>
            <div className="flex justify-between text-xs text-muted-foreground mt-1.5">
              <span>0</span>
              <span>
                Your Score:{" "}
                <strong className="text-foreground">{latest.riskScore}</strong>
              </span>
              <span>120</span>
            </div>
          </div>

          {/* Comparison Chart */}
          {latestPresent.length > 0 && (
            <div className="bg-card rounded-xl border border-border p-5">
              <h3 className="text-sm font-semibold mb-3">
                Your Top Symptoms vs Normal Baseline
              </h3>
              <ResponsiveContainer width="100%" height={160}>
                <BarChart
                  data={latestPresent.slice(0, 6).map((s) => ({
                    name: s.name.split(" ")[0],
                    yours: s.baseScore,
                    baseline: 0,
                  }))}
                  margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 9 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Legend iconSize={10} />
                  <Bar
                    dataKey="yours"
                    fill="#E53935"
                    name="Your Score"
                    radius={[4, 4, 0, 0]}
                  />
                  <Bar
                    dataKey="baseline"
                    fill="#22c55e"
                    name="Baseline (0)"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}

      {/* Consultation Section */}
      {showConsultation && (
        <section className="bg-red-50 border border-red-200 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Stethoscope size={18} className="text-red-600" />
            <h2 className="text-base font-bold text-red-700">
              Doctor Consultation &amp; Appointments
            </h2>
            <Badge className="bg-red-100 text-red-700 border-0 text-xs">
              Red Zone Activated
            </Badge>
          </div>

          {!bookingConfirmed ? (
            <div className="space-y-4">
              {consultStep === 1 && (
                <div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Choose your preferred consultation type:
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {(["online", "offline"] as const).map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => {
                          setConsultType(type);
                          setConsultStep(2);
                        }}
                        className={`p-4 rounded-xl border-2 transition-all text-center ${
                          consultType === type
                            ? "border-primary bg-primary/5"
                            : "border-border hover:border-primary/50"
                        }`}
                        data-ocid={`patient.consult_${type}.button`}
                      >
                        {type === "online" ? (
                          <Video
                            size={22}
                            className="mx-auto mb-2 text-primary"
                          />
                        ) : (
                          <Calendar
                            size={22}
                            className="mx-auto mb-2 text-primary"
                          />
                        )}
                        <p className="font-semibold text-sm capitalize">
                          {type}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {type === "online"
                            ? "Video or Chat"
                            : "In-Person Visit"}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {consultStep === 2 && (
                <div>
                  <p className="text-lg font-semibold text-gray-800 mb-4">
                    Select a Doctor:
                  </p>
                  <div className="space-y-2">
                    {BOOKING_DOCTORS.map((doc, i) => (
                      <button
                        key={doc.name}
                        type="button"
                        onClick={() => {
                          setSelectedDoctor(i);
                          setConsultStep(3);
                        }}
                        className={`w-full text-left p-3 rounded-xl border-2 transition-all ${
                          selectedDoctor === i
                            ? "border-primary bg-primary/5"
                            : "border-border hover:border-primary/50"
                        }`}
                        data-ocid={`patient.select_doctor.button.${i + 1}`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold text-sm">
                            {doc.name.split(" ")[1][0]}
                            {doc.name.split(" ")[2]?.[0] || ""}
                          </div>
                          <div>
                            <p className="font-semibold text-sm">{doc.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {doc.specialty} &bull; {doc.exp}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              🏥 {doc.hospital} &bull; {doc.available}
                            </p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2"
                    onClick={() => setConsultStep(1)}
                    data-ocid="patient.consult_back.button"
                  >
                    Back
                  </Button>
                </div>
              )}

              {consultStep === 3 && selectedDoctor !== null && (
                <div>
                  {consultType === "online" ? (
                    <div className="space-y-3">
                      <p className="text-sm font-semibold">
                        Online Consultation with{" "}
                        {BOOKING_DOCTORS[selectedDoctor].name}
                      </p>
                      <div className="grid grid-cols-2 gap-3">
                        <Button
                          onClick={() => {
                            setSelectedSlot("Video");
                            setSelectedDate(
                              new Date().toISOString().split("T")[0],
                            );
                            handleBookAppointment();
                          }}
                          className="flex items-center gap-2"
                          data-ocid="patient.start_video.primary_button"
                        >
                          <Video size={16} /> Video Consultation
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setSelectedSlot("Chat");
                            setSelectedDate(
                              new Date().toISOString().split("T")[0],
                            );
                            handleBookAppointment();
                          }}
                          className="flex items-center gap-2"
                          data-ocid="patient.start_chat.button"
                        >
                          <MessageSquare size={16} /> Chat Consultation
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-sm font-semibold">
                        Book Offline Appointment
                      </p>
                      <div>
                        <p className="text-xs font-semibold mb-2">
                          Select Date:
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {NEXT_7_DAYS.map((d) => (
                            <button
                              key={d.value}
                              type="button"
                              onClick={() => setSelectedDate(d.value)}
                              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                                selectedDate === d.value
                                  ? "bg-primary text-white border-primary"
                                  : "border-border hover:border-primary/50"
                              }`}
                              data-ocid="patient.date_select.button"
                            >
                              {d.label}
                            </button>
                          ))}
                        </div>
                      </div>
                      {selectedDate && (
                        <div>
                          <p className="text-xs font-semibold mb-2">
                            Select Time Slot:
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {TIME_SLOTS.map((slot) => (
                              <button
                                key={slot}
                                type="button"
                                onClick={() => setSelectedSlot(slot)}
                                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                                  selectedSlot === slot
                                    ? "bg-primary text-white border-primary"
                                    : "border-border hover:border-primary/50"
                                }`}
                                data-ocid="patient.slot_select.button"
                              >
                                {slot}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setConsultStep(2)}
                          data-ocid="patient.consult_back2.button"
                        >
                          Back
                        </Button>
                        <Button
                          size="sm"
                          disabled={!selectedDate || !selectedSlot}
                          onClick={handleBookAppointment}
                          data-ocid="patient.confirm_booking.primary_button"
                        >
                          Confirm Booking
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div
              className="bg-green-50 border border-green-200 rounded-xl p-4 text-center"
              data-ocid="patient.booking_confirmed.success_state"
            >
              <CheckCircle size={28} className="mx-auto mb-2 text-green-600" />
              <p className="font-bold text-green-700">
                Appointment Booked Successfully!
              </p>
              {selectedDoctor !== null && (
                <p className="text-sm text-muted-foreground mt-1">
                  {BOOKING_DOCTORS[selectedDoctor].name} &bull; {selectedDate}{" "}
                  &bull; {selectedSlot} &bull;{" "}
                  {consultType === "online" ? "Online" : "In-Person"}
                </p>
              )}
            </div>
          )}
        </section>
      )}

      {/* Upcoming Appointments */}
      {appointments.length > 0 && (
        <section>
          <h2 className="text-base font-bold mb-3 flex items-center gap-2">
            <CalendarCheck size={16} className="text-primary" /> Upcoming
            Appointments
          </h2>
          <div className="space-y-2">
            {appointments.map((appt, i) => (
              <div
                key={appt.id}
                className="bg-card rounded-xl border border-border p-4 flex items-center gap-4"
                data-ocid={`patient.appointment.item.${i + 1}`}
              >
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                  {appt.consultationType === "online" ? (
                    <Video size={16} className="text-primary" />
                  ) : (
                    <Calendar size={16} className="text-primary" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold">{appt.doctorName}</p>
                  <p className="text-xs text-muted-foreground">
                    {appt.specialty} &bull; {appt.hospital}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {appt.date} at {appt.slot}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <Badge
                    className={`text-xs ${appt.consultationType === "online" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"} border-0`}
                  >
                    {appt.consultationType === "online"
                      ? "Online"
                      : "In-Person"}
                  </Badge>
                  <Badge
                    className={`text-xs ${appt.status === "completed" ? "bg-green-100 text-green-700" : appt.status === "rejected" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"} border-0`}
                  >
                    {appt.status.charAt(0).toUpperCase() + appt.status.slice(1)}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Doctor Recommendation Feedback */}
      {showDoctorRecommendation && (
        <section>
          <h2 className="text-base font-bold mb-3 flex items-center gap-2">
            <Stethoscope size={16} className="text-primary" /> Doctor
            Recommendation
          </h2>
          <div className="space-y-3">
            <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl p-4">
              <AlertCircle
                size={18}
                className="text-amber-600 flex-shrink-0 mt-0.5"
              />
              <p className="text-sm text-amber-800 font-medium">
                Please follow the doctor&apos;s recommendations and proceed with
                suggested tests.
              </p>
            </div>

            {latest.recommendedTests?.length > 0 && (
              <div className="bg-card rounded-xl border border-primary/20 p-4">
                <h3 className="text-sm font-bold mb-1 flex items-center gap-2 text-primary">
                  <FlaskConical size={15} /> Recommended Tests
                </h3>
                <p className="text-xs text-muted-foreground italic mb-3">
                  Recommended tests are optional but advised for better
                  diagnosis.
                </p>
                <div className="space-y-2">
                  {latest.recommendedTests.map((test, i) => (
                    <div
                      key={test}
                      className="flex items-center gap-3 p-2.5 bg-primary/5 rounded-lg"
                      data-ocid={`patient.recommended_test.item.${i + 1}`}
                    >
                      <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                        {i + 1}
                      </div>
                      <span className="text-sm font-medium">{test}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Clinical Notes */}
            {(latest.clinicalNotes || latest.doctorNotes) && (
              <div className="bg-card rounded-xl border border-primary/20 p-4">
                <h3 className="text-sm font-bold mb-2 flex items-center gap-2 text-primary">
                  <MessageSquare size={15} /> Clinical Notes
                </h3>
                <p className="text-sm leading-relaxed bg-primary/5 rounded-lg p-3">
                  &ldquo;{latest.clinicalNotes || latest.doctorNotes}&rdquo;
                </p>
              </div>
            )}

            {/* Medical Notes (patient-friendly) */}
            {latest.medicalNotes && (
              <div className="bg-card rounded-xl border border-primary/20 p-4">
                <h3 className="text-sm font-bold mb-2 flex items-center gap-2 text-primary">
                  <MessageSquare size={15} /> Medical Notes
                </h3>
                <p className="text-sm leading-relaxed bg-primary/5 rounded-lg p-3">
                  &ldquo;{latest.medicalNotes}&rdquo;
                </p>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Doctor Recommendations */}
      {myPatients.length > 0 && (
        <section>
          <h2 className="text-base font-bold mb-3 flex items-center gap-2">
            <Stethoscope size={16} className="text-primary" /> Recommended
            Hospitals – Chennai, Tamil Nadu
          </h2>

          <div className="mb-4">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Building2 size={12} /> Private Hospitals – Chennai
            </p>
            <div className="grid md:grid-cols-3 gap-3">
              {DOCTORS_PRIVATE.map((doc, i) => (
                <div
                  key={doc.hospital}
                  className="bg-card rounded-xl border border-gray-100 shadow-sm p-4"
                  data-ocid={`patient.doctor_private.item.${i + 1}`}
                >
                  <div className="flex items-start gap-2 mb-2">
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold text-xs flex-shrink-0">
                      {doc.hospital[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold leading-tight">
                        {doc.hospital}
                      </p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        <Badge className="bg-primary/10 text-primary border-0 text-xs">
                          {doc.specialty}
                        </Badge>
                        <Badge className="bg-blue-100 text-blue-700 border-0 text-xs">
                          Private
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    📍 {doc.location}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    📅 {doc.availability}
                  </p>
                  <p className="text-xs font-semibold text-primary mt-1">
                    💰 {doc.fee}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Shield size={12} /> Government Hospitals – Chennai
            </p>
            <div className="grid md:grid-cols-3 gap-3">
              {DOCTORS_GOVT.map((doc, i) => (
                <div
                  key={doc.hospital}
                  className="bg-card rounded-xl border border-green-100 p-4"
                  data-ocid={`patient.doctor_govt.item.${i + 1}`}
                >
                  <div className="flex items-start gap-2 mb-2">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-700 font-bold text-xs flex-shrink-0">
                      {doc.hospital[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold leading-tight">
                        {doc.hospital}
                      </p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        <Badge className="bg-green-100 text-green-700 border-0 text-xs">
                          {doc.specialty}
                        </Badge>
                        <Badge className="bg-teal-100 text-teal-700 border-0 text-xs">
                          Government
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    📍 {doc.location}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    📅 {doc.availability}
                  </p>
                  <p className="text-xs font-semibold text-green-700 mt-1">
                    💰 {doc.fee}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Lab Recommendations */}
      {myPatients.length > 0 && (
        <section>
          <h2 className="text-base font-bold mb-3 flex items-center gap-2">
            <FlaskConical size={16} className="text-primary" /> Nearby
            Diagnostic Labs – Chennai, Tamil Nadu
          </h2>
          <div className="grid md:grid-cols-2 gap-3">
            {LABS.map((lab, i) => (
              <div
                key={lab.name}
                className="bg-card rounded-xl border border-gray-100 shadow-sm p-4"
                data-ocid={`patient.lab.item.${i + 1}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <p className="text-sm font-semibold">{lab.name}</p>
                  <span className="text-xs font-bold text-primary">
                    {lab.cost}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mb-2">
                  📍 {lab.location}
                </p>
                <div className="flex flex-wrap gap-1">
                  {lab.tests.map((t) => (
                    <Badge
                      key={t}
                      className="bg-muted text-muted-foreground border-0 text-xs"
                    >
                      {t}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Patient-only insurance information; kept out of doctor/admin data. */}
      <section>
        <h2 className="text-base font-bold mb-3 flex items-center gap-2">
          <Shield size={16} className="text-primary" /> Cancer Coverage Information (India)
        </h2>
        <p className="text-xs text-muted-foreground mb-3">
          These are examples to check, not personalized recommendations. An insurer may not accept an application or cover an existing diagnosis or treatment. Check eligibility and current terms directly with the insurer.
        </p>
        <div className="grid md:grid-cols-2 gap-3">
          {cancerCoverageOptions.map((option, index) => (
            <article
              key={option.id}
              className="bg-card rounded-xl border border-gray-100 shadow-sm p-4"
              data-ocid={`patient.cancer_coverage.item.${index + 1}`}
            >
              <p className="text-xs font-semibold text-primary">{option.provider}</p>
              <h3 className="text-sm font-bold mt-1">{option.name}</h3>
              <p className="text-xs text-muted-foreground mt-2">{option.summary}</p>
              <p className="text-xs mt-2">{option.importantTerms}</p>
              <a
                className="inline-block text-xs text-primary underline mt-3"
                href={option.officialUrl}
                target="_blank"
                rel="noreferrer"
              >
                View official product information
              </a>
              <p className="text-[10px] text-muted-foreground mt-2">
                Information checked {option.lastVerified}; terms can change.
              </p>
            </article>
          ))}
        </div>
        <div className="bg-card rounded-xl border border-primary/20 p-4 mt-3">
          <h3 className="text-sm font-bold mb-2">Before considering cover</h3>
          <ul className="list-disc pl-5 space-y-1 text-xs text-muted-foreground">
            {cancerCoverageChecklist.map((item) => <li key={item}>{item}</li>)}
          </ul>
          <p className="text-xs text-muted-foreground mt-3">{existingCoverageNote}</p>
          <p className="text-xs text-muted-foreground mt-2">
            IRDAI explains that cover for a disclosed pre-existing disease depends on the insurer&apos;s underwriting and the product terms. {" "}
            <a className="text-primary underline" href={irdaiHealthInsuranceUrl} target="_blank" rel="noreferrer">Read IRDAI&apos;s health insurance information</a>.
          </p>
        </div>
      </section>

      <Separator />

      {/* Disclaimer */}
      <div className="flex items-start gap-2 bg-muted rounded-xl p-4">
        <Shield size={16} className="text-primary mt-0.5 flex-shrink-0" />
        <p className="text-xs text-muted-foreground">
          DermaMind is a screening aid only. A dermatologist can review your report if you choose to request professional care. Do not use these results to diagnose yourself.
        </p>
      </div>
    </div>
  );
}

function ReportCard({ patient, index }: { patient: Patient; index: number }) {
  const colors = getRiskColors(patient.riskZone);
  const label = getRiskLabel(patient.riskZone);

  const zoneMsg =
    patient.riskZone === "green"
      ? `GREEN ZONE — screening score ${patient.riskScore}/120. Continue monitoring and contact a dermatologist if anything changes.`
      : patient.riskZone === "yellow"
        ? `YELLOW ZONE — screening score ${patient.riskScore}/120. A dermatologist review is advised.`
        : `RED ZONE — screening score ${patient.riskScore}/120. Arrange a dermatologist review as soon as possible.`;

  const canDownload =
    patient.riskZone === "yellow" || patient.riskZone === "red";

  return (
    <div
      className={`bg-card rounded-xl border p-4 ${colors.border}`}
      data-ocid={`patient.report.item.${index}`}
    >
      <div className="flex items-center gap-4">
        <div
          className={`w-10 h-10 ${colors.bg} rounded-full flex items-center justify-center flex-shrink-0`}
        >
          <Activity size={16} className={colors.text} />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-semibold">
              Patient ID: {patient.id}
            </span>
            <Badge className={`text-xs ${colors.badge} border-0`}>
              {label}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Submitted:{" "}
            {new Date(patient.submittedAt).toLocaleDateString("en-IN")}
          </p>
        </div>
        <div className="text-right">
          <div className={`text-sm font-bold ${colors.text}`}>
            {patient.doctorReviewed ? "Reviewed" : "Under Medical Review"}
          </div>
          <Progress
            value={(patient.riskScore / 120) * 100}
            className="w-24 h-1.5 mt-1"
          />
        </div>
      </div>

      {/* Zone message */}
      <div
        className={`mt-3 p-3 rounded-lg text-xs font-medium ${colors.bg} ${colors.text}`}
      >
        {zoneMsg}
      </div>
      <p className="mt-2 text-[11px] text-muted-foreground">Rule-based screening score, not a probability or diagnosis.</p>

      {/* Doctor review message */}
      <div className="mt-2 text-xs text-blue-700 bg-blue-50 rounded-lg p-2">
        This screening summary is not automatically reviewed by a clinician. Contact a dermatologist for professional assessment.
      </div>

      {/* PDF download (Yellow/Red only) */}
      {canDownload && (
        <Button
          size="sm"
          variant="outline"
          className="mt-3 flex items-center gap-2 text-xs"
          onClick={() => generateUserReportPDF(patient)}
          data-ocid={`patient.download_report.button.${index}`}
        >
          <Download size={13} /> Download Your Report
        </Button>
      )}
    </div>
  );
}

// ─── Follow-Up Date Banner ────────────────────────────────────────────────────

const MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

function formatFollowUpDate(assessmentDate: string, months: number): string {
  const base = new Date(assessmentDate);
  const result = new Date(base);
  result.setMonth(result.getMonth() + months);
  const day = result.getDate();
  const month = MONTH_NAMES[result.getMonth()];
  const year = result.getFullYear();
  return `${day} ${month} ${year}`;
}

interface FollowUpBannerProps {
  assessmentDate: string;
  followUpMonths: number;
  onChangeMonths: (months: number) => void;
}

function FollowUpBanner({
  assessmentDate,
  followUpMonths,
  onChangeMonths,
}: FollowUpBannerProps) {
  const dateStr = formatFollowUpDate(assessmentDate, followUpMonths);
  const intervals = [3, 4, 5, 6] as const;

  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      data-ocid="patient.followup_banner"
    >
      <div
        className="bg-card rounded-xl shadow-sm border-l-4 border border-border overflow-hidden"
        style={{ borderLeftColor: "#E53935" }}
      >
        <div className="p-4 md:p-5">
          <div className="flex items-start gap-3">
            <div
              className="flex-shrink-0 rounded-lg p-2.5"
              style={{ backgroundColor: "#FFF5F5" }}
            >
              <Calendar size={22} style={{ color: "#E53935" }} />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-bold text-foreground leading-tight">
                Next Health Check Reminder
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                Your next recommended assessment is on:
              </p>
              <p
                className="text-lg font-extrabold mt-1 leading-snug"
                style={{ color: "#E53935" }}
                data-ocid="patient.followup_date.display"
              >
                {dateStr}
              </p>
            </div>
          </div>

          <div className="mt-4">
            <p className="text-xs text-muted-foreground mb-2 font-medium">
              Adjust reminder interval:
            </p>
            <div className="flex flex-wrap gap-2">
              {intervals.map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => onChangeMonths(m)}
                  data-ocid={`patient.followup_interval.${m}months`}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all duration-150 focus-visible:ring-2 focus-visible:ring-offset-1"
                  style={
                    followUpMonths === m
                      ? {
                          backgroundColor: "#E53935",
                          color: "#fff",
                          borderColor: "#E53935",
                        }
                      : {
                          backgroundColor: "transparent",
                          color: "#6b7280",
                          borderColor: "#e5e7eb",
                        }
                  }
                >
                  {m} months
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
