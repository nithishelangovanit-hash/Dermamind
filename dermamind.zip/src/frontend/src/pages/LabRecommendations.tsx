import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FlaskConical, MapPin, Phone, Search, Star } from "lucide-react";
import { useState } from "react";

interface Lab {
  id: number;
  name: string;
  city: string;
  distance: number;
  rating: number;
  tests: string[];
  costRange: string;
  category: "low" | "mid" | "high";
}

const LABS: Lab[] = [
  {
    id: 1,
    name: "Apollo Diagnostics",
    city: "Delhi",
    distance: 2.3,
    rating: 4.8,
    tests: ["Dermoscopy", "Skin biopsy", "Mole mapping"],
    costRange: "₹800 – ₹3,500",
    category: "high",
  },
  {
    id: 2,
    name: "SRL Diagnostics",
    city: "Mumbai",
    distance: 1.5,
    rating: 4.6,
    tests: ["Dermatology consultation", "Skin biopsy"],
    costRange: "₹600 – ₹2,500",
    category: "mid",
  },
  {
    id: 3,
    name: "Metropolis Labs",
    city: "Bangalore",
    distance: 3.1,
    rating: 4.5,
    tests: ["Dermoscopy", "Skin biopsy"],
    costRange: "₹700 – ₹3,000",
    category: "mid",
  },
  {
    id: 4,
    name: "Thyrocare",
    city: "Hyderabad",
    distance: 0.8,
    rating: 4.3,
    tests: ["Dermoscopy", "Mole mapping"],
    costRange: "₹500 – ₹1,500",
    category: "low",
  },
  {
    id: 5,
    name: "LIMS Diagnostics",
    city: "Chennai",
    distance: 4.2,
    rating: 4.4,
    tests: ["Skin biopsy", "Dermatology consultation"],
    costRange: "₹600 – ₹2,800",
    category: "mid",
  },
  {
    id: 6,
    name: "Healthians",
    city: "Pune",
    distance: 1.9,
    rating: 4.2,
    tests: ["Dermoscopy", "Mole mapping"],
    costRange: "₹400 – ₹1,200",
    category: "low",
  },
];

export default function LabRecommendations() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "low" | "mid" | "high">("all");

  const filtered = LABS.filter((l) => {
    const matchSearch =
      !search ||
      l.name.toLowerCase().includes(search.toLowerCase()) ||
      l.city.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "all" || l.category === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto">
      <h1 className="text-xl font-bold mb-1">Lab Recommendations</h1>
      <p className="text-sm text-muted-foreground mb-5">
        Find nearby diagnostic labs for your recommended tests.
      </p>

      <div className="flex gap-3 flex-wrap mb-5">
        <div className="relative flex-1 min-w-48">
          <Search
            size={14}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search labs or city..."
            className="pl-8"
            data-ocid="labs.search.search_input"
          />
        </div>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as typeof filter)}
          className="border border-input rounded-lg px-3 py-2 text-sm bg-background"
          data-ocid="labs.filter.select"
        >
          <option value="all">All Cost Ranges</option>
          <option value="low">Budget (₹400–1,500)</option>
          <option value="mid">Mid (₹1,500–3,000)</option>
          <option value="high">Premium (₹3,000+)</option>
        </select>
      </div>

      <div className="space-y-3">
        {filtered.map((lab, i) => (
          <div
            key={lab.id}
            className="bg-card rounded-xl border border-border p-4"
            data-ocid={`labs.lab.item.${i + 1}`}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex gap-3">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <FlaskConical size={18} className="text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">{lab.name}</h3>
                  <div className="flex items-center gap-3 mt-0.5">
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin size={10} /> {lab.city} • {lab.distance} km
                    </span>
                    <span className="flex items-center gap-1 text-xs text-amber-600">
                      <Star size={10} fill="currentColor" /> {lab.rating}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {lab.tests.map((t) => (
                      <Badge
                        key={t}
                        variant="outline"
                        className="text-xs px-1.5 py-0"
                      >
                        {t}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="text-sm font-bold text-primary">
                  {lab.costRange}
                </p>
                <Button
                  size="sm"
                  className="mt-2 text-xs"
                  data-ocid={`labs.book.button.${i + 1}`}
                >
                  Book Now
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
