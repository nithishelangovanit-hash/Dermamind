import { Alert } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Shield, User } from "lucide-react";
import { useState } from "react";
import Logo from "../components/Logo";
import type { DoctorSpecialty, Screen, User as UserType } from "../types";

interface Props {
  onNavigate: (screen: Screen) => void;
  onLogin: (user: UserType) => void;
}

const ACCOUNTS: Record<string, UserType> = {
  "patient1@demo.com": {
    name: "Arjun Kumar",
    email: "patient1@demo.com",
    role: "patient",
  },
  "patient2@demo.com": {
    name: "Priya Devi",
    email: "patient2@demo.com",
    role: "patient",
  },
  "patient3@demo.com": {
    name: "Ravi Shankar",
    email: "patient3@demo.com",
    role: "patient",
  },
  "patient4@demo.com": {
    name: "Lakshmi Narayanan",
    email: "patient4@demo.com",
    role: "patient",
  },
  "patient5@demo.com": {
    name: "Senthil Murugan",
    email: "patient5@demo.com",
    role: "patient",
  },
  "doctor@demo.com": {
    name: "Dr. Ramesh Nair",
    email: "doctor@demo.com",
    role: "doctor",
    specialty: "Dermatologist" as DoctorSpecialty,
  },
  "dermatologist@demo.com": {
    name: "Dr. Priya Sharma",
    email: "dermatologist@demo.com",
    role: "doctor",
    specialty: "Dermatologist" as DoctorSpecialty,
  },
  "admin@demo.com": {
    name: "Admin User",
    email: "admin@demo.com",
    role: "admin",
  },
};

const PASSWORDS: Record<string, string> = {
  "patient1@demo.com": "patient1",
  "patient2@demo.com": "patient2",
  "patient3@demo.com": "patient3",
  "patient4@demo.com": "patient4",
  "patient5@demo.com": "patient5",
  "doctor@demo.com": "doctor123",
  "dermatologist@demo.com": "doctor123",
  "admin@demo.com": "admin",
};

// 5 demo patient accounts — each with unique credential
const DEMO_PATIENTS = [
  {
    name: "Patient 1 — Arjun Kumar",
    label: "Low risk profile",
    email: "patient1@demo.com",
    password: "patient1",
    zone: "Green" as const,
    description: "Green Zone",
  },
  {
    name: "Patient 2 — Priya Devi",
    label: "Moderate symptoms",
    email: "patient2@demo.com",
    password: "patient2",
    zone: "Yellow" as const,
    description: "Yellow Zone",
  },
  {
    name: "Patient 3 — Ravi Shankar",
    label: "High-risk case",
    email: "patient3@demo.com",
    password: "patient3",
    zone: "Red" as const,
    description: "Red Zone",
  },
  {
    name: "Patient 4 — Lakshmi Narayanan",
    label: "Moderate skin symptoms",
    email: "patient4@demo.com",
    password: "patient4",
    zone: "Yellow" as const,
    description: "Yellow Zone",
  },
  {
    name: "Patient 5 — Senthil Murugan",
    label: "Minimal symptoms",
    email: "patient5@demo.com",
    password: "patient5",
    zone: "Green" as const,
    description: "Green Zone",
  },
];

const ZONE_STYLES: Record<
  "Green" | "Yellow" | "Red",
  { badge: string; border: string; bg: string }
> = {
  Green: {
    badge: "bg-green-100 text-green-800 border-green-300",
    border: "border-green-200 hover:border-green-400",
    bg: "hover:bg-green-50",
  },
  Yellow: {
    badge: "bg-yellow-100 text-yellow-800 border-yellow-300",
    border: "border-yellow-200 hover:border-yellow-400",
    bg: "hover:bg-yellow-50",
  },
  Red: {
    badge: "bg-red-100 text-red-800 border-red-300",
    border: "border-red-200 hover:border-red-400",
    bg: "hover:bg-red-50",
  },
};

interface DemoLoginButtonProps {
  loading: boolean;
  email: string;
  password: string;
  onUse: (email: string, password: string) => void;
  ocid: string;
}

function DemoLoginButton({
  loading,
  email,
  password,
  onUse,
  ocid,
}: DemoLoginButtonProps) {
  return (
    <Button
      type="button"
      size="sm"
      variant="outline"
      className="text-[10px] h-7 px-2.5 flex-shrink-0 border-primary/40 text-primary hover:bg-primary hover:text-primary-foreground"
      disabled={loading}
      onClick={() => onUse(email, password)}
      data-ocid={ocid}
    >
      Use This Account
    </Button>
  );
}

export default function AuthPage({ onNavigate, onLogin }: Props) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function doLogin(emailVal: string, passwordVal: string) {
    setError("");
    const user = ACCOUNTS[emailVal.trim().toLowerCase()];
    if (!user || PASSWORDS[emailVal.trim().toLowerCase()] !== passwordVal) {
      setError("Invalid email or password.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin(user);
    }, 600);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !password) {
      setError("Please fill all fields.");
      return;
    }
    doLogin(email, password);
  }

  function useDemoPatient(emailVal: string, passwordVal: string) {
    setEmail(emailVal);
    setPassword(passwordVal);
    doLogin(emailVal, passwordVal);
  }

  // Quick-access role buttons (existing functionality preserved)
  const patientAccounts = [
    ACCOUNTS["patient1@demo.com"],
    ACCOUNTS["patient2@demo.com"],
    ACCOUNTS["patient3@demo.com"],
    ACCOUNTS["patient4@demo.com"],
    ACCOUNTS["patient5@demo.com"],
  ];
  const doctorAccounts = [
    ACCOUNTS["doctor@demo.com"],
    ACCOUNTS["dermatologist@demo.com"],
    ACCOUNTS["admin@demo.com"],
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Back */}
        <button
          type="button"
          onClick={() => onNavigate("intro")}
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6"
          data-ocid="auth.back.button"
        >
          <ArrowLeft size={16} /> Back to Home
        </button>

        <Card className="shadow-card border-border">
          <CardHeader className="text-center pb-4">
            <div className="flex justify-center mb-2">
              <Logo size="lg" variant="dark" />
            </div>
          </CardHeader>
          <CardContent>
            {/* ── LOGIN FORM ── */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="email" className="text-xs font-semibold">
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="mt-1"
                  data-ocid="auth.email.input"
                />
              </div>
              <div>
                <Label htmlFor="password" className="text-xs font-semibold">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="mt-1"
                  data-ocid="auth.password.input"
                />
              </div>
              {error && (
                <Alert className="py-2 text-sm text-destructive border-destructive/30 bg-destructive/5">
                  {error}
                </Alert>
              )}
              <Button
                type="submit"
                className="w-full"
                disabled={loading}
                data-ocid="auth.login.submit_button"
              >
                {loading ? "Signing in..." : "Sign In"}
              </Button>
            </form>

            {/* ── QUICK ROLE ACCESS ── */}
            <div className="mt-5 pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground mb-3 font-semibold">
                Quick Role Access
              </p>
              <div className="space-y-2">
                {patientAccounts.map((acc, idx) => (
                  <button
                    key={acc.email}
                    type="button"
                    onClick={() => {
                      setEmail(acc.email);
                      setPassword(PASSWORDS[acc.email]);
                    }}
                    className="w-full text-left px-3 py-2 rounded-lg border border-border hover:bg-muted transition-colors text-xs"
                    data-ocid={`auth.demo_patient_${idx + 1}.button`}
                  >
                    <span className="font-semibold">Patient {idx + 1}</span>:{" "}
                    {acc.email} / {PASSWORDS[acc.email]}
                  </button>
                ))}
                {doctorAccounts.map((acc) => (
                  <button
                    key={acc.email}
                    type="button"
                    onClick={() => {
                      setEmail(acc.email);
                      setPassword(PASSWORDS[acc.email]);
                    }}
                    className="w-full text-left px-3 py-2 rounded-lg border border-border hover:bg-muted transition-colors text-xs"
                    data-ocid={`auth.demo_${acc.role}.button`}
                  >
                    <span className="font-semibold capitalize">
                      {acc.specialty
                        ? `${acc.specialty}`
                        : acc.role.charAt(0).toUpperCase() + acc.role.slice(1)}
                    </span>
                    : {acc.email} / {PASSWORDS[acc.email]}
                  </button>
                ))}
              </div>
            </div>

            {/* ── DEMO PATIENT ACCOUNTS SECTION ── */}
            <div className="mt-6 pt-5 border-t-2 border-primary/20">
              <div className="flex items-center gap-2 mb-1">
                <User size={15} className="text-primary" />
                <p className="text-sm font-bold text-foreground">
                  Demo Patient Accounts
                  <span className="ml-1.5 text-xs font-normal text-muted-foreground">
                    (For Testing)
                  </span>
                </p>
              </div>
              <p className="text-xs text-muted-foreground mb-3 leading-relaxed">
                These are demo accounts for system testing and presentation.
              </p>

              <div className="space-y-2" data-ocid="auth.demo_patients.list">
                {DEMO_PATIENTS.map((patient) => {
                  const zoneStyle = ZONE_STYLES[patient.zone];
                  return (
                    <div
                      key={patient.name}
                      className={`flex items-center justify-between gap-3 rounded-lg border px-3 py-2.5 transition-colors ${zoneStyle.border} ${zoneStyle.bg}`}
                      data-ocid={`auth.demo_patient.item.${patient.name.split(" ")[1]}`}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-semibold text-foreground truncate">
                            {patient.name}
                          </span>
                          <span
                            className={`inline-flex items-center rounded-full border px-1.5 py-0.5 text-[10px] font-semibold ${zoneStyle.badge}`}
                          >
                            {patient.zone === "Green" && "🟢 "}
                            {patient.zone === "Yellow" && "🟡 "}
                            {patient.zone === "Red" && "🔴 "}
                            {patient.description}
                          </span>
                        </div>
                        <p className="text-[10px] text-muted-foreground mt-0.5 truncate">
                          {patient.email} &nbsp;·&nbsp; {patient.label}
                        </p>
                      </div>
                      <DemoLoginButton
                        loading={loading}
                        email={patient.email}
                        password={patient.password}
                        onUse={useDemoPatient}
                        ocid={`auth.use_demo_patient.button.${patient.name.split(" ")[1]}`}
                      />
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ── DISCLAIMER ── */}
            <div className="mt-4 flex items-start gap-2 bg-primary/5 rounded-lg p-3">
              <Shield size={14} className="text-primary mt-0.5 flex-shrink-0" />
              <p className="text-xs text-muted-foreground">
                This is a screening tool only. Not a substitute for professional
                medical diagnosis.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
