import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Activity,
  AlertCircle,
  Brain,
  ChevronRight,
  Eye,
  Heart,
  Shield,
  Stethoscope,
  TrendingUp,
  Users,
  Sparkles,
  Zap,
} from "lucide-react";
import { motion } from "motion/react";
import Logo from "../components/Logo";
import type { Screen } from "../types";

interface Props {
  onNavigate: (screen: Screen) => void;
}

const doctors = [
  {
    name: "Dr. YYY",
    specialty: "Dermatologist",
    exp: "12+ years",
    initials: "YY",
    focus: "Skin Cancer & Melanoma",
    recognition: "IADVL Member, Skin Oncology Cert.",
    icon: <Eye size={20} />,
    color: "bg-amber-100 text-amber-700",
  },
];

const stats = [
  {
    value: "ABCDE",
    label: "Spot warning sign checklist",
    icon: <Users size={20} />,
  },
  {
    value: "EFG",
    label: "Elevated, firm, growing",
    icon: <TrendingUp size={20} />,
  },
  {
    value: "1 spot",
    label: "Notice the Ugly Duckling sign",
    icon: <Activity size={20} />,
  },
  { value: "Screening", label: "Not a diagnosis", icon: <Shield size={20} /> },
];

const cancerTypes = [
  {
    icon: "🧴",
    name: "Skin Cancer",
    signs:
      "Changing moles, irregular borders, uneven color, bleeding spots (ABCDE rule), non-healing sores",
  },
];

const educationSections = [
  {
    icon: <Brain size={18} className="text-primary" />,
    title: "What is skin screening?",
    body: "Skin screening means noticing new or changing spots and asking a qualified clinician to assess concerns. Appearance alone cannot confirm cancer.",
  },
  {
    icon: <TrendingUp size={18} className="text-primary" />,
    title: "When to seek care",
    body: "Arrange a dermatologist assessment for a spot that is changing, bleeding, persistently itchy, crusting, or not healing.",
  },
  {
    icon: <Eye size={18} className="text-primary" />,
    title: "Skin Cancer Awareness",
    body: "Skin cancer is the most common cancer globally, detectable visually at early stages. The ABCDE rule (Asymmetry, Border, Color, Diameter, Evolving) helps identify warning signs.",
  },
  {
    icon: <AlertCircle size={18} className="text-primary" />,
    title: "Screening vs. Diagnosis",
    body: "DermaMind is a skin cancer screening aid — it identifies warning signs that may warrant further investigation. It is not a medical diagnosis. Always consult a qualified dermatologist.",
  },
  {
    icon: <Zap size={18} className="text-primary" />,
    title: "About DermaMind",
    body: "DermaMind uses a prototype rule-based skin screening score and may connect to a machine learning model trained on synthetic data. Outputs are not clinically validated or diagnostic.",
  },
  {
    icon: <Shield size={18} className="text-primary" />,
    title: "Privacy & review",
    body: "A report is not automatically reviewed by a clinician. Only share information with a dermatologist when you choose to request professional care.",
  },
];

export default function IntroPage({ onNavigate }: Props) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/95 backdrop-blur border-b border-border">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <Logo size="sm" variant="dark" />
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate("auth")}
              data-ocid="intro.login.button"
            >
              Login
            </Button>
            <Button
              size="sm"
              onClick={() => onNavigate("auth")}
              data-ocid="intro.start_screening.primary_button"
            >
              Start Screening
            </Button>
          </div>
        </div>
      </header>

      {/* ═══ SPECIALIST CARDS — TOP PRIORITY ═══ */}
      <section className="py-10 px-4 bg-card border-b border-border">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center gap-2 mb-2">
            <Stethoscope size={18} className="text-primary" />
            <span className="text-xs font-semibold text-primary uppercase tracking-wider">
              Our Medical Panel
            </span>
          </div>
          <h2 className="text-xl font-bold mb-6">
            Dermatology Screening Guidance
          </h2>
          <div className="grid md:grid-cols-3 gap-5">
            {doctors.map((doc) => (
              <motion.div
                key={doc.name}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-background rounded-xl border border-border p-5 flex flex-col items-center text-center shadow-sm"
              >
                <div
                  className={`w-14 h-14 ${doc.color} rounded-full flex items-center justify-center mb-3`}
                >
                  {doc.icon}
                </div>
                <h3 className="font-bold text-base">{doc.name}</h3>
                <Badge className="mt-1 mb-2 bg-primary/10 text-primary border-0 text-xs">
                  {doc.specialty}
                </Badge>
                <p className="text-xs text-muted-foreground">
                  Experience: {doc.exp}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {doc.focus}
                </p>
                <p className="text-xs text-primary/70 mt-1.5 font-medium">
                  🏅 {doc.recognition}
                </p>
              </motion.div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground text-center mt-4 italic">
            Screening aid only. No clinician review is implied by using this page.
          </p>
        </div>
      </section>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-background pt-16 pb-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20 text-xs px-3 py-1">
              <Shield size={12} className="mr-1" />
              Screening Tool Only — Not a Medical Diagnosis
            </Badge>
            <h1 className="text-3xl md:text-5xl font-bold text-foreground leading-tight mb-4">
              Skin Cancer Warning Signs
              <span className="block text-primary mt-1">ABCDE, EFG, and Ugly Duckling</span>
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-8 text-lg">
              Review common warning signs and decide when to contact a dermatologist. This tool does not diagnose skin cancer.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                size="lg"
                onClick={() => onNavigate("auth")}
                data-ocid="intro.hero_cta.primary_button"
                className="bg-primary hover:bg-primary/90 text-white px-8 py-6 text-base shadow-lg"
              >
                Begin Free Screening <ChevronRight size={18} className="ml-1" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => {
                  document
                    .getElementById("learn-more")
                    ?.scrollIntoView({ behavior: "smooth" });
                }}
                data-ocid="intro.learn_more.button"
                className="px-8 py-6 text-base"
              >
                Learn More
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-10 px-4 bg-card border-y border-border">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="flex justify-center mb-2 text-primary">
                {stat.icon}
              </div>
              <div className="text-2xl font-bold text-primary">
                {stat.value}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Warning Signs */}
      <section className="py-14 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle size={18} className="text-primary" />
            <span className="text-xs font-semibold text-primary uppercase tracking-wider">
              Warning Signs
            </span>
          </div>
          <h2 className="text-2xl font-bold mb-8">Know the warning signs</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {cancerTypes.map((c) => (
              <motion.div
                key={c.name}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-card rounded-xl p-6 border border-border shadow-card"
              >
                <div className="text-3xl mb-3">{c.icon}</div>
                <h3 className="font-bold text-lg mb-2">{c.name}</h3>
                <p className="text-sm text-muted-foreground">{c.signs}</p>
              </motion.div>
            ))}
          </div>
          <div className="grid md:grid-cols-2 gap-5 mt-5">
            <div className="bg-card rounded-xl p-6 border border-border shadow-card"><h3 className="font-bold text-lg mb-3">ABCDE rule</h3><ul className="space-y-2 text-sm text-muted-foreground"><li><b>A — Asymmetry:</b> one half does not match the other.</li><li><b>B — Border:</b> irregular, ragged, notched or blurred edges.</li><li><b>C — Color:</b> uneven shades of brown or black, or patches of pink, red, white or blue.</li><li><b>D — Diameter:</b> larger than 6 mm (about a pencil eraser), though melanomas can be smaller.</li><li><b>E — Evolving:</b> changing in size, shape, colour or elevation, or new itching, crusting or bleeding.</li></ul></div>
            <div className="space-y-5"><div className="bg-card rounded-xl p-6 border border-border shadow-card"><h3 className="font-bold text-lg mb-3">EFG rule</h3><ul className="space-y-2 text-sm text-muted-foreground"><li><b>Elevated:</b> raised above the skin.</li><li><b>Firm:</b> feels hard, not soft.</li><li><b>Growing:</b> increasing in size over time.</li></ul></div><div className="bg-card rounded-xl p-6 border border-border shadow-card"><h3 className="font-bold text-lg mb-2">Ugly Duckling sign</h3><p className="text-sm text-muted-foreground">One spot looks noticeably different from all your other moles.</p></div></div>
          </div>
          <p className="text-xs text-center text-muted-foreground mt-5">Screening aid only. Not a diagnosis. See a dermatologist if you notice these signs.</p>
        </div>
      </section>

      {/* Educational Sections */}
      <section id="learn-more" className="py-14 px-4 bg-muted/30">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center gap-2 mb-2">
            <Brain size={18} className="text-primary" />
            <span className="text-xs font-semibold text-primary uppercase tracking-wider">
              Education
            </span>
          </div>
          <h2 className="text-2xl font-bold mb-8">Understanding skin screening</h2>
          <div className="grid md:grid-cols-2 gap-5">
            {educationSections.map((section) => (
              <motion.div
                key={section.title}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-card rounded-xl p-5 border border-border"
              >
                <div className="flex items-center gap-2 mb-2">
                  {section.icon}
                  <h3 className="font-semibold text-sm">{section.title}</h3>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {section.body}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 bg-primary text-white text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-3">
          Skin Screening Aid
        </h2>
        <p className="text-white/80 mb-6 max-w-xl mx-auto">
          Not a diagnosis. Contact a dermatologist if you notice a concerning change.
        </p>
        <Button
          size="lg"
          variant="outline"
          onClick={() => onNavigate("auth")}
          data-ocid="intro.bottom_cta.primary_button"
          className="border-white text-white hover:bg-white hover:text-primary px-8"
        >
          Start Your Screening Now
        </Button>
      </section>

      {/* Disclaimer */}
      <div className="py-4 px-4 border-t border-border text-center text-xs text-muted-foreground">
        <p>
          This tool is for screening purposes only. It does not replace
          professional medical diagnosis.
        </p>
      </div>
    </div>
  );
}
