import type React from "react";
import { createContext, useContext, useEffect, useState } from "react";
import { createDemoPatients } from "../data/demoPatients";
import type { Patient } from "../types";

interface PatientStoreCtx {
  patients: Patient[];
  addPatient: (p: Patient) => void;
  updatePatient: (id: string, updates: Partial<Patient>) => void;
  clearAllPatients: () => void;
}

const PatientStoreContext = createContext<PatientStoreCtx>({
  patients: [],
  addPatient: () => {},
  updatePatient: () => {},
  clearAllPatients: () => {},
});

const STORAGE_KEY = "oncomind_patients";
const DEMO_SEEDED_KEY = "oncomind_demo_seeded";

function loadPatients(): Patient[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return [];
    const records = JSON.parse(stored) as unknown;
    if (!Array.isArray(records)) return [];
    // Old mixed assessment records are ignored so an old answer can't be interpreted as a skin symptom.
    const currentRecords = records.filter((record): record is Patient => {
      if (!record || typeof record !== "object" || !Array.isArray((record as Patient).symptoms)) return false;
      const symptoms = (record as Patient).symptoms as unknown[];
      return symptoms.length === 25 && symptoms.every((s) => !!s && typeof s === "object" && "answer" in s && "rule" in s);
    });
    if (records.length > 0 && currentRecords.length === 0) localStorage.setItem(DEMO_SEEDED_KEY, "false");
    return currentRecords;
  } catch {
    return [];
  }
}

function seedDemoIfNeeded(current: Patient[]): Patient[] {
  // Only seed if no patients exist yet and we haven't seeded before
  const alreadySeeded = localStorage.getItem(DEMO_SEEDED_KEY) === "true";
  if (current.length === 0 && !alreadySeeded) {
    const demo = createDemoPatients();
    localStorage.setItem(DEMO_SEEDED_KEY, "true");
    return demo;
  }
  return current;
}

export function PatientStoreProvider({
  children,
}: { children: React.ReactNode }) {
  const [patients, setPatients] = useState<Patient[]>(() => {
    const loaded = loadPatients();
    return seedDemoIfNeeded(loaded);
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(patients));
  }, [patients]);

  function addPatient(p: Patient) {
    setPatients((prev) => [p, ...prev]);
  }

  function updatePatient(id: string, updates: Partial<Patient>) {
    setPatients((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p)),
    );
  }

  function clearAllPatients() {
    setPatients([]);
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(DEMO_SEEDED_KEY);
  }

  return (
    <PatientStoreContext.Provider
      value={{ patients, addPatient, updatePatient, clearAllPatients }}
    >
      {children}
    </PatientStoreContext.Provider>
  );
}

export function usePatientStore() {
  return useContext(PatientStoreContext);
}
